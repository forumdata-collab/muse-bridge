# v96 改動清單 — 2026-11-10（用戶反饋修復）

## 1. 鹿角與頭分離（根因：v95 回歸）
- 舊問題：鹿角 group 樞軸喺鹿身原點，`onFrameDeer` 每格將鹿角轉 `-0.22 rad`，角基被推離頭部約 0.45 個鹿身單位。
  舊版鹿角未標 `dynamic`，合併後轉角唔生效，空隙睇唔到；v95 標咗 `dynamic` 令輕擺生效，空隙先現形。
- 修復：`js/deer.js` `buildAntlers` 樞軸改設喺角基 `(±0.07, 1.84, 1.0)`，分枝座標改為相對角基；
  角柄（由頭骨內伸出）同角基骨瘤扁球一齊隨鹿角擺動，永遠連住頭。
  `onFrameDeer` 輕擺改為 `rotation.x = sin(t)·0.01`、`rotation.z = sin(t)·0.006`，唔再有 `-0.22` 整體轉角。
- 驗證：Node smoke test（真 three.js + stub DOM）— 鹿角樞軸 y=1.84、擺幅 max |rot.x|=0.0095、擺動後角基與頭心距離 0.075。

## 2. 鹿嘴麥穗（取代靈芝垂條）
- 舊版口中係一條幼細靈芝垂條，正面望落只係嘴邊一點點。
- 修復：`js/deer.js` `buildWheatEar()` 取代 `buildLingzhiStrand()`：穗柄由嘴角向前伸出，兩片唇瓣夾住穗柄；
  穗頭 7 對麥粒左右交錯 + 芒刺 + 頂粒，鹿含麥穗喻豐收得祿。
- 驗證：smoke test 數到麥粒 15 粒（7 對 + 頂粒），位置喺嘴前；舊靈芝色 `#9d6b26` 網格已清零。

## 3. 鹿台隸書「金鹿 • 祿」消失（根因：v95 回歸）
- 舊問題：v95 加嘅實心金框 `box(.30,.15,.012, …, 0,.25,.768)` 前面喺 z=.774，比牌面 z=.773 更前，
  成塊牌畀金板遮住晒。原版無呢塊金板，所以之前見到。
- 修復：金框改為四條邊框條（牌面外圍，前面 z=.776）；牌面移到 z=.778、`renderOrder=2`、`userData.dynamic=true`；
  牌面先用 Canvas 隸書後備字（`U.cvs` 440×200，深紅底金字 + 雙金線框），PNG 載好再換上 `assets/deer-plate.png`。
- 驗證：smoke test 牌面 z=.778、有 map。

## 4. 跪拜善信 + 廟祝衣服細節（`js/world.js`）
- 兩位跪姿善信：對襟 + 三粒盤扣、腰帶、裙腳邊、袖口邊、深色布鞋、髮髻 + 金簪、合十手腕七粒念珠；兩人邊色不同（金 / 米白）。
- 廟祝（唐裝短褂）：領口金邊、三對盤扣 + 結、袖口金邊、下擺金邊、胸袋巾。
- 全部加喺原本嘅 dynamic subtree 內，姿態動畫（`poseKneelingVisitor` / `gmUpdate`）唔受影響。

## 5. 求籤取香：案頭加香盤（3D + 介面）
- 3D：`js/world.js` `buildOfferings` 供桌加香盤（籤筒前方，x=.55, z=-9.20）：黃銅淺盤 + 紅布墊 +
  三炷平放清香（紅香頭）+ 五炷紮埋嘅備用香 +「香盤」小牌；`U.incenseTray` / `U.lotIncenseTray` 供程式取用。
- 介面：`js/lot-ritual.js` 求籤加第一步「取香」— 開場 `phase="incense"`，按「取三炷清香」先可以搖籤；
  未取香之前按住籤筒 / 一鍵搖籤唔會郁。重新搖籤唔使再取香；`resetDraw` 保持 `phase="ready"`。

## 6. 香案爐腳穿透案頭（`js/world.js` `buildDetails`）
- 舊問題：香案爐三足中心 y=-.06、足底 -0.17，穿過枱面（枱面頂 1.01）；爐身底又貼枱，足根本無承托作用。
- 修復：爐座升到枱面金邊頂（cg y .98→1.01）；三足改為高 .16、中心 y=.08（足底 0 貼枱、足頂 .16 托爐底）；
  爐身中心 .25→.41（爐底 .16、爐頂 .66）；爐耳 .34→.50、香灰盤 .5→.66、香枝中心 .68→.85；
  `ashY` .5→.66、煙霧基座相應上移（仍喺香灰上 .32）。木魚同樣由 .98 升到 1.01，唔再沉入枱面。
- 主爐（正殿主爐）三足係連接爐身同石柱嘅結構，唔係穿透，今次無改。

## 版本
- 快取 bump：sw.js manmo-v96、app.js sw.js?v=33、index.html scene/world/deer ?v=20261110b、lot-ritual ?v=20261113b、app ?v=20261111y

## 驗證（2026-11-10）
- `node --check` 通過：deer / world / lot-ritual / incense / app / scene / relics / optimize。
- Node smoke test（真 three.js r128 + stub DOM，`/tmp/v96_smoke.js`）：9 項全通過（鹿角樞軸、擺幅、角基貼頭、麥粒 15 粒、麥穗位置、牌面 z 與 map、舊靈芝已清）。
- 香案爐幾何數值驗算：足底 0 = 枱面、足頂 .16 = 爐底、爐頂 .66 = ashY、香枝底 .66 = 香灰、煙基座喺香灰上 .32。
- 未做瀏覽器截圖測試（VM 無 Playwright/Chromium，同 v95 一樣）；求籤取香流程只做結構檢查，未做真機點擊測試。

## 補修（2026-11-10，交件前按 MANUAL §10 檢查發現）
- `sw.js` `ASSETS` 漏咗 i18n 六件（`js/i18n.js`、`js/i18n-3d.js`、`js/lots-l10n.js`、`locales/ui.js`、`locales/ui3d.js`、`locales/ritual.js`），外語版離線會失效。已補齊；`node --check sw.js` 通過，CACHE 仍為 manmo-v96，版本號唔使再 bump。
