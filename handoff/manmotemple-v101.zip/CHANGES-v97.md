# v97 改動清單 — 2026-11-10（用戶反饋：麥穗要柔和含住）

## 1. 鹿口麥穗改為「柔和含住」（`js/deer.js` `buildWheatEar`）
- 舊問題（v96）：穗柄係一支直棍，由嘴角向前上方伸出（轉角 1.15 rad），睇落似插喺嘴邊；唇瓣只係兩粒細球喺穗柄兩側，包唔住。
- 修復：
  - 穗柄改為柔和 S 形彎曲（`CatmullRomCurve3` + `TubeGeometry`，半徑 .0095）：起點喺嘴內（鹿身局部 (0.015, 1.599, 1.306)，即吻部中心），穿過唇間彎出，末端微垂接穗頭。
  - 上下唇瓣改用金身物料（`gold()`），輕輕合攏托住穗柄：上唇喺穗柄上面（局部 -z，世界向上），下唇飽滿啲喺下面由下托住；兩邊嘴角向內收，包住穗柄兩側。似含住慢慢吮住，唔再係硬直戳出。
  - 成穗轉角 1.15 → 1.42 rad：穗頭向前微垂、貼住下唇線。頂粒由 (0.02, 1.80, 1.86) 降到 (0.02, 1.66, 1.904)，低咗、向前平伸，唔再向上戳。
  - 穗頭不變：7 對麥粒 + 頂粒 = 15 粒（`#e8c268`），芒刺不變。
- 驗證：`node --check js/deer.js` 通過；Node smoke test（真 three.js r128 + stub DOM）9 項全通過，包括麥粒 15 粒、麥粒喺嘴邊（世界 z 3.30–3.42）；幾何數值驗算：穗柄起點喺吻部中心內、上唇喺穗柄上 .03、下唇喺穗柄下 .03。

## 2. 全廟動畫細節提升（2026-11-10，3D 檢視）
檢視結果：燈籠搖、燭光閃、香煙、塵埃、鹿呼吸／鹿角／耳／尾、善信跪拜循環、廟祝手勢呼吸點頭、幡／祈福牌／香牌搖、光明燈閃、搖籤、擲筊物理、節慶花瓣、聖物觸摸動畫、上香插入動畫本身已經齊全。以下係之前靜止、家下郁返嘅部分：
- 菊花花頭輕擺（`js/world.js`）：6 朵菊花頭成組輕擺（±.03 rad，莖唔郁），花頭 group 帶 `userData.ph`，合併件掛返花頭 group 上跟住擺，唔使標 dynamic，draw call 幾乎唔加。
- 燭光火苗微傾（`js/world.js` `onFrameOfferings`）：火苗 sprite 左右輕挨 ±.005，好似有氣流掠過。
- 庭院街燈光暈呼吸（`js/world.js`）：兩盞街燈光暈透明度 .35±.08 慢慢脈動。
- 節慶橫額輕擺（`js/festival.js`）：橫額轉角 ±.012 輕搖；`onFrameFestival` 開頭先擺橫額，冇花瓣嘅模式都郁到。
- 效能：每格只係多幾個 sin 運算，零新增 allocation；花頭改為按頭合併（+9 個小 draw call 左右），鈴 3 件唔合併，整體影響輕微。
- 刻意冇郁嘅：籤筒（未搖之前應該靜止）、鐘鼓（只係敲先郁）、神像相片（實物相，唔係 3D 模型）、生果。
- （後來修正：鹿嘅三項——麥穗微擺、頸鈴輕搖、金箔閃爍——連同原有嘅鹿呼吸／鹿角／耳／尾，一併喺 §3 移除，因為金鹿係擺設。上面其餘四項保留。）

## 3. 金鹿改為全靜止（2026-11-10，用戶糾正）
- 金鹿係擺設，唔會呼吸、唔會郁：`onFrameDeer` 改為空殼，移除鹿身呼吸、鹿角輕擺、耳抖、尾擺、麥穗微擺、頸鈴輕搖、金箔星光閃爍。成個擺件靜止。
- 其餘動畫不受影響：菊花、燭光、街燈、節慶橫額繼續郁（嗰啲唔係擺件）。

## 4. 外語簽文 audit + 與獨立站一致（2026-11-10）
獨立站：https://handcraftstudio.eu.org/manmotemple/fortunestick/（en / ja / th）。
Audit 結果：
- 簽文資料本身一致：`lots.js`、`lots-l10n.js`、`lot-stories.js`、`lot-view.js`、`locales/ui.js`、`locales/ui3d.js`、`locales/ritual.js`、`divination-core.js`、`i18n.js`，live 站與工作目錄逐字節相同。
- 問題一（主因）：3D 廟從來冇載入 `lots-l10n.js`，亦冇掛 `l.l10n`。外語頁求籤，`LotView.readingHtml` 攞唔到譯本，只會顯示「譯文仍在準備中」；而獨立站 en/ja/th 頁會動態載入譯本，顯示完整英／日／泰文。
- 問題二：3D 廟冇載入 `js/i18n.js`，`window.I18N` 不存在，`LotView` 永遠以 `zh-Hant` 渲染，`?lang=en` 頁嘅籤文彈窗都係中文；獨立站有 `I18N.lang`。
- 問題三：`i18n-3d.js` 落後 live 站 3 條規則，「一百籤 · 第 N 籤」喺外語頁唔識翻譯。
修正（工作目錄）：
- `index.html`：外語頁（`?lang=`）同步載入 `js/lots-l10n.js?v=1`（中文頁唔下載，同獨立站一樣）；`lot-view.js` 之前加載 `locales/ui.js?v=2` + `js/i18n.js?v=2`（只係定義 `window.UI_STRINGS` / `window.I18N`，唔會自動改 DOM）。
- `js/app.js`：啟動時掛上 `l.l10n = LOTS_L10N[l.n]`（中文頁冇載入譯本，呢段唔做嘢）。
- `js/i18n-3d.js`：補返 3 條「一百籤 · 第 N 籤」規則，家下同 live 站逐字節相同。
- 驗證（`/tmp/v97_lot_parity.js`，17 項全通過）：100 支籤 × en/ja/th × 9 個欄位齊全（2700 項檢查）；第 1、42、78、100 籤英／日／泰文正常渲染，冇「準備中」卡；中文導讀原文不變；原籤紙（`paperHtml`）永遠中文直式；舊路徑（冇 I18N、冇譯本）喺 `?lang=en` 頁顯示中文／「準備中」卡，證明 bug 已修。

## 版本
- 快取 bump：sw.js manmo-v97、app.js sw.js?v=34、index.html deer/world/festival ?v=20261110c、app.js ?v=20261111z、i18n-3d.js ?v=5；新載入 ui.js?v=2、i18n.js?v=2、lots-l10n.js?v=1（與獨立站同版；三者本身已在 sw.js ASSETS，離線唔使改）。

## 驗證（2026-11-10）
- `node --check` 通過：deer / world / festival / app / i18n-3d（其餘模組 v96 已驗）。
- Node smoke test（真 three.js r128 + stub DOM）：鹿 `/tmp/v97_smoke.js` 19 項全通過（v96 原有 9 項 + 靜止驗證）；世界 `/tmp/v97_world_smoke.js` 9 項全通過（連續跑 5 次）；簽文一致性 `/tmp/v97_lot_parity.js` 18 項全通過。交件前捉到一個測試本身嘅問題：燭光／花頭／燈暈嘅 `ph` 係隨機，相位撞啱時兩點取樣會誤判，改為多點取最大－最小範圍驗證，code 本身無改。
- 本地開站：index、i18n.js、ui.js、lots-l10n.js、新版 app.js / i18n-3d.js / deer.js / world.js / festival.js / sw.js 全部 200；fortunestick/、en/、ja/、th/ 全部 200（只係靜態 HTTP 200，未做瀏覽器點擊測試）。
- 未做瀏覽器截圖測試（VM 無 Playwright/Chromium，同 v95/v96 一樣）。
- 已交付：2026-11-10 經 GitHub `inbox/v97-20261110.json` 交畀 Hermes 做 diff（只做 diff，唔部署；部署要用戶喺 Telegram 講「推」）。
