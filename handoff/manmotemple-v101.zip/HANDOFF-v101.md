# manmotemple v101 handoff（2026-11-10）

已上線版本，CACHE `manmo-v101`。

- 線上：https://handcraftstudio.eu.org/manmotemple/ ／ https://hi.we1co.me/manmotemple/
- 部署 URL：https://20c31f3b.hi-we1co.pages.dev/manmotemple/
- 權威 repo：forumdata-collab/hi-we1co `76cdd92`（private，唔可以 clone；用本 zip）
- 結構：`index.html` 在 `manmotemple/` 一層內（符合 §10）

## 相對 v100 zip 的唯一改動
- `js/scene.js`：`TEX.floor.repeat.set(7,8)` → `(4,5)`（每格 1.38×1.30m），格間色差 `60+rand*14` → `61+rand*9`；`offset(.125,.125)` 不變（仍然磚心置中）
- `sw.js`：`CACHE = "manmo-v101"`
- `index.html`：`js/scene.js?v=20261110f`
- `js/app.js`：`sw.js?v=38`
- 其餘（i18n、incense、ritual、divination、ASSETS 清單、相片欄、匾額）同 v100 完全一樣

## 改動時必須守住
1. `js/i18n-3d.js` 保持 md5 `0f5e17a4f4362192d717b2e26554f7be`（175 行）——唔好用舊快照覆蓋，會倒退「一百籤 · 第 N 籤」三條 RULES
2. `sw.js` 的 `ASSETS` 要留住 i18n 六件：`js/i18n.js`、`js/i18n-3d.js`、`js/lots-l10n.js`、`locales/ui.js`、`locales/ui3d.js`、`locales/ritual.js`
3. 交新版時 CACHE 用 `manmo-v102` 或以上；任何 HTML/CSS/JS 行為改動都要 bump
