# v95 改動清單 — 2026-11-10

## 金鹿（js/deer.js）
- 鎏金程序化貼圖（拉絲、錘揲凹點、舊化）+ bump + 環境反光
- 頭：鼻孔、嘴線、下頜肌、下巴、眼瞼、眉脊、額頂金簇；耳：內耳、耳緣、耳尖，間中輕動
- 鹿角：段數提升、新增眉枝、角基雙環、尖端深色；標 dynamic，輕擺生效
- 身：胸隆、腹底、脇側雲紋陰刻、背脊鬃毛；尾獨立 dynamic，可輕擺
- 腿：分叉蹄、蹄踵絨毛、小距；頸筋
- 金牌加「福」字、頸圈金珠、小鈴鈴舌；台座金包角、金線、牌面金框；金箔皺摺
- castShadow

## 供桌祭品（js/world.js）
- 青花瓷盤 + 青葉墊；橙 / 蘋果 / 桃分得清，各有莖、葉、皮紋
- 菊花（花心 + 兩層花瓣 + 莖葉）+ 青花瓷車床花瓶
- 燭台（黃銅車床 + 滴蠟盤）+ 滴蠟 + 燭芯 + 雙層閃爍火焰
- 新增紅布、三杯清茶、發糕 ×3、元寶 ×2；主爐香灰丘、香枝紅線；籤筒竹紋

## 一併改進（js/scene.js 等）
- 新增 TEX.gold / porcelain / orange / bamboo、U.ENV CubeTexture 環境貼圖、神壇補光、U.onFrameOfferings
- 快取 bump：sw.js manmo-v95、app.js sw.js?v=32、index.html scene/world/deer ?v=20261110a

## 驗證
- node --check：scene.js / world.js / deer.js / app.js 全部通過
- 本地 http.server 載入檢查：見下方「本地驗證」

## 本地驗證
- 用 `python3 -m http.server 8899` 在 manmotemple/ 預覽，開 http://127.0.0.1:8899/ ，入殿後行去金鹿（中軸）同正殿神壇，近睇鹿頭、鹿角、果盤、花、燭。
- 如用 Playwright 截圖，可跑現有 tests/deer3_shots.py / tests/plate_shot.py 作對比。

## 驗證（實測，2026-11-10）
- Node smoke test（stub DOM + WebGL，load three + scene/world/deer/relics/optimize，MM.init → buildWorld → buildDeer → buildRelics → optimizeStatic → mergeColored）：PASS
  - 原版：mesh 1092 → 優化後 323；v95：mesh 1338 → 優化後 380（+57，約 +18%，換取金鹿動畫生效 + 供品細節）
  - ENV、TEX.gold/porcelain/orange/bamboo 全部載入；candleFlames 2 盞；gildDeer('antler') → true，resetDeer 後清空
- node --check：scene.js / world.js / deer.js / app.js / relics.js / incense.js / optimize.js 全部通過
- 本地 http.server 8899：index 200、scene/world/deer ?v=20261110a 全部 200
