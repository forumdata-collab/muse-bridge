/* 文武廟 · 雲端參拜 — 離線快取
   導航與程式碼一律 network-first（更新即時生效），圖片 cache-first。 */
const CACHE = "manmo-v101";
const ASSETS = ["./", "index.html", "js/scene.js", "js/world.js", "js/deer.js", "js/relics.js", "js/festival.js", "js/incense.js", "js/optimize.js", "js/audio.js", "js/app.js", "js/lots.js", "js/lot-stories.js", "js/lot-view.js", "js/divination-core.js", "js/lot-ritual.js", "js/i18n.js", "js/i18n-3d.js", "js/lots-l10n.js", "locales/ui.js", "locales/ui3d.js", "locales/ritual.js", "assets/voice/greet.mp3", "assets/voice/history.mp3", "assets/voice/rite.mp3", "assets/voice/tour.mp3", "assets/deities/altar-shrine.jpg", "assets/deities/deities-zoom.jpg", "assets/deer-plate.png", "assets/washi.jpg",
  "assets/fonts/mm-serif-tc.woff2", "assets/fonts/mm-sans-tc.woff2", "vendor/three.min.js", "assets/bgm.mp3", "assets/coils1.jpg", "assets/interior2.jpg", "assets/altar.jpg",
  "assets/exterior1.jpg", "assets/roof.jpg", "assets/plaques.jpg", "assets/plaque.jpg", "manifest.webmanifest", "assets/icon-192.png", "assets/icon-512.png", "assets/favicon.svg"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS).catch(() => {})).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const isCode = /\.(js|css|json|webmanifest)$/.test(url.pathname) || url.pathname.endsWith("/");

  if (req.mode === "navigate") {
    e.respondWith(fetch(req).catch(() => caches.match("index.html")));
    return;
  }
  if (isCode) {
    /* network-first：有新版本即取新版本，離線時才用快取 */
    e.respondWith(fetch(req).then(res => {
      const copy = res.clone();
      caches.open(CACHE).then(c => c.put(req, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match(req)));
    return;
  }
  e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(res => {
    const copy = res.clone();
    caches.open(CACHE).then(c => c.put(req, copy)).catch(() => {});
    return res;
  }).catch(() => hit)));
});
