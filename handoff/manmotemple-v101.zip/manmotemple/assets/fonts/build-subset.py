#!/usr/bin/env python3
"""Rebuild the bundled Noto Serif/Sans TC subsets for the Man Mo lot UI.

Run from the site root:  python3 assets/fonts/build-subset.py

Coverage = every character in index.html, js/**, css/** plus Big5 level-1
(5,401 common traditional characters). That makes the bundle robust for new
L.reading / L.bixian / L.jieyue prose added later, not only today's lot text.
Re-run after new lot data lands and check the reported coverage counts.
"""
import os
import pathlib
import subprocess
import sys
import tempfile
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUT = pathlib.Path(__file__).resolve().parent
SOURCES = {
    "serif": ("https://raw.githubusercontent.com/google/fonts/main/ofl/notoseriftc/NotoSerifTC%5Bwght%5D.ttf",
              OUT / "mm-serif-tc.woff2"),
    "sans": ("https://raw.githubusercontent.com/google/fonts/main/ofl/notosanstc/NotoSansTC%5Bwght%5D.ttf",
             OUT / "mm-sans-tc.woff2"),
}
SCAN = ["index.html", "manifest.webmanifest"]
SCAN_DIRS = ["js", "css"]


def collect_chars(extra=()):
    chars = set()
    files = [ROOT / p for p in SCAN if (ROOT / p).exists()]
    for d in SCAN_DIRS:
        base = ROOT / d
        if base.exists():
            files += [p for p in base.rglob("*") if p.suffix.lower() in {".js", ".json", ".css", ".html"}]
    files += [pathlib.Path(p) for p in extra if pathlib.Path(p).exists()]
    for p in files:
        chars.update(p.read_text(encoding="utf-8", errors="ignore"))
    # Big5 level 1: the 5,401 most common traditional Chinese characters.
    for hi in range(0xA4, 0xC7):
        for lo in range(0x40, 0x7F):
            if hi == 0xC6 and lo > 0x7E:
                continue
            try:
                ch = bytes([hi, lo]).decode("big5")
            except UnicodeDecodeError:
                continue
            if len(ch) == 1:
                chars.add(ch)
    chars.update("　·—…「」『』〈〉《》【】‧・°％＋－×÷")
    return {c for c in chars if not c.isascii() or 0x20 <= ord(c) <= 0x7E}


def main():
    text = "".join(sorted(collect_chars(sys.argv[1:])))
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as fh:
        fh.write(text)
        charfile = fh.name
    print(f"coverage characters: {len(text)}")
    for name, (url, dest) in SOURCES.items():
        src = pathlib.Path(tempfile.gettempdir()) / f"noto-{name}-tc.ttf"
        if not src.exists():
            print(f"downloading {name} source …")
            urllib.request.urlretrieve(url, src)
        cmd = [sys.executable, "-m", "fontTools.subset", str(src),
               f"--text-file={charfile}", "--flavor=woff2", f"--output-file={dest}",
               "--layout-features=kern,liga,locl,ccmp,mark,mkmk,vert",
               "--name-IDs=1,2,3,4,6", "--drop-tables+=DSIG", "--no-hinting"]
        subprocess.run(cmd, check=True)
        print(f"{dest.name}: {dest.stat().st_size/1024:.0f} KB")
    os.unlink(charfile)


if __name__ == "__main__":
    main()
