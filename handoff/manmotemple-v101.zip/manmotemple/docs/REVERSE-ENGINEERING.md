# 逆向分析與重實作說明

本文件記錄參考站的技術拆解、可複用的設計模式，以及本作品如何對應實作。
只借鑑**互動模式與氣氛**；程式碼、材質、音檔、籤文資料均為自行撰寫或取自公共領域 / CC 授權素材。

---

## 一、參考站 A：`mazu-temple.harper88888.workers.dev`（雲端天后宮）

### 1. 形態
單一 HTML（約 783 KB）內嵌全部 CSS / JS，無建置步驟；資源用 CDN：

| 依賴 | 用途 |
|---|---|
| three.js **r128**（cdnjs） | 全 3D |
| GLTFLoader + meshopt_decoder | 神像 GLB（`mazu-model.js` 形式以 script 注入 base64） |
| pinyin-pro | 姓名 / 注音相關互動 |
| Supabase JS（`zgwbthrqjrsnhqpdcona.supabase.co`） | 多人 presence（同殿人數、其他香客位置） |

外部資產：`mural.jpg`、`lamps.webp`、`tex1.jpg`、`music.mp3`、`favicon.png`、`manifest.webmanifest`。

### 2. 場景架構（由註釋分段讀出）
```
renderer & scene    → ACESFilmic, exposure .82, Fog(34,90)
the hall            → HX=12, HZ=15, HH=10（米）；藻井、樑、花崗石柱、格扇窗
courtyard / 虎爺 / 天公爐
avatars             → 可換裝：SKIN/HAIRS/HAIRC/STYLES/ROBE_STYLES/HATS/EYES/BROWS/MOUTH/GEAR
平安符過爐 · jiaobei（筊杯）
state, input, camera → 虛擬搖桿 + 近距離站點（nearChip）
NPC demo worshippers → 假香客維持「廟很旺」的感覺
multiplayer (room presence)
audio · HUD · sheets
玄天上帝畫北斗 / 關帝斬小人（互動小遊戲）
歌仔戲台 / 布袋戲台（事件）
```
- **全程序化貼圖**：`floorTex / carvedTex / beamTex / latticeTex / curtainTex / plaqueDraw / donateTex / lotSignTex` 等全部用 Canvas 2D 即時繪製，再 `CanvasTexture`。這是低成本做出「廟味」的關鍵。
- **塔香**：`TubeGeometry` 沿圓錐螺旋 curve，加頂端 emissive 光點 + 粒子煙。
- **光明燈**：140 盞，`lamps.webp` 做櫃體 alphaTest 貼圖，逐盞以 emissive 平面 + additive sprite 呈現明暗；用 `alphaTest` 而非 transparent 避免深度排序錯誤（原碼有註釋記錄此坑）。
- **求籤資料**：`POEMS`（60 首七絕，`干支|句1|句2|句3|句4`）、`BAIHUA`（逐句白話）、`JIEQIAN`（總解 + 功名/婚姻/求財/疾病/出外/家運/失物/官事 八項）、`JQ_CATS`。
- **互動**：`stations{}`（approach 座標 + face 朝向）＋ `nearChip`，走近顯示；底部印章式四鍵（拜 / 筊 / 籤 / 香）。
- **HUD**：殿別切換、參拜指引、音量、聊天、表情、換裝、背包、隱藏他人 / 介面、畫質。
- **多人**：Supabase presence 房間；顯示同時在線人數與其他香客 avatar。

### 3. 值得抄的設計決策
1. 站點式互動（走近才提示）比純按鈕更有臨場感。
2. 底部 sheet 承載所有長內容，3D 不中斷。
3. 塔香 + 煙 + 燭光 = 廟宇氣氛的 80%。
4. 燈牆、祈福牌等「可留下痕跡」的功能，是回訪誘因。
5. 假香客（NPC）在沒有人連線時仍撐住「香火鼎盛」。

---

## 二、參考站 B：`sansatemple.com`（산사，韓國「靜靜共坐」線上寺廟）

- Vite + Vue 打包的 SPA，three.js 遊戲 chunk（`assets/game-*.js`）＋ `cloud-presence` chunk。
- URL 合約：`?room=maru-51&instance=0&region=apac`；room 以 `/^maru(-\d{2,3})?$/` 驗證。
- 產品概念：**無聊天、無任務**，只有「別人也靜靜坐在這裡」的共在感；人數與環境音是主要回饋。
- 對本作品的啟示：UI 要退後、環境音要連續、同坐人數比排行榜更重要。

---

## 三、參考站 C：另一份 `man-mo-temple.zip`

ES modules + three.js CDN 的**外觀組群**版本（圍牆、牌坊、重檐正殿、列聖宮、鐘亭、上環樓景），功能：跪拜、三炷香、16 首原創籤、擲筊、鳴鐘、天燈、煙花、BroadcastChannel 同源分頁同步、`config.js` 的 `wsUrl` / `arModelUrl` 升級位、Web Audio 合成音效、in-app browser 提示。

可借鑑：**1847 銅鐘 / 1862 官轎**等史實細節、`config.js` 的「部署時只改一檔」思路、BroadcastChannel 作為無後端 presence 的過渡。

---

## 四、本作品的功能對照

| 參考功能 | 本作品 | 實作位置 |
|---|---|---|
| 3D 廟宇、塔香、藻井 | ✅ 正殿 + 天井 + 列聖宮 + 廟前 | `js/scene.js` |
| 虛擬搖桿 / 拖曳環視 / 碰撞 | ✅ 第一人稱 + 站點提示 | `scene.js` `updatePlayer()` / `stations` |
| 參拜（跪拜） | ✅ 三鞠躬鏡頭動畫 | `app.js doBow()` / `MM.bow()` |
| 求籤 + 關帝一百籤 | ✅ 搖籤筒動畫 + 等第 / 典故 / 詩 / 聖意 / 東坡解 | `world.js shakeLot()` + `js/lots100.js` |
| 擲筊（3D 拋擲） | ✅ 聖 / 笑 / 陰，隨機物理拋擲 | `world.js throwJiao()` |
| 上香 + 煙 | ✅ 香案煙霧、香枝累加 | `world.js` `addIncenseStick()` |
| 光明燈牆 | ✅ 60 盞，可命名、可熄燈、本地保存 | `world.js` `setLamp()` |
| 祈福牌 | ✅ 3D 紅牌掛上祈福架 | `world.js addWish()` |
| 鳴鐘 / 擊鼓 | ✅ 鐘擺、鼓震 + 合成音 | `world.js` + `audio.js` |
| 多人同在 | ⚠️ 靜態版未含（見下） | — |
| 換裝 avatar / 背包 / 聊天 | ❌ 刻意不做（本作是單人參拜 + 文化導覽） | — |
| 全合成音效 | ✅ 殿內嗡鳴、風、鐘、鼓、木魚 | `js/audio.js` |
| 畫質 / 音量設定 | ✅ 高 / 中 / 省電 | `app.js openSettings()` |
| In-app browser 提示 | ✅ | `app.js` |
| 3D / AR 模型位 | ➕ 以 Google Earth 3D + 街景外鏈代替 | `app.js renderIntro()` |

### 刻意偏離之處
- **不做 Supabase / WebSocket 依賴**：交付物是可直接上傳的靜態 zip，避免帶金鑰與外部帳號。
- **不做虛擬貨幣 / 背包**：與「參拜」主題無關，會削弱莊重感。
- **籤詩用關聖帝君一百籤（雷雨師）**，上環文武廟所行；只取傳統原文，不假稱廟方授權；UI 與 README 都如實標示。

---

## 四之二、金鹿（2026-11 追加）

參考東華三院〈文武廟推出全新祈願金鹿服務〉：

- 鹿喻「俸祿」，為文昌帝君座前神獸；善信到廟內櫃位請金箔（每片 HK$18），合十稟願後貼在金鹿身上。
- 部位對應：鹿角＝智慧／判斷力（求學）、臉＝工作與人緣（在職）、腹＝招財守財（營商）、腳＝家庭和合（已婚）、背＝健康（任何人）。
- 實作：`js/deer.js` 自行建模金色公鹿（含分叉鹿角、曲線鹿角管、蹄與關節），置於正殿左側紅木台座；`MM.gildDeer(area)` 在對應位置加上金屬金箔片，狀態存 localStorage；UI 在 `js/app.js renderDeer()`。
- 站點：`stations.deer`（走近顯示「金鹿 · 貼金箔祈願」），底部第六個動作鍵「鹿」。
- 不涉及付款：只模擬習俗，頁面明確標示。

## 四之三、殿前聖物（2026-11 追加）

- 文昌筆：巨型毛筆斜擱筆架，筆頭朝右上；摸筆求智慧、功名、考試。
- 關帝刀：青龍偃月刀立於刀座，紅纓、金環、亮鋼刀身；摸刀求財運、貴人、辟邪。
- 互動 gating：`state.bowed` 為 false 時按鈕 disabled，按「聖物」會先引導三拜；達成才可摸，次數寫入 `state.relics`。
- 實作：`js/relics.js`（建模 + 觸摸動畫 + 光暈），站點 `stations.brush/blade`，UI 在 `app.js renderRelics()`。

## 四之四、節慶、太歲、祈願中心（2026-11 追加）

- `js/festival.js`：節慶模式（新年／文昌誕／秋祭）切換裝飾與粒子；太歲計算（值／沖／刑／害／破，用 12 地支關係表）。
- `app.js`：`renderMine()`＋`drawCard()`（Canvas 1080×1350 分享圖）、節慶設定、太歲面板、深鏈（`#lot` 等）。
- SEO：JSON-LD TouristAttraction、OG 圖、`sitemap.xml`、`manmotemple/robots.txt`。
- PWA：`beforeinstallprompt` 捕捉後在設定顯示「安裝到主畫面」。

## 五、如果要加多人同在（可選）

最省的做法是 Cloudflare Worker + Durable Object，一個房間一個 DO：

```js
// Worker route: /ws?room=hollywood&region=apac
export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (url.pathname !== "/ws") return env.ASSETS.fetch(req);
    const room = url.searchParams.get("room") || "hollywood";
    const id = env.ROOMS.idFromName(room);
    return env.ROOMS.get(id).fetch(req);
  }
};
// Durable Object: 用 WebSocket Hibernation API，廣播 {id,name,x,z,yaw,ritual}
```

前端只需把 `MM` 的位置（每秒 5–10 次）送上，並把收到的其他訪客畫成簡化人形（可重用 `world.js makeNpc()`）。
協議可直接沿用參考站格式：`{id, name, x, z, ritual}`，另加 `yaw`。
人數顯示可接在 HUD 的殿別 pill 內（如「同時 12 人參拜」）。

---

## 六、效能備註

- 目前約 **3.5 萬三角面 / 500+ draw call**（含 12 串塔香、60 盞燈、神像與供品）。
- 塔香用 `TubeGeometry`（180 段 × 6 邊），是最大單一幾何成本；低畫質可把段數減半。
- 陰影只在「高」畫質開啟，且只有一顆 SpotLight 投影（1536²），避免手機過熱。
- 全站無外部請求 → 首屏只需 5.5 MB（含照片），可再壓照片至 WebP 減半。
