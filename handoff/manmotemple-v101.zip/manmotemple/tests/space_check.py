from playwright.sync_api import sync_playwright
import os, re
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/space/'
os.makedirs(OUT, exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    # 全文頁：第 10 籤
    pg.goto(BASE+'fortunestick/?v=x1#lot10', wait_until='load'); pg.wait_for_timeout(2500)
    txt = pg.evaluate("document.getElementById('lot10').innerText")
    print('FORTUNESTICK lot10 (first 300):')
    print(txt.replace('\n',' | ')[:400])
    print('has ，　 :', '，　' in txt)
    pg.screenshot(path=OUT+'fs_lot10.png', full_page=False)
    b.close()
