from playwright.sync_api import sync_playwright
import os
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/deer2/'
os.makedirs(OUT, exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=d2',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2200)
    print(pg.evaluate("({top:+(MM._.deer.position.y + 2.66*0.48).toFixed(2), plinthTop:0.33, scale:MM._.deer.scale.x})"))
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    for name,x,z,yaw,pitch in [('entry',0,9.4,3.14159,-.03),('front',0,4.6,3.14159,-.12),
                               ('side',2.4,3.6,-2.1,-.14),('back',-1.9,1.0,2.4,-.10)]:
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)",[x,z,yaw,pitch])
        pg.wait_for_timeout(700); pg.evaluate("MM.pause()"); pg.wait_for_timeout(300)
        pg.screenshot(path=OUT+name+'.png',timeout=120000); pg.evaluate("MM.resume()")
        print('shot',name)
    print('ERR',errs)
    b.close()
