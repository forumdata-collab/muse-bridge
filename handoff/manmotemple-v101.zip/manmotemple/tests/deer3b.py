from playwright.sync_api import sync_playwright
import os, math
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/deer3/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=d3c',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2000)
    pg.evaluate("document.querySelectorAll('#hz,#loader,.top,.bottom,#nearChip,#joy').forEach(e=>{if(e)e.style.display='none'});1")
    # 俯視：看台座比例
    pg.evaluate("MM.teleport(0,5.0,Math.PI,-.85)"); pg.wait_for_timeout(600)
    pg.evaluate("MM.pause()"); pg.wait_for_timeout(300)
    pg.screenshot(path=OUT+'top.png',timeout=120000); pg.evaluate("MM.resume()")
    # 左前 40 度，貼近
    x,z=2.3,4.2
    pg.evaluate("([x,z])=>MM.teleport(x,z,Math.atan2(0-x,2.4-z),-.10)",[x,z]); pg.wait_for_timeout(600)
    pg.evaluate("MM.pause()"); pg.wait_for_timeout(300)
    pg.screenshot(path=OUT+'q34.png',timeout=120000); pg.evaluate("MM.resume()")
    print('ok')
    b.close()
