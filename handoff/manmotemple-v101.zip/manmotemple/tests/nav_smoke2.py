from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8899/'
def run(btn, wait=4000):
    with sync_playwright() as p:
        b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
        pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
        errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/sw.js*',lambda r:r.abort())
        pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
        pg.goto(BASE+'?v=ns2',wait_until='load'); pg.locator('#enterBtn').click()
        pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations)',timeout=90000)
        pg.wait_for_timeout(1800)
        pg.evaluate("(id)=>document.getElementById(id).click()", btn)
        pg.wait_for_timeout(wait)
        st=pg.evaluate("(() => { const s=document.getElementById('sheet'); return {open:s.classList.contains('open'), txt:s.innerText.slice(0,90).replace(/\\n/g,' | ')}; })()")
        print(btn, st, 'ERR', errs)
        b.close()
run('lotBtn', 20000); run('jiaoBtn', 20000)
