from playwright.sync_api import sync_playwright
import os, math
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/bd/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=bd3',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2200)
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    x,z=4.6,9.2; tx,tz=9.2,3.7
    yaw=math.atan2(tx-x, tz-z)
    pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)",[x,z,yaw,-.02])
    pg.wait_for_timeout(800); pg.evaluate("MM.pause()"); pg.wait_for_timeout(350)
    pg.screenshot(path=OUT+'pair.png',timeout=120000); pg.evaluate("MM.resume()")
    print('shot pair', yaw)
    b.close()
