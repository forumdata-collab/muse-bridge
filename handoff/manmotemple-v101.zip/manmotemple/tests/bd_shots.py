from playwright.sync_api import sync_playwright
import os
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/bd/'
os.makedirs(OUT, exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=bd1',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2500)
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    print(pg.evaluate("({bell:[MM._.stations.bell.x,MM._.stations.bell.z],drum:[MM._.stations.drum.x,MM._.stations.drum.z],donate:[MM._.stations.donate.x,MM._.stations.donate.z],box:MM._.donateBox.position.toArray()})"))
    for name,x,z,yaw,pitch in [('bell_drum', 5.4, 3.8, 1.5708, -.02),
                               ('bell_drum_wide', 2.6, 7.4, 1.15, -.05),
                               ('donate', -5.4, 8.8, .9, -.04)]:
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)",[x,z,yaw,pitch])
        pg.wait_for_timeout(800); pg.evaluate("MM.pause()"); pg.wait_for_timeout(350)
        pg.screenshot(path=OUT+name+'.png',timeout=120000); pg.evaluate("MM.resume()")
        print('shot',name)
    print('ERR',errs)
    b.close()
