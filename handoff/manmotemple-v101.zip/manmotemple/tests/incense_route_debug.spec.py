from playwright.sync_api import sync_playwright
import json, sys
BASE=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8899/'
with sync_playwright() as p:
 b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
 pg=b.new_context(viewport={'width':900,'height':700}).new_page();pg.route('**/sw.js',lambda r:r.abort())
 pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
 errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.goto(BASE,wait_until='load');pg.wait_for_timeout(1200);pg.evaluate("document.getElementById('enterBtn').click()");pg.wait_for_timeout(3500)
 pg.evaluate("MM.pause();MM.teleport(0,-4.6,Math.PI,0);window.__trace=[];window.__traceTimer=setInterval(()=>__trace.push({x:MM._.player.x,z:MM._.player.z,walk:MM._.walkTarget||null,phase:MM.Incense.phase()}),100)")
 pg.evaluate("document.getElementById('incBtn').click()");pg.wait_for_timeout(80);pg.evaluate("document.getElementById('incThree').click()")
 for _ in range(70):
  if pg.evaluate('MM.Incense.isBusy()'):break
  pg.wait_for_timeout(100)
 for _ in range(240):
  if not pg.evaluate('MM.Incense.isBusy()'):break
  pg.wait_for_timeout(100)
 result=pg.evaluate("(()=>{clearInterval(__traceTimer);let c=MM.Incense.byId('main');return {trace:__trace,main:c.total,front:MM.Incense.byId('front').total,position:MM._.player,toast:document.getElementById('toast').textContent,walk:MM._.walkTarget}})()")
 trace=result['trace'];print(json.dumps({'samples':len(trace),'traceHead':trace[:6],'traceTail':trace[-6:],'main':result['main'],'front':result['front'],'pos':{'x':result['position']['x'],'z':result['position']['z']},'toast':result['toast'],'walk':result['walk'],'errors':errors},ensure_ascii=False))
 b.close()
