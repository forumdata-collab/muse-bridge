from playwright.sync_api import sync_playwright
import os, json
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/bd/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=bd2',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2000)
    print(pg.evaluate("""(() => {
      const U=MM._;
      function bb(o){const b=new THREE.Box3();o.traverse(m=>{if(m.isMesh){m.updateWorldMatrix(true,false);b.expandByObject(m)}});return [b.min.toArray().map(v=>+v.toFixed(2)),b.max.toArray().map(v=>+v.toFixed(2))]}
      return JSON.stringify({bell:bb(U.bell), drum:bb(U.drum), box:bb(U.donateBox),
        bellParent:U.bell.parent.position.toArray().map(v=>+v.toFixed(2)), n:U.bell.parent.children.length});
    })()"""))
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    for name,x,z,yaw,pitch in [('bell', 6.6, 2.4, 1.5708, -.02), ('drum', 6.6, 5.0, 1.5708, -.02), ('donate2', -8.6, 8.4, 0, -.05)]:
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)",[x,z,yaw,pitch])
        pg.wait_for_timeout(700); pg.evaluate("MM.pause()"); pg.wait_for_timeout(300)
        pg.screenshot(path=OUT+name+'.png',timeout=120000); pg.evaluate("MM.resume()")
        print('shot',name)
    b.close()
