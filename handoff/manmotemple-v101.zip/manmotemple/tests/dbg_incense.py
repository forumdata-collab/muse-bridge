from playwright.sync_api import sync_playwright
import json, time
BASE='http://127.0.0.1:8899/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':390,'height':844},device_scale_factor=.35)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=dbg1',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(1500)
    pg.evaluate("MM.teleport(0,7.6,Math.PI,0);document.getElementById('incBtn').click();1")
    pg.wait_for_function("document.getElementById('sheet').classList.contains('open')")
    pg.evaluate("document.getElementById('incThree').click()")
    rows=[]
    for i in range(40):
        time.sleep(1.5)
        rows.append(pg.evaluate("({ph:MM.Incense.phase(),x:+MM._.player.x.toFixed(2),z:+MM._.player.z.toFixed(2),busy:MM.Incense.isBusy(),main:MM.Incense.byId('main').total,front:MM.Incense.byId('front').total,wt:MM.walkTarget()})"))
    print(json.dumps(rows,ensure_ascii=False))
    print('ERR',errs)
    b.close()
