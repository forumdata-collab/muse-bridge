from playwright.sync_api import sync_playwright
import json, math
BASE='http://127.0.0.1:8899/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=nav1',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2000)
    res = pg.evaluate("""(() => {
      const U=MM._, LIM={x0:-9.4,x1:9.4,z0:-8.1,z1:26.5}, D=1.9;
      const cols=[]; [-6.4,6.4].forEach(x=>[4.4,-1.4].forEach(z=>cols.push([x,z])));
      const out=[];
      Object.keys(U.stations).forEach(k=>{
        const s=U.stations[k];
        const sx=s.x-Math.sin(s.face)*D, sz=s.z-Math.cos(s.face)*D;
        const probs=[];
        if(sx<LIM.x0+.2||sx>LIM.x1-.2) probs.push('stand out of x bounds');
        if(sz<LIM.z0+.2) probs.push('stand behind altar limit');
        cols.forEach(c=>{ if(Math.hypot(sx-c[0],sz-c[1])<1.0) probs.push('stand on column '+c); });
        (U.obstacles||[]).forEach(o=>{ if(Math.hypot(sx-o.x,sz-o.z)<o.r+.2) probs.push('stand in obstacle '+o.x+','+o.z); });
        if(Math.hypot(s.x,s.z-2.4)<1.2) probs.push('station on deer');
        out.push({k, name:s.name, sx:+sx.toFixed(2), sz:+sz.toFixed(2), r:s.r, probs});
      });
      return out;
    })()""")
    bad=[r for r in res if r['probs']]
    print('STATIONS', len(res), 'problems:', len(bad))
    for r in bad: print(' !!', r)
    print('deer', pg.evaluate("[MM._.stations.deer.x,MM._.stations.deer.z,MM._.stations.deer.r]"))
    print('ERR', errs)
    b.close()
