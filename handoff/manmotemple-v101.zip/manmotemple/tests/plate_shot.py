from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/deer3/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=plate',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(3000)
    pg.evaluate("document.querySelectorAll('#hz,#loader,.top,.bottom,#nearChip,#joy').forEach(e=>{if(e)e.style.display='none'});1")
    pg.evaluate("MM.teleport(0,4.9,Math.PI,-.62)"); pg.wait_for_timeout(900)
    pg.evaluate("MM.pause()"); pg.wait_for_timeout(400)
    pg.screenshot(path=OUT+'plate.png',timeout=120000)
    print('ok')
    b.close()
