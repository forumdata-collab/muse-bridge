from playwright.sync_api import sync_playwright
import json, sys, time

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8899/"
failures = []


def open_temple(p, seed=None):
    browser = p.chromium.launch(channel="chromium", args=["--no-sandbox", "--use-gl=angle", "--use-angle=swiftshader"])
    context = browser.new_context(viewport={"width": 900, "height": 700}, device_scale_factor=.35)
    context.add_init_script("window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)")
    if seed:
        sticks = json.dumps(seed, separators=(",", ":"))
        context.add_init_script("localStorage.setItem('manmo.sticks.v1', " + json.dumps(sticks) + ")")
    page = context.new_page()
    page.route("**/sw.js", lambda route: route.abort())
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)[:180]))
    page.goto(BASE, wait_until="load")
    page.wait_for_timeout(1500)
    page.locator("#enterBtn").click()
    page.wait_for_timeout(4000)
    return browser, page, errors


def report(name, ok, detail):
    print(("PASS " if ok else "FAIL ") + name + " " + json.dumps(detail, ensure_ascii=False))
    if not ok:
        failures.append(name)


with sync_playwright() as p:
    # Regression: restored sticks must reserve their positions and continue the index.
    now = int(time.time() * 1000)
    seed = [
        {"c": "main", "i": 1, "h": 0.56, "t0": now, "dur": 480000},
        {"c": "main", "i": 2, "h": 0.58, "t0": now, "dur": 480000},
    ]
    browser, page, errors = open_temple(p, seed)
    page.evaluate("MM.pause(); MM.Incense.offer('main',1)")
    restored = page.evaluate("(()=>{const c=MM.Incense.byId('main'),a=MM.Incense.burning.filter(x=>x.c===c);return {total:c.total,sticks:a.map(x=>({i:x.i,x:x.x,z:x.z})),children:c.group.children.length}})()")
    coords = [(s["x"], s["z"]) for s in restored["sticks"]]
    separated = all(((x-y)**2 + (z-w)**2)**0.5 > 0.035 for i,(x,z) in enumerate(coords) for y,w in coords[:i])
    report("復訪後新香不重疊", restored["total"] == 3 and len(coords) == 3 and separated and not errors, {"state": restored, "distinct_positions": separated, "errors": errors})
    browser.close()

    # Regression: rapid re-entry during an active ceremony must be acknowledged, not silently dropped.
    browser, page, errors = open_temple(p)
    page.evaluate("MM.pause(); MM.teleport(0,-6.9,Math.PI,0)")
    page.evaluate("document.getElementById('incBtn').click()")
    page.wait_for_timeout(80)
    page.evaluate("document.getElementById('incThree').click()")
    for _ in range(20):
        if page.evaluate("MM.Incense.isBusy()"):
            break
        page.wait_for_timeout(100)
    busy_started = page.evaluate("MM.Incense.isBusy()")
    page.evaluate("document.getElementById('incBtn').click()")
    feedback = page.evaluate("({toast:document.getElementById('toast').textContent,sheetOpen:document.getElementById('sheet').classList.contains('open')})")
    page.evaluate("MM.resume()")
    for _ in range(240):
        if not page.evaluate("MM.Incense.isBusy()"):
            break
        page.wait_for_timeout(150)
    result = page.evaluate("({busy:MM.Incense.isBusy(),totals:Object.fromEntries(MM.Incense.censers.map(c=>[c.id,c.total])),toast:document.getElementById('toast').textContent})")
    good_feedback = any(word in feedback["toast"] for word in ("進行", "稍候", "上香")) and not feedback["sheetOpen"]
    report("連續點擊有進行中提示且不重複執行", busy_started and good_feedback and result["totals"].get("main") == 3 and "正殿主爐" in result["toast"] and not errors,
           {"busy_started": busy_started, "feedback": feedback, "completed": result, "errors": errors})
    browser.close()

    # Regression: censer smoke density survives the render loop; each new stick grows into view.
    browser, page, errors = open_temple(p)
    page.evaluate("MM.pause(); MM.Incense.offer('main',1)")
    immediate = page.evaluate("({smoke:MM.Incense.byId('main').smoke.points.material.opacity,scale:MM.Incense.burning[0].mesh.scale.y})")
    page.wait_for_function("(()=>{const o=MM.Incense.burning[0];return o && o.mesh.scale.y >= o.h*.95})()", timeout=3000)
    settled = page.evaluate("({smoke:MM.Incense.byId('main').smoke.points.material.opacity,scale:MM.Incense.burning[0].mesh.scale.y,h:MM.Incense.burning[0].h})")
    report("煙霧增幅保留、香枝有落爐動畫", settled["smoke"] > 0.18 and settled["scale"] >= settled["h"] * 0.95 and not errors,
           {"immediate": immediate, "after_animation": settled, "errors": errors})
    browser.close()

print("RESULT", "ALL PASS" if not failures else "FAILED: " + ",".join(failures))
raise SystemExit(bool(failures))
