from playwright.sync_api import sync_playwright
import json, sys, time
BASE=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8899/'
with sync_playwright() as p:
 b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
 pg=b.new_context(viewport={'width':900,'height':700},device_scale_factor=.35).new_page(); pg.route('**/sw.js',lambda r:r.abort())
 pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
 errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
 pg.goto(BASE,wait_until='load');pg.wait_for_timeout(1500);pg.locator('#enterBtn').click();pg.wait_for_timeout(3500)
 pg.evaluate("MM.teleport(0,7.6,Math.PI,0);document.getElementById('incBtn').click()")
 pg.wait_for_function("document.getElementById('sheet').classList.contains('open')")
 pg.evaluate("document.getElementById('incThree').click()")
 pg.wait_for_function("MM._.player.z < 7.5",timeout=15000)
 state=pg.evaluate("({start:7.6,z:MM._.player.z,busy:MM.Incense.isBusy(),phase:MM.Incense.phase()})")
 assert state['busy'] and state['phase']=='traveling',state
 assert abs(state['z']-7.6)<2.5,('teleport detected',state)
 print('PASS walking begins without teleport',json.dumps(state))
 b.close()
print('RESULT ALL PASS')
