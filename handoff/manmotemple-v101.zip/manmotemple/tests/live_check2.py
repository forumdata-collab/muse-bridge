from playwright.sync_api import sync_playwright
import os, math
BASE='https://handcraftstudio.eu.org/manmotemple/'
OUT='/home/ubuntu/.hermes/cache/scratch/live2/'
os.makedirs(OUT, exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=livebb',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=120000)
    pg.wait_for_timeout(2500)
    print(pg.evaluate("""(() => {
      const U=MM._;
      const head=new THREE.Vector3(0,1.9,1.0).applyMatrix4(U.deer.matrixWorld);
      const tail=new THREE.Vector3(0,1.1,-.86).applyMatrix4(U.deer.matrixWorld);
      return {deerRot:U.deer.rotation.y, headZ:+head.z.toFixed(2), tailZ:+tail.z.toFixed(2),
              bell:[U.stations.bell.x,U.stations.bell.z], drum:[U.stations.drum.x,U.stations.drum.z],
              donate:[U.stations.donate.x,U.stations.donate.z]};
    })()"""))
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    for name,x,z,yaw,pitch in [('entry',0,9.6,3.14159,-.02),
                               ('pair',4.6,9.2,math.atan2(9.2-4.6,3.7-9.2),-.02),
                               ('donate',-8.6,8.4,0,-.05)]:
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)",[x,z,yaw,pitch])
        pg.wait_for_timeout(800); pg.evaluate("MM.pause()"); pg.wait_for_timeout(350)
        pg.screenshot(path=OUT+name+'.png',timeout=120000); pg.evaluate("MM.resume()")
        print('shot',name)
    print('ERR',errs)
    b.close()
