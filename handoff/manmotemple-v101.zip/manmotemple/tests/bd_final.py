from playwright.sync_api import sync_playwright
import os, math
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/bd/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=bd4',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2200)
    print(pg.evaluate("({deerRot:MM._.deer.rotation.y})"))
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    shots=[('entry2',0,9.6,3.14159,-.02), ('deer2',0,5.6,3.14159,-.07)]
    x,z=4.6,9.2
    shots.append(('pair', x, z, math.atan2(9.2-x,3.7-z), -.02))
    shots.append(('donate3', -8.6, 8.4, 0, -.05))
    for name,x,z,yaw,pitch in shots:
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)",[x,z,yaw,pitch])
        pg.wait_for_timeout(800); pg.evaluate("MM.pause()"); pg.wait_for_timeout(350)
        pg.screenshot(path=OUT+name+'.png',timeout=120000); pg.evaluate("MM.resume()")
        print('shot',name)
    print('ERR',errs)
    b.close()
