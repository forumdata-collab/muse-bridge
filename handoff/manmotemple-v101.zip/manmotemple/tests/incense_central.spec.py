from playwright.sync_api import sync_playwright
import sys,json
BASE=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8899/'
with sync_playwright() as p:
 b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
 pg=b.new_page(viewport={'width':390,'height':844},device_scale_factor=.35)
 errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.route('**/sw.js*',lambda r:r.abort())
 pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
 pg.goto(BASE,wait_until='load');pg.locator('#enterBtn').click();pg.wait_for_timeout(2000)
 pg.evaluate('''MM.teleport(0,7.6,Math.PI,0);window.samples=[];window.bows=[];var original=MM.bow;MM.bow=function(){bows.push({x:MM._.player.x,z:MM._.player.z,t:performance.now(),total:MM.Incense.byId('main').total});original()};window.timer=setInterval(()=>{var h=MM._.camera.getObjectByName('ritual-held-incense');samples.push({x:MM._.player.x,z:MM._.player.z,y:MM._.camera.position.y,yaw:MM._.player.yaw,t:performance.now(),phase:MM.Incense.phase(),held:!!(h&&h.visible),total:MM.Incense.byId('main').total})},25);document.getElementById('incBtn').click()''')
 pg.wait_for_function("document.getElementById('sheet').classList.contains('open')")
 pg.evaluate("document.getElementById('incThree').click()")
 pg.wait_for_function('MM.Incense.isBusy()');pg.wait_for_function('!MM.Incense.isBusy()',timeout=120000)
 r=pg.evaluate('''(()=>{clearInterval(timer);return {samples,bows,main:MM.Incense.byId('main').total,front:MM.Incense.byId('front').total,held:MM._.camera.getObjectByName('ritual-held-incense').visible}})()''')
 assert r['main']==3 and r['front']==0 and not r['held'] and not errors,(r,errors)
 assert len(r['bows'])==3,r['bows']
 assert all(abs(s['yaw']-3.141592653589793)<.01 for s in r['samples'])
 for i,bow in enumerate(r['bows']):
  assert abs(bow['x'])<.05 and -1.7<bow['z']<-1.5 and bow['total']==0,bow
  end=r['bows'][i+1]['t'] if i+1<len(r['bows']) else float('inf')
  frames=[s for s in r['samples'] if bow['t']<=s['t']<end and s['total']==0]
  assert min(s['y'] for s in frames)<1.2 and max(s['y'] for s in frames)>1.5,frames
  assert all(abs(s['x']-bow['x'])<.01 and abs(s['z']-bow['z'])<.01 for s in frames)
 print('PASS central position; 3 complete stationary bows before insertion; altar-facing; main=3/front=0; errors=0',json.dumps(r['bows']))
 b.close()
