"""跪拜善信回歸測試：姿態幾何、完整循環、相位交錯、root 靜止、優化器不吞肢體。

執行：/home/ubuntu/doubao2api/.venv/bin/python tests/npc_kneel.spec.py [base_url]
輸出：截圖／錄影到 /home/ubuntu/.hermes/cache/scratch/manmo-kneel/
"""
from playwright.sync_api import sync_playwright
import sys, os, json, math

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8899/'
OUT = '/home/ubuntu/.hermes/cache/scratch/manmo-kneel'
os.makedirs(OUT, exist_ok=True)
ARGS = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader']
PARTS = ['thighL', 'thighR', 'shinL', 'shinR', 'footL', 'footR', 'pelvis', 'skirt',
         'torso', 'neckCol', 'headBall', 'handL', 'handR', 'upperArmL', 'foreArmL']
# 關節相連（AABB 相交或間隙 < 3cm）：證明下蹲／躬身時全身仍然連住
JOINTS = [('thighL', 'shinL'), ('thighR', 'shinR'), ('shinL', 'footL'), ('shinR', 'footR'),
          ('thighL', 'pelvis'), ('thighR', 'pelvis'), ('torso', 'pelvis'),
          ('neckCol', 'torso'), ('headBall', 'neckCol'),
          ('upperArmL', 'foreArmL'), ('foreArmL', 'handL'), ('upperArmL', 'torso')]


def gap(a, b):
    """兩 AABB 在每個軸上的最大間隙（負值代表重疊）"""
    return max(max(a['min'][k] - b['max'][k], b['min'][k] - a['max'][k]) for k in range(3))

SAMPLE_JS = """
(() => {
  const T = THREE, U = MM._;
  const bb = o => { const b = new T.Box3().setFromObject(o);
    return {min:[b.min.x,b.min.y,b.min.z], max:[b.max.x,b.max.y,b.max.z]}; };
  const names = %s;
  const out = [];
  const missing = [];
  const roots = [];
  for (let i = 0; i < U.kneelers.length; i++) {
    const g = U.kneelers[i];
    roots.push({i:i, pos:[g.position.x,g.position.y,g.position.z], ry:g.rotation.y,
                userDataDynamic: !!g.userData.dynamic});
    for (let k = 0; k <= 36; k++) {
      const t = k * 0.25;                       // 0..9s 完整循環
      const kv = MM.poseKneelingVisitor(i, t);
      g.updateMatrixWorld(true);
      const parts = {};
      names.forEach(n => { const o = g.getObjectByName(n); if (!o) { missing.push(i+':'+n); return; } parts[n] = bb(o); });
      out.push({i:i, t:t, k:kv, pos:[g.position.x,g.position.y,g.position.z], ry:g.rotation.y,
        hip:+g.userData.rig.hip.rotation.x.toFixed(4),
        spine:+g.userData.rig.spine.rotation.x.toFixed(4),
        neck:+g.userData.rig.neck.rotation.x.toFixed(4),
        head:+g.userData.rig.head.rotation.x.toFixed(4), parts:parts});
    }
    // 決定性：同一時間再算一次
    const a = MM.poseKneelingVisitor(i, 2.13), sa = g.userData.rig.spine.rotation.x;
    const b = MM.poseKneelingVisitor(i, 2.13), sb = g.userData.rig.spine.rotation.x;
    out.push({i:i, t:2.13, k:a, repeatK:b, repeatSpine:[sa, sb], parts:{}});
  }
  const st = U.npcs[2];
  return {samples: out, missing: missing, roots: roots,
          nKneelers: U.kneelers.length, nNpcs: U.npcs.length,
          meshCount: U.kneelers.map(g => { let n = 0; g.traverse(o => { if (o.isMesh) n++; }); return n; }),
          optStats: MM.optStats || null,
          standing: {pos:[st.position.x, st.position.y, st.position.z], ry: st.rotation.y,
                     ph: st.userData.ph !== undefined, kneel: !!st.userData.kneel}};
})()
""" % json.dumps(PARTS)


def check_cycle(d, tag):
    assert d['missing'] == [], ('limbs swallowed by optimizer', d['missing'])
    assert d['meshCount'] == [18, 18], ('optimizer absorbed limb meshes', d['meshCount'])
    assert d['nNpcs'] == 3 and d['nKneelers'] == 2, d
    assert d['standing']['ph'] and not d['standing']['kneel'], d['standing']
    assert abs(d['standing']['pos'][0] - 4.6) < 1e-6 and abs(d['standing']['pos'][2] - 6.0) < 1e-6, d['standing']
    assert all(r['pos'][1] == 0 and abs(r['pos'][0]) == 2.2 and abs(r['pos'][2] - (-2.5)) < 1e-9 and r['ry'] == 0
               and r['userDataDynamic'] for r in d['roots']), d['roots']

    by_i = {0: [], 1: []}
    for s in d['samples']:
        if s['parts']:
            by_i[s['i']].append(s)

    for i, samples in by_i.items():
        assert len(samples) == 37, (tag, i, len(samples))
        # root 靜止
        assert len({tuple(round(v, 6) for v in s['pos']) + (round(s['ry'], 6),) for s in samples}) == 1, (tag, i)
        # 腳／膝全程貼墊：小腿、腳掌、大腿下端高度穩定且在墊面上
        for n in ('footL', 'footR'):
            ys = [s['parts'][n]['min'][1] for s in samples]
            assert 0.09 < min(ys) and max(ys) < 0.17, (tag, i, n, min(ys), max(ys))
            assert max(ys) - min(ys) < 0.01, (tag, i, n, 'legs moved', min(ys), max(ys))
        for n in ('shinL', 'shinR'):
            ys = [s['parts'][n]['min'][1] for s in samples]
            assert 0.08 < min(ys) and max(ys) < 0.18 and max(ys) - min(ys) < 0.005, (tag, i, n, min(ys), max(ys))
        for n in ('thighL', 'thighR'):
            ys = [s['parts'][n]['min'][1] for s in samples]
            assert 0.08 < min(ys) and max(ys) < 0.18, (tag, i, n, min(ys), max(ys))
        # 關節相連：大腿上端接臀部（臀部低點不高於大腿頂太多），無斷肢
        for s in samples:
            p = s['parts']
            for a, c in JOINTS:
                g = gap(p[a], p[c])
                assert g < 0.03, (tag, i, s['t'], 'detached', a, c, round(g, 3))
            assert p['thighL']['max'][1] > p['torso']['min'][1] - 0.02, (tag, i, 'thigh/hip gap')
            assert p['shinL']['max'][1] > p['thighL']['min'][1] - 0.12, (tag, i, 'knee gap')
            # 頭／手全程離地
            assert p['headBall']['min'][1] > 0.55, (tag, i, s['t'], 'head low', p['headBall']['min'][1])
            assert p['handL']['min'][1] > 0.25 and p['handR']['min'][1] > 0.25, (tag, i, s['t'], 'hands low')
            # 全部留在拜墊範圍（1.24 x 1.18，中心 ±2.2,-2.5）
            for n, b in p.items():
                cx = (b['min'][0] + b['max'][0]) / 2
                cz = (b['min'][2] + b['max'][2]) / 2
                assert abs(cx - (2.2 if i == 1 else -2.2)) < 0.62, (tag, i, s['t'], n, 'x out', cx)
                assert abs(cz + 2.5) < 0.59, (tag, i, s['t'], n, 'z out', cz)
            # 中央通道保持淨空 / 遠離香案與主爐（香案前沿 z=-6.05）
            inner = p['torso']['max'][0] if i == 0 else p['torso']['min'][0]
            assert abs(inner) > 1.45, (tag, i, 'aisle', inner)
            assert p['torso']['min'][2] > -4.2 and p['headBall']['min'][2] > -4.2, (tag, i, 'too near 香案')
            assert p['headBall']['min'][2] - (-6.05) > 1.5, (tag, i, 'censer/table gap')
        # 分節角度有變化，且係輕躬非五體投地
        sp = [s['spine'] for s in samples]
        nk = [s['neck'] for s in samples]
        hd = [s['head'] for s in samples]
        hp = [s['hip'] for s in samples]
        assert max(sp) - min(sp) > 0.30, (tag, i, 'spine static', min(sp), max(sp))
        assert max(nk) - min(nk) > 0.06 and max(hd) - min(hd) > 0.03, (tag, i, 'neck/head static')
        assert max(hp) - min(hp) > 0.05, (tag, i, 'hip static')
        total = -min(sp) - min(nk) - min(hd) - min(hp)
        assert 0.7 < total < 1.15, (tag, i, 'bow not gentle', total)
        # 頭在下躬時下降但唔貼地
        lo = min(samples, key=lambda s: s['parts']['headBall']['min'][1])
        hi = max(samples, key=lambda s: s['parts']['headBall']['min'][1])
        assert hi['parts']['headBall']['min'][1] - lo['parts']['headBall']['min'][1] > 0.08, (tag, i, 'head no motion')

    # 相位交錯：一位躬身時另一位休息
    k0 = {round(s['t'], 2): s['k'] for s in by_i[0]}
    k1 = {round(s['t'], 2): s['k'] for s in by_i[1]}
    assert any(k0[t] > 0.6 and k1[t] < 0.05 for t in k0), (tag, 'no anti-phase A')
    assert any(k1[t] > 0.6 and k0[t] < 0.05 for t in k0), (tag, 'no anti-phase B')

    # 決定性
    for s in d['samples']:
        if 'repeatK' in s:
            assert abs(s['k'] - s['repeatK']) < 1e-9, (tag, 'non-deterministic')
            assert abs(s['repeatSpine'][0] - s['repeatSpine'][1]) < 1e-9, (tag, 'non-deterministic spine')
    print('PASS %s: 2 kneelers, arms/legs intact after optimizeStatic (meshes=%s, optStats=%s)'
          % (tag, d['meshCount'], json.dumps(d['optStats'])))


with sync_playwright() as pw:
    browser = pw.chromium.launch(channel='chromium', args=ARGS)

    # ---------- 邏輯 + 幾何：兩個 viewport ----------
    for w, h in ((390, 844), (900, 700)):
        pg = browser.new_page(viewport={'width': w, 'height': h}, device_scale_factor=0.35)
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.route('**/sw.js*', lambda r: r.abort())
        pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
        pg.goto(BASE, wait_until='load')
        pg.locator('#enterBtn').click()
        pg.wait_for_function('window.MM && MM._ && MM._.kneelers && MM._.kneelers.length===2', timeout=60000)
        pg.wait_for_timeout(1200)
        data = pg.evaluate(SAMPLE_JS)
        check_cycle(data, 'vp%d' % w)
        assert not errs, errs
        pg.close()

    # ---------- 截圖（scale 1） ----------
    pg = browser.new_page(viewport={'width': 900, 'height': 700}, device_scale_factor=1)
    pg.route('**/sw.js*', lambda r: r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE, wait_until='load')
    pg.locator('#enterBtn').click()
    pg.wait_for_function('window.MM && MM._ && MM._.kneelers && MM._.kneelers.length===2', timeout=60000)
    pg.evaluate("document.getElementById('loader').classList.add('done')")

    def shot(name, x, z, yaw, pitch, t=1.8):
        pg.evaluate('(()=>{MM.poseKneelingVisitor(0,%f);MM.poseKneelingVisitor(1,%f);'
                    'MM.pause&&0;MM.teleport(%f,%f,%f,%f)})()' % (t, t + 1.0, x, z, yaw, pitch))
        pg.wait_for_timeout(900)
        pg.screenshot(path=os.path.join(OUT, name), timeout=90000)

    # 正面（面向神壇，鏡頭喺神壇一側回望）
    shot('kneel-front-900.png', 2.2, -4.9, 0.0, -0.22, 2.2)
    # 側面（中央通道望向右側善信）
    shot('kneel-side-900.png', -0.15, -2.5, math.pi / 2, -0.15, 2.2)
    # 兩位同時可見（由入口方向望入，即用戶實際動線）
    shot('kneel-pair-900.png', 0, 2.6, math.pi, -0.10, 2.2)
    # 後側 3/4
    shot('kneel-rear-900.png', 1.0, 1.7, math.pi * 0.97, -0.10, 2.2)
    # 近鏡：合十與折腿
    shot('kneel-close-900.png', 2.2, -3.85, 0.0, -0.34, 2.4)
    pg.set_viewport_size({'width': 390, 'height': 844})
    shot('kneel-front-390.png', 2.2, -4.35, 0.0, -0.24, 2.2)
    pg.close()

    # ---------- 短錄影：完整一個循環（webm） ----------
    ctx = browser.new_context(viewport={'width': 900, 'height': 620},
                              record_video_dir=OUT, record_video_size={'width': 900, 'height': 620})
    vp = ctx.new_page()
    vp.route('**/sw.js*', lambda r: r.abort())
    vp.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    vp.goto(BASE, wait_until='load')
    vp.locator('#enterBtn').click()
    vp.wait_for_function('window.MM && MM._ && MM._.kneelers && MM._.kneelers.length===2', timeout=60000)
    vp.evaluate("document.getElementById('loader').classList.add('done');MM.teleport(0,2.6,Math.PI,-0.10)")
    vp.wait_for_timeout(9500)
    video = vp.video.path()
    ctx.close()
    target = os.path.join(OUT, 'kneel-cycle.webm')
    if os.path.exists(target):
        os.remove(target)
    os.replace(video, target)
    print('video:', target)
    browser.close()

print(json.dumps({'screenshots': sorted(f for f in os.listdir(OUT) if f.endswith('.png'))}))
print('ALL PASS')
