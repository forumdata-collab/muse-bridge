from playwright.sync_api import sync_playwright
import os
BASE='https://handcraftstudio.eu.org/manmotemple/'
OUT='/home/ubuntu/.hermes/cache/scratch/live/'
os.makedirs(OUT, exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    ctx=b.new_context(viewport={'width':430,'height':900},device_scale_factor=1)
    pg=ctx.new_page()
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=live1',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=120000)
    pg.wait_for_timeout(2500)
    info=pg.evaluate("({stations:Object.keys(MM._.stations),deer:[MM._.stations.deer.x,MM._.stations.deer.z],sidehall:!!MM._.stations.sidehall,legend:document.getElementById('hallName').textContent})")
    print('LIVE',info)
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    pg.evaluate("MM.teleport(0,9.6,Math.PI,-.02)"); pg.wait_for_timeout(900)
    pg.evaluate("MM.pause()"); pg.wait_for_timeout(400)
    pg.screenshot(path=OUT+'live_entry.png',timeout=120000); pg.evaluate("MM.resume()")
    print('shot live_entry')
    print('ERR',errs)
    b.close()
