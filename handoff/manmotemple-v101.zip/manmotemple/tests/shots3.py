from playwright.sync_api import sync_playwright
import json, os, time, sys
BASE = 'http://127.0.0.1:8899/'
OUT = '/home/ubuntu/.hermes/cache/scratch/shots3/'
os.makedirs(OUT, exist_ok=True)
log = open('/tmp/layout_report.txt','w',encoding='utf-8')
def L(*a):
    s=' '.join(str(x) for x in a); print(s); log.write(s+'\n'); log.flush()

with sync_playwright() as p:
    b = p.chromium.launch(channel='chromium', args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg = b.new_page(viewport={'width':430,'height':860}, device_scale_factor=1)
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('**/sw.js*', lambda r: r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=layout5', wait_until='load')
    pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)', timeout=90000)
    pg.wait_for_timeout(2500)
    pg.evaluate("document.getElementById('hz')&&document.getElementById('hz').remove();document.getElementById('loader')&&document.getElementById('loader').classList.add('done');1")

    def shot(name, x, z, yaw, pitch=-.03):
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)", [x,z,yaw,pitch])
        pg.wait_for_timeout(800)
        pg.evaluate("MM.pause()")
        pg.wait_for_timeout(400)
        pg.screenshot(path=OUT+name+'.png', timeout=120000)
        pg.evaluate("MM.resume()")
        L('shot', name)

    shot("entry", 0, 9.6, 3.14159, -.01)
    shot("deer", 0, 5.6, 3.14159, -.06)
    shot("censer_steps", 0, -3.4, 3.14159, -.09)
    shot("on_platform", 0, -8.9, 3.14159, -.02)
    shot("leftwall", 3.0, -2.0, -1.5708, -.02)
    shot("total", 0, -3.4, 3.14159, -.5)

    # 向前行：由出生點直行，應繞過金鹿
    pg.evaluate("MM.teleport(0,7.6,Math.PI,0); MM.setJoy(0,-1); 1")
    trace=[]
    for i in range(20):
        time.sleep(.35)
        trace.append(pg.evaluate("[+MM._.player.x.toFixed(2), +MM._.player.z.toFixed(2), +(MM._.groundY||0).toFixed(2)]"))
    pg.evaluate("MM.setJoy(0,0); 1")
    L('WALK', json.dumps(trace))
    L('ERR', json.dumps(errs))
    b.close()
log.close()
