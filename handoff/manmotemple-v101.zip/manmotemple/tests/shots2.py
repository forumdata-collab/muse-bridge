from playwright.sync_api import sync_playwright
import json, os, time
BASE = 'http://127.0.0.1:8899/'
OUT = '/home/ubuntu/.hermes/cache/scratch/shots2/'
os.makedirs(OUT, exist_ok=True)

with sync_playwright() as p:
    b = p.chromium.launch(channel='chromium', args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg = b.new_page(viewport={'width':430,'height':860}, device_scale_factor=1)
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('**/sw.js*', lambda r: r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=layout4', wait_until='load')
    pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)', timeout=90000)
    pg.wait_for_timeout(2500)
    pg.evaluate("document.getElementById('hz')&&document.getElementById('hz').remove();document.getElementById('loader')&&document.getElementById('loader').classList.add('done');1")

    def shot(name, x, z, yaw, pitch=-.03):
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)", [x,z,yaw,pitch])
        pg.wait_for_timeout(900)
        pg.evaluate("MM.pause()")
        pg.wait_for_timeout(400)
        pg.screenshot(path=OUT+name+'.png', timeout=120000)
        pg.evaluate("MM.resume()")
        print('shot', name)

    shot("entry", 0, 9.2, 3.14159, -.01)
    shot("deer_front", 0, 5.4, 3.14159, -.05)
    shot("deer_side", 3.6, 3.0, -2.35, -.04)
    shot("censer", 0, -0.6, 3.14159, -.07)
    shot("steps", 0, -4.6, 3.14159, -.02)
    shot("leftwall", 2.0, -4.0, -1.5708, -.02)
    shot("topdown", 0, -4.0, 3.14159, -.55)

    # 向前行測試：由出生點一路向前，應繞過金鹿
    pg.evaluate("MM.teleport(0,7.6,Math.PI,0); MM.setJoy(0,-1); 1")
    trace=[]
    for i in range(24):
        time.sleep(.35)
        trace.append(pg.evaluate("[+MM._.player.x.toFixed(2), +MM._.player.z.toFixed(2)]"))
    pg.evaluate("MM.setJoy(0,0); 1")
    print('WALK', json.dumps(trace))
    print('ERR', errs)
    b.close()
