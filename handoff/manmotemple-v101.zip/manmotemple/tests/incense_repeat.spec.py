from playwright.sync_api import sync_playwright
import json, sys, time
BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8899/'
with sync_playwright() as p:
    b = p.chromium.launch(channel='chromium', args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    ctx = b.new_context(viewport={'width':390,'height':844}, device_scale_factor=.35)
    ctx.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg = ctx.new_page(); pg.route('**/sw.js',lambda r:r.abort())
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto(BASE,wait_until='load'); pg.wait_for_timeout(1300)
    pg.locator('#enterBtn').click(); pg.wait_for_timeout(4000)
    pg.evaluate('MM.teleport(0,-6.9,Math.PI,0)')
    for nth in range(3):
        pg.evaluate("document.getElementById('incBtn').click()")
        pg.wait_for_function("document.getElementById('sheet').classList.contains('open')",timeout=5000)
        pg.evaluate("document.getElementById('incThree').click()")
        for _ in range(70):
            if pg.evaluate('MM.Incense.isBusy()'): break
            pg.wait_for_timeout(100)
        assert pg.evaluate('MM.Incense.isBusy()'), 'ceremony did not start'
        for _ in range(180):
            if not pg.evaluate('MM.Incense.isBusy()'): break
            pg.wait_for_timeout(250)
        assert not pg.evaluate('MM.Incense.isBusy()'), 'ceremony stuck'
        values=pg.evaluate("({n:MM.Incense.byId('main').total,sticks:MM.Incense.burning.filter(o=>o.c.id==='main').length,children:MM.Incense.byId('main').group.children.length})")
        assert values['n']==(nth+1)*3, values
        assert values['sticks']==values['n'], values
        print('PASS consecutive rite',nth+1,json.dumps(values))
    pg.evaluate("MM.Incense.offer('main',50)")
    capped=pg.evaluate("({n:MM.Incense.byId('main').total,sticks:MM.Incense.burning.filter(o=>o.c.id==='main').length,children:MM.Incense.byId('main').group.children.length,indices:MM.Incense.burning.filter(o=>o.c.id==='main').map(o=>o.i)})")
    assert capped['n']==39 and capped['sticks']==30 and capped['children']==90, capped
    print('PASS capped repeated offers',json.dumps({k:v for k,v in capped.items() if k!='indices'}))
    assert not errs,errs
    b.close()
print('RESULT ALL PASS')
