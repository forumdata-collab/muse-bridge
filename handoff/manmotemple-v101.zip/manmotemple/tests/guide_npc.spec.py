"""廟祝（虛擬導賞員）驗收：實體 NPC 點擊、鄰近互動、三主題內容、自願帶位、語音不自動播、BGM  duck／回復、跪拜善信不變。

執行：/home/ubuntu/doubao2api/.venv/bin/python tests/guide_npc.spec.py [base_url]
輸出：PASS 行；截圖 /home/ubuntu/.hermes/cache/scratch/manmo-guide/guide-900.png
"""
from playwright.sync_api import sync_playwright
import sys, os, json, math

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8899/'
OUT = '/home/ubuntu/.hermes/cache/scratch/manmo-guide'
os.makedirs(OUT, exist_ok=True)
ARGS = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader',
        '--autoplay-policy=no-user-gesture-required']

BOOT = """window.MM && MM._ && MM._.kneelers && MM._.kneelers.length===2 && MM.guideNPC && MM.guideNPC.node"""

def npc_screen(pg):
    return pg.evaluate("""(() => {
      const T = THREE, g = MM.guideNPC.node, cam = MM._.camera;
      const p = new T.Vector3(); g.getObjectByName('headBall').getWorldPosition(p);
      const v = p.clone().project(cam);
      const r = MM._.renderer.domElement.getBoundingClientRect();
      return {x: r.left + (v.x + 1) / 2 * r.width, y: r.top + (1 - v.y) / 2 * r.height,
              on: v.z > -1 && v.z < 1 && Math.abs(v.x) < 1 && Math.abs(v.y) < 1,
              world: [p.x, p.y, p.z]};
    })()""")

def player(pg):
    return pg.evaluate("(() => { const p = MM._.player; return {x:p.x, z:p.z, yaw:p.yaw}; })()")

def panel_text(pg):
    return pg.evaluate("document.getElementById('gmPanel') ? document.getElementById('gmPanel').innerText : ''")

def open_panel(pg):
    if not pg.evaluate("MM.guideNPC.isOpen()"):
        pg.evaluate("MM.guideNPC.open()")
    pg.wait_for_function("document.getElementById('gmPanel').classList.contains('open')", timeout=5000)

def choose(pg, idx):
    pg.evaluate("document.querySelectorAll('#gmTopics [data-t]')[%d].click()" % idx)
    pg.wait_for_timeout(120)

def check(pg, tag, errs):
    # ---------- 1. 廟祝模型：短褂 + 深褲，無道袍 ----------
    model = pg.evaluate("""(() => {
      const g = MM.guideNPC.node, mats = {};
      g.traverse(o => { if (o.isMesh && o.name) mats[o.name] = '#' + o.material.color.getHexString(); });
      let meshes = 0; g.traverse(o => { if (o.isMesh) meshes++; });
      const b = new THREE.Box3().setFromObject(g);
      return {mats, meshes, minY: b.min.y, maxY: b.max.y,
              jacket: !!g.getObjectByName('jacket'), placket: !!g.getObjectByName('placket'),
              robe: !!g.getObjectByName('robe'), dynamic: !!g.userData.dynamic,
              guide: !!g.userData.guide, kneel: !!g.userData.kneel,
              pos: [g.position.x, g.position.y, g.position.z]};
    })()""")
    assert model['guide'] and not model['kneel'] and model['dynamic'], model
    assert model['jacket'] and model['placket'] and not model['robe'], model
    assert model['mats'].get('jacket') == '#33475b', model['mats']   # 平口素短褂
    assert model['mats'].get('thighL') == '#1c2026', model['mats']   # 深色長褲
    assert model['meshes'] >= 15 and 1.6 < model['maxY'] < 1.9 and model['minY'] >= -0.02, model
    assert abs(model['pos'][0] - 4.6) < 1e-6 and abs(model['pos'][2] - 6.0) < 1e-6, model['pos']
    print('PASS %s 廟祝外觀：短褂/深褲、%d meshes、高 %.2fm、站位 (4.6,6.0)'
          % (tag, model['meshes'], model['maxY'] - model['minY']))

    # ---------- 2. 走到廟祝前面，實際用滑鼠點渲染出的 NPC ----------
    pg.evaluate("MM.teleport(3.0, 4.0, Math.atan2(4.6-3.0, 6.0-4.0), 0.02)")
    pg.wait_for_timeout(500)
    scr = npc_screen(pg)
    assert scr['on'], ('npc not on screen', scr)
    # 拖曳守衛：在畫面中央拖 40px 不應開面板（拖曳會轉視角，之後重新投影 NPC）
    pg.mouse.move(195, 330)
    pg.mouse.down()
    pg.mouse.move(235, 336, steps=4)
    pg.mouse.up()
    pg.wait_for_timeout(300)
    assert not pg.evaluate("MM.guideNPC.isOpen()"), 'drag opened the guide panel'
    scr = npc_screen(pg)
    assert scr['on'], ('npc not on screen after drag', scr)
    before = player(pg)
    # 真點擊
    pg.mouse.click(scr['x'], scr['y'])
    pg.wait_for_function("MM.guideNPC.isOpen() && document.getElementById('gmPanel').classList.contains('open')", timeout=5000)
    after = player(pg)
    assert abs(after['x'] - before['x']) < 0.01 and abs(after['z'] - before['z']) < 0.01 \
        and abs(after['yaw'] - before['yaw']) < 0.01, ('camera forced move on open', before, after)
    # 面向玩家 + 點頭
    pg.wait_for_function("MM.guideNPC.facingDot() > 0.85", timeout=5000)
    pg.wait_for_timeout(200)
    print('PASS %s 實體點擊：拖曳守衛有效、點 NPC 開面板、鏡頭未移動、面向玩家 dot=%.3f'
          % (tag, pg.evaluate("MM.guideNPC.facingDot()")))

    # ---------- 3. 標籤 + 三主題 + 不自動播音 ----------
    txt = panel_text(pg)
    assert '虛擬' in txt and '非官方' in txt and '預錄腳本' in txt, txt
    assert pg.evaluate("document.querySelectorAll('#gmTopics [data-t]').length") == 3
    vs = pg.evaluate("MM.guideNPC.voiceState()")
    assert vs['playing'] is False and vs['paused'] is True and vs['speech'] is False and (vs['currentTime'] or 0) == 0, ('autoplay on open', vs)
    assert pg.get_attribute('#gmPanel', 'role') == 'dialog'
    assert pg.get_attribute('#gmVoice', 'aria-pressed') == 'false'
    print('PASS %s 開啟：虛擬/非官方標籤、3 個主題、無自動語音' % tag)

    # ---------- 4. 三個固定腳本內容 ----------
    choose(pg, 0)
    h = panel_text(pg)
    for must in ['一八四七至一八六二年', '一九〇八', '東華', '公所', '二〇一〇', '法定古蹟', '古物古蹟辦事處']:
        assert must in h, ('history missing', must, h)
    assert '建於一八四七年，' not in h, 'old wrong single-year claim still present'
    choose(pg, 1)
    r = panel_text(pg)
    for must in ['天公爐', '三炷', '聖筊', '一正一反', '以廟方告示為準', '簡化互動']:
        assert must in r, ('rite missing', must, r)
    choose(pg, 2)
    t = panel_text(pg)
    for must in ['正殿神壇', '金鹿', '立地大香爐', '帶我過去']:
        assert must in t, ('tour missing', must, t)
    places = pg.evaluate("Array.from(document.querySelectorAll('#gmTopics ~ * [data-place], #gmPanel [data-place]')).map(b => b.getAttribute('data-place'))")
    assert places == ['altar', 'deer'], places
    vs2 = pg.evaluate("MM.guideNPC.voiceState()")
    assert vs2['playing'] is False and vs2['speech'] is False, ('autoplay on topic change', vs2)
    print('PASS %s 三主題內容正確（歷史 1847–1862／1908／2010；禮儀標明以現場為準；帶位 3 處）' % tag)

    # ---------- 5. 自願帶位：走真實 setCam 路徑，核對 app 站點目標 ----------
    exp = pg.evaluate("""(() => { const o = {}; ['altar','deer'].forEach(k => {
        const s = MM._.stations[k], d = {altar:2.5, deer:2.4}[k];
        o[k] = {x: s.x - Math.sin(s.face)*d, z: s.z - Math.cos(s.face)*d, yaw: s.face,
                sx: s.x, sz: s.z}; }); return o; })()""")
    for key in ('altar', 'deer'):
        pg.evaluate("MM.teleport(3.0, 4.0, Math.atan2(1.6, 2.0), 0.02)")
        pg.wait_for_timeout(300)
        open_panel(pg)
        choose(pg, 2)
        pg.evaluate("document.querySelector('#gmPanel [data-place=\"%s\"]').click()" % key)
        pg.wait_for_timeout(300)
        assert not pg.evaluate("MM.guideNPC.isOpen()"), ('panel not closed on travel', key)
        lt = pg.evaluate("MM.guideNPC.lastTravel()")
        assert lt['key'] == key and lt['station'] == key, (key, lt)
        e = exp[key]
        assert abs(lt['target'][0] - e['x']) < 1e-6 and abs(lt['target'][1] - e['z']) < 1e-6, (key, lt, e)
        pg.wait_for_function("(e => { const p = MM._.player; return Math.hypot(p.x-e.x, p.z-e.z) < 0.06; })(%s)"
                             % json.dumps({'x': e['x'], 'z': e['z']}), timeout=60000)
        p = player(pg)
        dyaw = abs(((p['yaw'] - e['yaw'] + math.pi * 3) % (math.pi * 2)) - math.pi)
        assert dyaw < 0.03, (key, 'yaw', p, e)
        # 站點距離合理：不是傳送到神像內
        assert math.hypot(p['x'] - e['sx'], p['z'] - e['sz']) > 1.5, (key, p, e)
        print('PASS %s 自願帶位 %s：目標 (%.2f, %.2f) yaw %.2f，實際到位 (%.2f, %.2f)'
              % (tag, key, e['x'], e['z'], e['yaw'], p['x'], p['z']))

    # ---------- 6. 鄰近互動（near chip）----------
    pg.evaluate("MM.teleport(4.6, 8.0, Math.PI, 0)")
    pg.wait_for_function("!document.getElementById('nearChip').classList.contains('hidden') && /廟祝/.test(document.getElementById('nearChip').innerText)", timeout=5000)
    pg.locator('#nearChip').click()
    pg.wait_for_function("MM.guideNPC.isOpen()", timeout=5000)
    print('PASS %s 鄰近提示可開對話（near chip）' % tag)

    # ---------- 7. 語音：手動播放、duck、結束／關閉回復 ----------
    choose(pg, 1)
    assert pg.evaluate("MM.guideNPC.voiceState().playing") is False, 'autoplay after choosing'
    pg.locator('#gmVoice').click()
    pg.wait_for_function("MM.guideNPC.voiceState().currentTime > 0.15", timeout=8000)
    vs = pg.evaluate("MM.guideNPC.voiceState()")
    assert vs['src'].endswith('/assets/voice/rite.mp3'), vs
    assert vs['duck'] is not None and vs['duck'] < 0.5, ('bgm not ducked', vs)
    assert pg.get_attribute('#gmVoice', 'aria-pressed') == 'true'
    # 模擬播放結束（真實 media ended 事件）
    pg.evaluate("MM.guideNPC._audio().dispatchEvent(new Event('ended'))")
    pg.wait_for_function("MM.guideNPC.voiceState().duck >= 0.999", timeout=4000)
    assert pg.evaluate("MM.guideNPC.voiceState().playing") is False
    # 播放中關閉：停止 + 回復 BGM
    pg.locator('#gmVoice').click()
    pg.wait_for_function("MM.guideNPC.voiceState().currentTime > 0.05", timeout=6000)
    assert pg.evaluate("MM.guideNPC.voiceState().duck") < 0.5
    pg.locator('#gmClose').click()
    pg.wait_for_function("document.getElementById('gmPanel') && !document.getElementById('gmPanel').classList.contains('open')", timeout=4000)
    pg.wait_for_timeout(500)
    vs = pg.evaluate("MM.guideNPC.voiceState()")
    assert vs['playing'] is False and vs['paused'] is True and vs['duck'] >= 0.999, ('close cleanup', vs)
    assert pg.evaluate("MM.audio._dbg().targetAmbient") == 0.55
    print('PASS %s 語音：需按鈕、duck %.2f→1、結束與關閉均停止並回復 BGM' % (tag, vs['duck']))

    # ---------- 8. 跪拜善信不變 ----------
    kn = pg.evaluate("""(() => { const U = MM._; let mc = [];
      U.kneelers.forEach(g => { let n = 0; g.traverse(o => { if (o.isMesh) n++; }); mc.push(n); });
      const a = MM.poseKneelingVisitor(0, 2.13); const s1 = U.kneelers[0].userData.rig.spine.rotation.x;
      const b = MM.poseKneelingVisitor(0, 2.13); const s2 = U.kneelers[0].userData.rig.spine.rotation.x;
      return {n: U.kneelers.length, npcs: U.npcs.length, meshes: mc, k: a, s1: s1, s2: s2,
              pos: U.kneelers.map(g => [g.position.x, g.position.z, g.rotation.y])}; })()""")
    assert kn['n'] == 2 and kn['npcs'] == 3 and kn['meshes'] == [18, 18], kn
    assert abs(kn['s1'] - kn['s2']) < 1e-9, kn
    assert kn['pos'] == [[-2.2, -2.5, 0], [2.2, -2.5, 0]], kn['pos']
    print('PASS %s 跪拜善信不變：2 人 × 18 meshes、姿態決定性、root 靜止' % tag)

    assert not errs, ('console/page errors', errs)

with sync_playwright() as pw:
    browser = pw.chromium.launch(channel='chromium', args=ARGS)
    for w, h in ((390, 844), (900, 700)):
        pg = browser.new_page(viewport={'width': w, 'height': h}, device_scale_factor=0.35)
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
        pg.route('**/sw.js*', lambda r: r.abort())
        pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
        pg.goto(BASE, wait_until='load')
        pg.locator('#enterBtn').click()
        pg.wait_for_function(BOOT, timeout=60000)
        pg.wait_for_timeout(1000)
        pg.evaluate("MM.guideNPC.reset()")
        check(pg, 'vp%d' % w, errs)
        pg.close()
        print('PASS vp%d: no console/page errors' % w)

    # ---------- 截圖（DPR 1，一次） ----------
    pg = browser.new_page(viewport={'width': 900, 'height': 700}, device_scale_factor=1)
    pg.route('**/sw.js*', lambda r: r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE, wait_until='load')
    pg.locator('#enterBtn').click()
    pg.wait_for_function(BOOT, timeout=60000)
    pg.evaluate("MM.teleport(4.6, 9.4, Math.PI, -0.30)")
    pg.wait_for_timeout(800)
    pg.evaluate("MM.guideNPC.open(); MM.guideNPC.choose(0)")
    pg.wait_for_timeout(600)
    pg.evaluate("""(() => { const p = document.getElementById('gmPanel').getBoundingClientRect();
      window.__gmPanelTop = p.top; })()""")
    vis = pg.evaluate("""(() => { const T=THREE, g=MM.guideNPC.node, cam=MM._.camera;
      const p=new T.Vector3(); g.getObjectByName('headBall').getWorldPosition(p);
      const v=p.clone().project(cam);
      return {y: (1-v.y)/2*innerHeight, top: window.__gmPanelTop, x: (v.x+1)/2*innerWidth}; })()""")
    assert vis['y'] < vis['top'] - 6, ('NPC head hidden behind panel in screenshot', vis)
    pg.screenshot(path=OUT + '/guide-900.png')
    print('PASS screenshot:', OUT + '/guide-900.png')
    browser.close()
print('ALL GUIDE NPC TESTS PASSED')
