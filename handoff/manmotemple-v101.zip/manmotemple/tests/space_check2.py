from playwright.sync_api import sync_playwright
import os
BASE='http://127.0.0.1:8899/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=sp1',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations)',timeout=90000)
    pg.wait_for_timeout(1500)
    pg.evaluate("MM.showLotPreview(10)")
    pg.wait_for_timeout(2500)
    def pane():
        return pg.evaluate("""(() => {
          const vis=[...document.querySelectorAll("#sheet .lot-pane, #sheet [data-pane]")].filter(e=>getComputedStyle(e).display!=="none");
          const t=document.getElementById("sheet").innerText;
          return {txt:t.replace(/\\n/g," | ").slice(0,700), bad: t.includes("，　")};
        })()""")
    print('PAPER', pane()['bad'], pane()['txt'][:200])
    # 切到坊間通行本
    pg.evaluate("(() => { const b=[...document.querySelectorAll('#sheet [data-lot-tab], #sheet .lot-tabs button')]; const t=b.find(x=>/坊間/.test(x.textContent)); if(t) t.click(); })()")
    pg.wait_for_timeout(1200)
    r=pane(); print('LIB bad:', r['bad']); print(r['txt'][:700])
    print('ERR', errs)
    b.close()
