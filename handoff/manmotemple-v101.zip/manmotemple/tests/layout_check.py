from playwright.sync_api import sync_playwright
import json, sys
BASE = 'http://127.0.0.1:8899/'
with sync_playwright() as p:
    b = p.chromium.launch(channel='chromium', args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg = b.new_page(viewport={'width':390,'height':844}, device_scale_factor=.35)
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('**/sw.js*', lambda r: r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=layout2', wait_until='load')
    pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)', timeout=60000)
    pg.wait_for_timeout(1200)
    info = pg.evaluate('''(() => {
      const U=MM._;
      const bb=new THREE.Box3().setFromObject(U.deer);
      return {stations:Object.keys(U.stations),
              sidehall:!!U.stations.sidehall,
              deerStation:{x:U.stations.deer.x,z:U.stations.deer.z,face:U.stations.deer.face,r:U.stations.deer.r},
              deerPos:U.deer.position.toArray(), deerRot:U.deer.rotation.y,
              deerBox:[bb.min.toArray(),bb.max.toArray()],
              obstacles:U.obstacles.map(o=>({x:o.x,z:o.z,r:o.r,slide:!!o.slide})),
              censer:[U.censerGroup.position.x,U.censerGroup.position.y,U.censerGroup.position.z],
              shrineBottom:U.shrineBox.bottom};
    })()''')
    print('INFO', json.dumps(info, ensure_ascii=False))

    # 入殿向前行：由出生點直行，應被金鹿擋住但側滑繞過，最終到達香案前
    walk = pg.evaluate('''(() => { MM.teleport(0,7.6,Math.PI,0);
      window.trace=[]; MM.setJoy(0,-1);
      const t0=performance.now();
      return new Promise(res=>{
        const iv=setInterval(()=>{const p=MM._.player;trace.push([+p.x.toFixed(2),+p.z.toFixed(2)]);
          if(performance.now()-t0>9000){clearInterval(iv);MM.setJoy(0,0);res({trace,final:[p.x,p.z]});}},120);
      });})()''')
    print('WALK', json.dumps(walk))
    print('ERRORS', errs)
    b.close()
