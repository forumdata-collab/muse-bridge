from playwright.sync_api import sync_playwright
import os
BASE='http://127.0.0.1:8899/'
OUT='/home/ubuntu/.hermes/cache/scratch/deer3/'
os.makedirs(OUT, exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=d3',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)',timeout=90000)
    pg.wait_for_timeout(2200)
    pg.evaluate("document.querySelectorAll('#hz,#loader').forEach(e=>{e.classList.add('done');e.style.display='none'});1")
    for name,x,z,yaw,pitch in [('front',0,4.9,3.14159,-.14),
                               ('side',2.2,3.3,-2.15,-.16),
                               ('frontclose',0,3.6,3.14159,-.20),
                               ('entry',0,9.4,3.14159,-.04)]:
        pg.evaluate("([x,z,y,p])=>MM.teleport(x,z,y,p)",[x,z,yaw,pitch])
        pg.wait_for_timeout(700); pg.evaluate("MM.pause()"); pg.wait_for_timeout(300)
        pg.screenshot(path=OUT+name+'.png',timeout=120000); pg.evaluate("MM.resume()")
        print('shot',name)
    print('ERR',errs)
    b.close()
