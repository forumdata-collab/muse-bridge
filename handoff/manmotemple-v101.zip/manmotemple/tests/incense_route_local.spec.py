from playwright.sync_api import sync_playwright
import sys,json
base=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8899/'
with sync_playwright() as p:
 b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
 pg=b.new_context(viewport={'width':900,'height':700}).new_page();pg.route('**/sw.js',lambda r:r.abort());pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
 errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
 pg.goto(base,wait_until='load');pg.wait_for_timeout(1200);pg.evaluate("document.getElementById('enterBtn').click()");pg.wait_for_timeout(4000)
 # Move to approach directly; leave animation enabled to test route callbacks.
 pg.evaluate("MM.teleport(0,-4.6,Math.PI,0);window.__trace=[];window.__t=setInterval(()=>__trace.push({x:MM._.player.x,z:MM._.player.z,target:MM.walkTarget(),phase:MM.Incense.phase()}),100)")
 pg.evaluate("document.getElementById('incBtn').click()");pg.wait_for_timeout(80);pg.evaluate("document.getElementById('incThree').click()")
 for _ in range(100):
  if not pg.evaluate('MM.Incense.isBusy()'): break
  pg.wait_for_timeout(150)
 data=pg.evaluate("(()=>{clearInterval(__t);return {trace:__trace,total:MM.Incense.byId('main').total,front:MM.Incense.byId('front').total,pos:{x:MM._.player.x,z:MM._.player.z},toast:document.getElementById('toast').textContent,busy:MM.Incense.isBusy()}})()")
 print(json.dumps({'n':len(data['trace']),'head':data['trace'][:5],'tail':data['trace'][-8:],'main':data['total'],'front':data['front'],'pos':data['pos'],'toast':data['toast'],'busy':data['busy'],'errs':errs},ensure_ascii=False))
 b.close()
