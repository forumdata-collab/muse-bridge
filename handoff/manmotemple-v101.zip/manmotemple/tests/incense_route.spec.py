# The current route ends at the central worship point, not the old right aisle.
# Share the complete movement / three-bow / insertion regression.
from pathlib import Path
exec(compile(Path(__file__).with_name('incense_central.spec.py').read_text(), __file__, 'exec'))
