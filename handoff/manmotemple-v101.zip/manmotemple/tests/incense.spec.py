from playwright.sync_api import sync_playwright
import json,sys
BASE=sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:8899/'
fails=[]
def scenario(label,pos,mode,expect,cancel=False):
 with sync_playwright() as p:
  b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
  pg=b.new_context(viewport={'width':900,'height':700},device_scale_factor=.35).new_page();pg.route('**/sw.js',lambda r:r.abort());pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:150]));pg.goto(BASE,wait_until='load');pg.wait_for_timeout(1200);pg.evaluate("document.getElementById('enterBtn').click()");pg.wait_for_timeout(3500)
  pg.evaluate('MM.pause()')
  if pos:pg.evaluate('MM.teleport(%s,%s,Math.PI,0)'%(pos[0],pos[1]))
  else:pg.evaluate('MM.teleport(0,7.6,Math.PI,0)')
  pg.evaluate("document.getElementById('incBtn').click()")
  pg.wait_for_function("document.getElementById('sheet').classList.contains('open')",timeout=5000);pg.wait_for_timeout(350)
  if cancel:pg.evaluate('MM.pause()')
  pg.evaluate("document.getElementById('%s').click()"%('incThree' if mode=='three' else 'incOne'))
  if cancel:pg.evaluate('MM.pause()')
  else:pg.wait_for_timeout(250);pg.evaluate('MM.pause()')
  if cancel:pg.wait_for_timeout(700);pg.evaluate('MM.Incense.cancel()')
  else:pg.wait_for_timeout(250);pg.evaluate('MM.resume()')
  for _ in range(240):
   if not pg.evaluate('MM.Incense.isBusy()'):break
   pg.wait_for_timeout(500)
  got=pg.evaluate("(()=>Object.fromEntries(MM.Incense.censers.map(c=>[c.id,c.total])))()")
  result=pg.evaluate("({x:MM._.player.x,z:MM._.player.z})")
  ok=(sum(got.values())<=1 if cancel else got==expect) and not errs
  print(('PASS ' if ok else 'FAIL ')+label,json.dumps({'totals':got,'pos':result,'errors':errs},ensure_ascii=False))
  if not ok:fails.append(label)
  b.close()
scenario('殿內三炷',None,'three',{'main':3,'front':0,'heaven':0})
scenario('廟前三炷',(0,16.2),'three',{'main':0,'front':0,'heaven':1})
scenario('主爐前一炷',(0,-3.85),'one',{'main':1,'front':0,'heaven':0})
scenario('香案前一炷',(0,-7.6),'one',{'main':0,'front':1,'heaven':0})
scenario('中途取消',None,'three',{},True)
print('RESULT','ALL PASS' if not fails else 'FAILED '+','.join(fails))
raise SystemExit(bool(fails))
