from playwright.sync_api import sync_playwright
import json
BASE='http://127.0.0.1:8899/'
with sync_playwright() as p:
    b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg=b.new_page(viewport={'width':430,'height':900},device_scale_factor=1)
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/sw.js*',lambda r:r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=navsmoke',wait_until='load'); pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations)',timeout=90000)
    pg.wait_for_timeout(2000)
    rows=[]
    btns = pg.evaluate("Array.from(document.querySelectorAll('.act')).map(b=>({id:b.id,t:b.textContent.trim()}))")
    print('bottom actions:', json.dumps(btns, ensure_ascii=False))
    for bt in btns:
        pg.evaluate("document.querySelectorAll('#sheet').forEach(e=>e.classList.remove('open'))")
        pg.wait_for_timeout(200)
        pg.evaluate("(id)=>{const b=document.getElementById(id); if(b) b.click();}", bt['id'])
        pg.wait_for_timeout(1400)
        st = pg.evaluate("(() => { const s=document.getElementById('sheet'); return {open:s.classList.contains('open'), title:(s.querySelector('h3,h2,.sheet-title')||{}).textContent||'', len:s.innerText.length}; })()")
        rows.append((bt['t'], st))
        print(bt['t'], st['open'], st['title'][:24], st['len'])
        pg.evaluate("if(window.closeSheet) closeSheet(); else document.getElementById('sheet').classList.remove('open');")
    # 殿區切換
    pg.evaluate("document.getElementById('hallBtn').click()"); pg.wait_for_timeout(800)
    halls = pg.evaluate("Array.from(document.querySelectorAll('#sheet [data-hall]')).map(b=>b.getAttribute('data-hall'))")
    print('HALLS:', halls)
    print('ERR', errs)
    b.close()
