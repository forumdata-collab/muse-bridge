from playwright.sync_api import sync_playwright
import json, sys, os
BASE = 'http://127.0.0.1:8899/'
OUT = '/home/ubuntu/.hermes/cache/scratch/shots/'
os.makedirs(OUT, exist_ok=True)

with sync_playwright() as p:
    b = p.chromium.launch(channel='chromium', args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader'])
    pg = b.new_page(viewport={'width':430,'height':860}, device_scale_factor=1)
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('**/sw.js*', lambda r: r.abort())
    pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
    pg.goto(BASE+'?v=layout3', wait_until='load')
    pg.locator('#enterBtn').click()
    pg.wait_for_function('!!(window.MM&&MM._&&MM._.stations&&MM._.stations.deer)', timeout=90000)
    pg.wait_for_timeout(2500)
    pg.evaluate("document.getElementById('hz')&&document.getElementById('hz').remove();document.getElementById('loader')&&document.getElementById('loader').classList.add('done');1")

    views = [
        ("entry", 0, 8.6, 3.14159, -.02),
        ("deer", 0, 5.6, 3.14159, -.03),
        ("censer", 0, -1.2, 3.14159, -.05),
        ("steps", 0, -3.6, 3.14159, -.02),
        ("leftwall", -3.0, -4.0, -1.5708, -.02),
    ]
    for name, x, z, yaw, pitch in views:
        pg.evaluate("([x,z,y,p])=>MM.setCam(x,z,y,p)", [x,z,yaw,pitch])
        pg.wait_for_timeout(1500)
        pg.evaluate("MM.pause()")
        pg.wait_for_timeout(600)
        pg.screenshot(path=OUT+name+'.png', timeout=90000)
        print('shot', OUT+name+'.png')
        pg.evaluate("MM.resume()")

    print(pg.evaluate('''(() => {
      const U=MM._; const bb=new THREE.Box3();
      U.deer.traverse(o=>{ if(o.isMesh){ o.updateWorldMatrix(true,false); bb.expandByObject(o); }});
      let n=0; U.deer.traverse(o=>{if(o.isMesh)n++});
      return JSON.stringify({min:bb.min.toArray().map(v=>+v.toFixed(2)),max:bb.max.toArray().map(v=>+v.toFixed(2)),meshes:n});
    })()'''))
    print('ERR', errs)
    b.close()
