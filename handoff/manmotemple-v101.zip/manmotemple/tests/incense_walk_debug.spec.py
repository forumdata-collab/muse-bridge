from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
 b=p.chromium.launch(channel='chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader']);pg=b.new_page(viewport={'width':900,'height':700});pg.route('**/sw.js',lambda r:r.abort());pg.add_init_script('window.requestAnimationFrame=cb=>setTimeout(()=>cb(performance.now()),16)')
 pg.goto('http://127.0.0.1:8899/',wait_until='load');pg.wait_for_timeout(1200);pg.evaluate("document.getElementById('enterBtn').click()");pg.wait_for_timeout(3500);pg.evaluate("MM.teleport(0,-4.6,Math.PI,0)")
 pg.evaluate("window.__tr=[];window.__ti=setInterval(()=>__tr.push({p:[MM._.player.x,MM._.player.z],t:MM.walkTarget(),busy:MM.Incense.isBusy(),phase:MM.Incense.phase()}),150)")
 pg.evaluate("document.getElementById('incBtn').click()");pg.wait_for_timeout(450);pg.evaluate("document.getElementById('incThree').click()")
 for _ in range(20):
  pg.wait_for_timeout(1000)
  if not pg.evaluate('MM.Incense.isBusy()'): break
 print(json.dumps({'trace':pg.evaluate("(()=>{clearInterval(__ti);return __tr})()"),'route':pg.evaluate("({z:MM._.player.z,x:MM._.player.x,toast:document.getElementById('toast').textContent,phase:MM.Incense.phase(),busy:MM.Incense.isBusy(),main:MM.Incense.byId('main').total})")},ensure_ascii=False));b.close()
