/* 文武廟 · 金鹿（文昌帝君座前神獸）
   鹿喻「俸祿」；善信請金箔貼於鹿身祈願 — 依東華三院文武廟「祈願金鹿」習俗
   位置與朝向：入殿中軸、鹿頭向門（local +z 即入口方向，rotation.y = 0） */
(function () {
  "use strict";
  var T = window.THREE, MM = window.MM, U = MM._;
  var scene, box, cyl, mesh, mat, gold, rnd;
  var deer, antlers = [], ears = [], tailGroup = null, patchGroup, patches = {};
  var wheatGroup = null;   /* v97：麥穗組（每格微擺用）；v98 拆咗頸鈴組 */

  /* ---------------- 尺度（鹿身局部單位；1 單位 = SCALE 米） ---------------- */
  var SCALE = .54;                 /* 連鹿角約 1.65m，比成人稍矮 */
  var PLINTH_TOP = .36;            /* 台座頂面高度 */
  var HOOF_Y = .08;                /* 蹄底在鹿身局部 y */
  var BODY_Y = PLINTH_TOP - HOOF_Y * SCALE;   /* 鹿身離地 = .317 */
  var SITE = { x: 0, z: 2.4, r: .80 };        /* 入殿中軸；r = 碰撞半徑 */
  var MM_UNIT = 1 / (1000 * SCALE);           /* 1mm 等於幾多鹿身局部單位 */

  /* 台座：矮而精緻的直立長方形（左右收窄、前後加長，四蹄剛好站得住） */
  var PLINTH = { base: [.42, .13, 1.54], trim: [.46, .03, 1.60], body: [.38, .16, 1.54], cap: [.40, .02, 1.54] };

  /* 靈芝如意：依實物照片——彎曲木枝柄 + 末端大靈芝雲頭 + 柄身小靈芝芽；
     v98：雲頭改單片扁圓蓋，柄尾加扁長方形，兩粒座腳，柄身螺旋雕紋 */
  var RUYI = {
    spine: [[.00, 1.455, .30], [-.035, 1.415, .10], [.035, 1.372, -.08], [-.015, 1.352, -.24], [.01, 1.38, -.33]],
    rHead: .030, rTip: .011,           /* 柄徑由頭到尾漸收 */
    headTilt: -.55,                    /* 雲頭向上揚起 */
    sprouts: [[.26, .040, 1], [.50, .034, -1], [.72, .028, 1]]
  };

  var AREAS = {
    antler: { name: "鹿角", mean: "開啟智慧之門，增加判斷力", who: "求學人士", p: [.10, 2.02, 1.0], s: .12 },
    face:   { name: "臉部", mean: "工作順利，增添人緣魅力", who: "在職人士", p: [.0, 1.78, 1.19], s: .10 },
    belly:  { name: "腹部", mean: "招財、守財，生活富足", who: "營商人士", p: [.0, 1.02, .54], s: .15 },
    legs:   { name: "腳部", mean: "家庭幸福，和合美滿", who: "已婚人士", p: [.20, .58, .58], s: .12 },
    back:   { name: "背部", mean: "身體健康，百病不侵", who: "任何人士", p: [.14, 1.31, -.10], s: .15 }
  };
  MM.DEER_AREAS = AREAS;

  function init() {
    scene = U.scene; box = U.box; cyl = U.cyl; mesh = U.mesh;
    mat = U.mat; gold = U.gold; rnd = U.rnd;
    buildDeer();
  }

  /* ---------------- 組裝 ---------------- */
  function buildDeer() {
    var g = new T.Group(); g.position.set(SITE.x, 0, SITE.z); scene.add(g);
    buildPlinth(g);

    /* v95：鎏金本體 — 程序化鎏金貼圖 + bump + 環境反光，唔再係一色死金。
       map 已經係金色，color 用白色等貼圖原色出嚟；envMap 令高光有廟內暖光層次。
       v98：改用鹿專用做舊金箔 TEX.deerGold（深銅底 + 金箔貼片，照實物相）；
       鹿角用暖金 tint 提亮少少，面、頸、腿一樣有斑駁。 */
    var deerGold = U.TEX.deerGold || U.TEX.gold;
    var bodyMat = new T.MeshStandardMaterial({ map: deerGold, bumpMap: deerGold, bumpScale: .012,
      color: new T.Color("#ffffff"), metalness: .88, roughness: .34,
      envMap: U.ENV || null, envMapIntensity: 1.05 });
    var antlerMat = new T.MeshStandardMaterial({ map: deerGold, bumpMap: deerGold, bumpScale: .008,
      color: new T.Color("#e8c890"), metalness: .72, roughness: .48,
      envMap: U.ENV || null, envMapIntensity: .8 });
    var darkMat = new T.MeshStandardMaterial({ color: new T.Color("#33200e"), metalness: .55, roughness: .45,
      envMap: U.ENV || null, envMapIntensity: .5 });
    var innerEarMat = new T.MeshStandardMaterial({ color: new T.Color("#b06a3a"), metalness: .45, roughness: .6,
      envMap: U.ENV || null, envMapIntensity: .4 });
    deer = new T.Group(); deer.position.set(0, BODY_Y, 0); g.add(deer);

    buildTorso(bodyMat, darkMat);
    buildNeckAndHead(bodyMat, darkMat, innerEarMat);
    buildAntlers(antlerMat);
    buildLegs(bodyMat, darkMat);
    buildRuyi(bodyMat);                 /* 靈芝如意：顏色隨鹿身 */
    buildWheatEar();                    /* v96：口中含麥穗（豐收、祿）—— 取代舊嘅靈芝垂條 */
    /* v98：拆咗 buildTack（胸前「福」牌、頸圈金珠、小鈴）—— 實物相三張都見唔到呢啲，
       係 v95 加嘅裝飾；真鹿頸上乜都冇。U.deerBell 亦一併取消。 */

    patchGroup = new T.Group(); patchGroup.userData.dynamic = true; deer.add(patchGroup);
    deer.scale.setScalar(SCALE);
    /* 影：主光係 SpotLight（high quality 先開 shadow），鹿身 / 供品要 cast 先有落地感。
       合併時 optimizer 會用 some(castShadow) 決定合併件係咪 cast，dynamic 件直接生效。 */
    deer.traverse(function (o) { if (o.isMesh) { o.castShadow = true; } });

    var pl = new T.PointLight(0xffbe74, .5, 3.4, 2); pl.position.set(0, 1.45, 2.7); scene.add(pl);
    U.deerLight = pl;

    U.addStation("deer", "金鹿 · 貼金箔祈願", SITE.x, SITE.z, Math.PI, 2.8);
    U.deer = g;
    (U.obstacles = U.obstacles || []).push({ x: SITE.x, z: SITE.z, r: SITE.r, slide: true });
  }

  /* 台座 + 隸書牌面（牌面由 tools/make-deer-plate.py 預先烘焙）
     v98：台座改深灰石材 + 回紋邊（照實物相）—— 拆咗金邊、金角、正面兩條幼金線；
     「金鹿 • 祿」牌保留（v96 用戶要修復嘅），金框條留返做牌框。 */
  function buildPlinth(g) {
    var stoneM = new T.MeshStandardMaterial({ map: U.TEX.granite || null, color: new T.Color("#8a8175"),
      roughness: .9, metalness: .05, envMap: U.ENV || null, envMapIntensity: .3 });
    var fretM = new T.MeshStandardMaterial({ map: U.TEX.fret || U.TEX.carved, roughness: .85, metalness: .05,
      envMap: U.ENV || null, envMapIntensity: .3 });
    var plinthGold = new T.MeshStandardMaterial({ map: U.TEX.gold, bumpMap: U.TEX.gold, bumpScale: .008,
      color: new T.Color("#ffffff"), metalness: .85, roughness: .35,
      envMap: U.ENV || null, envMapIntensity: .9 });
    box(PLINTH.base[0], PLINTH.base[1], PLINTH.base[2], stoneM, 0, .065, 0, g);
    box(PLINTH.trim[0], PLINTH.trim[1], PLINTH.trim[2], stoneM, 0, .145, 0, g);
    box(PLINTH.body[0], PLINTH.body[1], PLINTH.body[2], fretM, 0, .25, 0, g);
    box(PLINTH.cap[0], PLINTH.cap[1], PLINTH.cap[2], stoneM, 0, .34, 0, g);
    /* v98：「請勿攀爬」小牌（照實物相，台座正面右邊） */
    var ncTex = U.textTexture("請勿攀爬", { size: 40, color: "#e8dcc0", bg: "#3a352e", pad: 6 });
    var nc = new T.Mesh(new T.PlaneGeometry(.12, .045),
      new T.MeshBasicMaterial({ map: ncTex, transparent: true }));
    nc.position.set(.10, .065, .772); g.add(nc);
    /* v96：金框改為四條邊框條（舊版係一塊實心金板，前面 .774 比牌面 .773 更前，
       成塊「金鹿 • 祿」牌畀金板遮住晒 — 呢個就係 v95 隸書消失嘅原因）。
       邊框條喺牌面外圍，牌面移到 .778，永遠喺最前。 */
    box(.32, .012, .008, plinthGold, 0, .325, .772, g);
    box(.32, .012, .008, plinthGold, 0, .175, .772, g);
    box(.012, .15, .008, plinthGold, -.155, .25, .772, g);
    box(.012, .15, .008, plinthGold, .155, .25, .772, g);

    /* 牌面：先用 Canvas 隸書後備字（PNG 未載入／載入失敗都見到字），PNG 載好再換上烘焙圖 */
    var plateFallback = U.cvs(440, 200, function (x, w, h) {
      x.fillStyle = "#4a0d09"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "#c9a24a"; x.lineWidth = 5; x.strokeRect(10, 10, w - 20, h - 20);
      x.strokeStyle = "rgba(201,162,74,.6)"; x.lineWidth = 2; x.strokeRect(20, 20, w - 40, h - 40);
      x.font = "700 88px serif"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillStyle = "#f0cd80";
      x.fillText("金鹿 • 祿", w / 2, h / 2 + 4);
    });
    var plate = new T.Mesh(new T.PlaneGeometry(.28, .13), new T.MeshBasicMaterial({ map: plateFallback, transparent: true }));
    plate.position.set(0, .25, .778); plate.renderOrder = 2; plate.userData.dynamic = true; g.add(plate);
    new T.TextureLoader().load("assets/deer-plate.png", function (t) {
      t.encoding = T.sRGBEncoding;
      if (U.renderer && U.renderer.capabilities) t.anisotropy = Math.min(8, U.renderer.capabilities.getMaxAnisotropy());
      plate.material.map = t; plate.material.needsUpdate = true;
    });
  }

  function buildTorso(bodyMat, darkMat) {
    mesh(new T.SphereGeometry(.34, 32, 24), bodyMat, 0, 1.02, -.02, deer).scale.set(.92, .94, 1.55);
    mesh(new T.SphereGeometry(.3, 28, 20), bodyMat, 0, 1.04, .46, deer).scale.set(.94, 1.02, 1.05);
    mesh(new T.SphereGeometry(.3, 28, 20), bodyMat, 0, 1.04, -.5, deer).scale.set(.98, 1.04, 1);
    /* 胸隆 + 腹底：等身形唔再係一粒拉長波 */
    mesh(new T.SphereGeometry(.18, 20, 14), bodyMat, 0, .92, .62, deer).scale.set(.8, 1, 1);
    mesh(new T.SphereGeometry(.28, 24, 18), bodyMat, 0, .88, -.05, deer).scale.set(.9, .8, 1.3);
    [-1, 1].forEach(function (s) {
      mesh(new T.SphereGeometry(.17, 20, 14), bodyMat, s * .25, 1.13, .42, deer).scale.set(.6, 1.1, .9);
      mesh(new T.SphereGeometry(.18, 20, 14), bodyMat, s * .26, 1.06, -.5, deer).scale.set(.62, 1.15, .95);
      for (var r = 0; r < 3; r++) {           /* 肋骨起伏 */
        var rib = mesh(new T.TorusGeometry(.3 - r * .02, .015, 8, 24, Math.PI * 1.2), bodyMat, 0, 1.0 + r * .02, .12 - r * .22, deer);
        rib.rotation.z = Math.PI / 2; rib.rotation.y = Math.PI / 2; rib.scale.set(1, .95, .8);
      }
      /* 脇側雲紋陰刻（金底深金線）：兩邊對稱，近睇先見到 */
      var cloud = mesh(new T.TorusGeometry(.17, .006, 6, 24, Math.PI * 1.1), darkMat, s * .315, 1.05, .05, deer);
      cloud.rotation.y = Math.PI / 2; cloud.rotation.z = .4;
      var cloud2 = mesh(new T.TorusGeometry(.11, .005, 6, 20, Math.PI * 1.3), darkMat, s * .325, 1.02, -.18, deer);
      cloud2.rotation.y = Math.PI / 2; cloud2.rotation.z = -.5;
    });
    /* 背脊鬃毛：一排細扁金簇，由頸背延到腰 */
    for (var mi = 0; mi < 7; mi++) {
      var mane = mesh(new T.SphereGeometry(.035, 10, 8), darkMat, 0, 1.34 - mi * .015, .62 - mi * .17, deer);
      mane.scale.set(.55, 1.15, .9); mane.rotation.x = -.3;
    }
    /* 尾：獨立 group（dynamic），等陣可以輕擺 */
    tailGroup = new T.Group(); tailGroup.position.set(0, 1.08, -.86); tailGroup.rotation.x = -.55;
    tailGroup.userData.dynamic = true; deer.add(tailGroup);
    cyl(.018, .045, .22, bodyMat, 0, 0, 0, tailGroup, 10);
    var tuft = mesh(new T.SphereGeometry(.05, 12, 10), darkMat, 0, -.12, -.02, tailGroup);
    tuft.scale.set(.8, 1.25, .7);
    mesh(new T.SphereGeometry(.032, 10, 8), bodyMat, 0, -.06, .02, tailGroup).scale.set(.7, 1, .7);
  }

  function buildNeckAndHead(bodyMat, darkMat, innerEarMat) {
    var neck = cyl(.095, .175, .68, bodyMat, 0, 1.36, .73, deer, 20);   /* 前傾頸 */
    neck.rotation.x = .62; neck.scale.z = .9;
    /* 頸肌：兩側頸筋令頸唔再係一支光管 */
    [-1, 1].forEach(function (ns) {
      mesh(new T.SphereGeometry(.06, 12, 10), bodyMat, ns * .09, 1.42, .78, deer).scale.set(.5, 1.4, .8);
    });

    mesh(new T.SphereGeometry(.15, 28, 20), bodyMat, 0, 1.72, 1.0, deer).scale.set(.72, .8, 1.3);
    mesh(new T.SphereGeometry(.1, 20, 16), bodyMat, 0, 1.63, 1.14, deer).scale.set(.72, .62, 1.25);
    mesh(new T.SphereGeometry(.072, 20, 16), bodyMat, 0, 1.6, 1.31, deer).scale.set(.78, .68, 1.5);
    mesh(new T.SphereGeometry(.042, 14, 10), darkMat, 0, 1.6, 1.4, deer).scale.set(1.15, .75, .7);
    /* 下頜 + 顎肌 + 下巴 */
    [-1, 1].forEach(function (js) {
      mesh(new T.SphereGeometry(.055, 12, 10), bodyMat, js * .08, 1.66, 1.05, deer).scale.set(.6, .5, .9);
    });
    mesh(new T.SphereGeometry(.05, 12, 10), bodyMat, 0, 1.56, 1.28, deer).scale.set(.9, .6, .8);
    /* 鼻孔 + 嘴線 */
    [-1, 1].forEach(function (ns2) {
      var nostril = mesh(new T.SphereGeometry(.013, 8, 6), darkMat, ns2 * .035, 1.585, 1.385, deer);
      nostril.scale.set(1, .7, .5); nostril.rotation.z = ns2 * .5;
    });
    var mouth = mesh(new T.TorusGeometry(.05, .004, 6, 18, Math.PI * .75), darkMat, 0, 1.565, 1.36, deer);
    mouth.rotation.set(.5, 0, Math.PI * 1.12);
    /* 額頂金簇 */
    for (var fi = -1; fi <= 1; fi++) {
      var tuftF = mesh(new T.SphereGeometry(.022, 8, 6), darkMat, fi * .03, 1.86, 1.02, deer);
      tuftF.scale.set(.7, 1.4, .7);
    }
    [-1, 1].forEach(function (s) {          /* 眼 + 眼神光 + 眼瞼 + 眉脊 */
      mesh(new T.SphereGeometry(.026, 12, 10), new T.MeshBasicMaterial({ color: 0x0d0703 }), s * .105, 1.75, 1.08, deer);
      mesh(new T.SphereGeometry(.009, 6, 5), new T.MeshBasicMaterial({ color: 0xffe6b0 }), s * .112, 1.762, 1.086, deer);
      var lid = mesh(new T.TorusGeometry(.032, .006, 6, 16, Math.PI), bodyMat, s * .105, 1.752, 1.082, deer);
      lid.rotation.set(.2, s * .5, s * .15);
      mesh(new T.SphereGeometry(.028, 10, 8), bodyMat, s * .105, 1.79, 1.07, deer).scale.set(1, .45, .7);
      /* 耳：向後外側，獨立 dynamic group，等陣可以輕動 */
      var ear = new T.Group(); ear.position.set(s * .12, 1.84, .99); ear.rotation.z = s * .55; ear.rotation.x = -.45;
      ear.userData.dynamic = true; ear.userData.baseRotZ = s * .55; ear.userData.side = s; deer.add(ear); ears.push(ear);
      cyl(.012, .06, .2, bodyMat, 0, .1, 0, ear, 12).scale.z = .55;
      var inner = cyl(.008, .042, .15, innerEarMat, 0, .1, -.012, ear, 12); inner.scale.z = .4;
      var rim = mesh(new T.TorusGeometry(.052, .007, 6, 16), bodyMat, 0, .1, -.005, ear);
      rim.rotation.x = Math.PI / 2 - .2;
      mesh(new T.SphereGeometry(.016, 8, 6), darkMat, 0, .2, 0, ear).scale.set(.8, 1.2, .5);
    });
  }

  function buildAntlers(bodyMat) {
    function branch(parent, pts, r) {
      var curve = new T.CatmullRomCurve3(pts.map(function (p) { return new T.Vector3(p[0], p[1], p[2]); }));
      var tube = new T.Mesh(new T.TubeGeometry(curve, 32, r, 10, false), bodyMat);
      tube.castShadow = true; parent.add(tube);
      var endPt = pts[pts.length - 1], prev = pts[pts.length - 2];
      var dir = new T.Vector3(endPt[0] - prev[0], endPt[1] - prev[1], endPt[2] - prev[2]).normalize();
      var tip = cyl(.001, r * .95, .09, bodyMat, endPt[0] + dir.x * .04, endPt[1] + dir.y * .04, endPt[2] + dir.z * .04, parent, 8);
      tip.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), dir);
      /* 尖端收深色，似鹿角天然角尖 */
      mesh(new T.SphereGeometry(r * .55, 8, 6), new T.MeshStandardMaterial({ color: new T.Color("#5a3a12"), metalness: .4, roughness: .6 }),
        endPt[0] + dir.x * .07, endPt[1] + dir.y * .07, endPt[2] + dir.z * .07, parent);
    }
    [-1, 1].forEach(function (sd) {
      /* v96：鹿角樞軸改設喺角基（舊版樞軸喺鹿身原點，onFrame 嘅 -0.22 轉角
         令成支鹿角向前上方移位，望落同頭分離 — v95 將鹿角標 dynamic 之後，
         呢個舊轉角先至真正郁到，空隙就現形。家下樞軸就係角基，輕擺只係 ±0.01，
         角柄沉入頭骨，唔會再離頭。分枝座標改為相對角基。 */
      var baseX = sd * .07, baseY = 1.84, baseZ = 1.0;
      var A = new T.Group(); A.position.set(baseX, baseY, baseZ); A.userData.dynamic = true; deer.add(A);
      /* 角柄：由頭骨內伸出，隨鹿角一齊擺，永遠連住頭 */
      cyl(.05, .062, .20, bodyMat, 0, .02, 0, A, 12);
      /* 角基骨瘤：扁球壓住頭頂，遮住角柄同頭殼嘅接縫 */
      mesh(new T.SphereGeometry(.062, 12, 10), bodyMat, 0, -.02, 0, A).scale.set(1, .65, 1);
      branch(A, [[sd * .005, .02, 0], [sd * .06, .24, -.06], [sd * .12, .46, -.14], [sd * .14, .66, -.24], [sd * .15, .76, -.34]], .026);
      branch(A, [[sd * .02, .06, .02], [sd * .13, .16, .12], [sd * .21, .18, .22], [sd * .24, .16, .28]], .018);
      branch(A, [[sd * .07, .26, -.07], [sd * .19, .38, 0], [sd * .27, .46, .04], [sd * .30, .49, .06]], .015);
      branch(A, [[sd * .12, .48, -.15], [sd * .23, .58, -.10], [sd * .31, .63, -.07], [sd * .34, .65, -.05]], .013);
      /* 眉枝：向前伸，鹿角先似真鹿有前後分枝 */
      branch(A, [[sd * .01, .04, .04], [sd * .09, .10, .18], [sd * .15, .12, .30], [sd * .17, .11, .36]], .014);
      /* 角基雙環：珠狀凸起，似鹿角基部骨瘤 */
      var ring = mesh(new T.TorusGeometry(.042, .011, 8, 20), bodyMat, sd * .005, .03, 0, A);
      ring.rotation.x = Math.PI / 2 - .28;
      var ring2 = mesh(new T.TorusGeometry(.046, .008, 8, 20), bodyMat, sd * .005, .005, 0, A);
      ring2.rotation.x = Math.PI / 2 - .28;
      antlers.push(A);
    });
  }

  function buildLegs(bodyMat, darkMat) {
    [[-.22, .46], [.22, .46], [-.24, -.5], [.24, -.5]].forEach(function (p, i) {
      var hind = i >= 2;
      var leg = new T.Group(); leg.position.set(p[0], .98, p[1]); deer.add(leg);
      var thigh = cyl(.1, .06, .38, bodyMat, 0, -.16, 0, leg, 10);
      if (hind) { thigh.rotation.x = -.22; thigh.position.z = -.03; }
      mesh(new T.SphereGeometry(.055, 10, 8), bodyMat, 0, -.36, hind ? -.05 : 0, leg);
      var cannon = cyl(.048, .038, .4, bodyMat, 0, -.55, hind ? .02 : 0, leg, 10);
      if (hind) cannon.rotation.x = .16;
      mesh(new T.SphereGeometry(.042, 10, 8), bodyMat, 0, -.76, hind ? .06 : 0, leg);
      /* 蹄：分叉兩趾 + 蹄踵絨毛 + 後方小距 */
      [-1, 1].forEach(function (ts) {
        box(.034, .09, .11, darkMat, ts * .02, -.86, hind ? .08 : .01, leg).scale.set(1, 1, 1.15);
      });
      mesh(new T.SphereGeometry(.028, 8, 6), bodyMat, 0, -.78, hind ? -.02 : -.04, leg).scale.set(1, .8, .7);
      var dew = mesh(new T.ConeGeometry(.012, .04, 6), darkMat, 0, -.80, hind ? -.02 : -.05, leg);
      dew.rotation.x = hind ? .6 : -.6;
    });
  }

  /* 靈芝如意：彎曲枝幹 + 靈芝雲頭 + 柄身小靈芝（形制依實物照片） */
  function buildRuyi(bodyMat) {
    var g = new T.Group(); g.position.set(0, 0, 0); deer.add(g);
    var curve = new T.CatmullRomCurve3(RUYI.spine.map(function (p) { return new T.Vector3(p[0], p[1], p[2]); }));

    /* 枝幹：沿曲線排圓柱，半徑由頭到尾漸收（TubeGeometry 冇錐度） */
    var N = 26, prev = curve.getPoint(0);
    for (var i = 1; i <= N; i++) {
      var t = i / N, pt = curve.getPoint(t);
      var r = RUYI.rHead + (RUYI.rTip - RUYI.rHead) * t;
      r *= 1 + .28 * Math.sin(t * 9.4);                 /* 枝節起伏 */
      var len = prev.distanceTo(pt);
      var seg = new T.Mesh(new T.CylinderGeometry(r, r * 1.06, len * 1.08, 9), bodyMat);
      seg.position.copy(prev).add(pt).multiplyScalar(.5);
      seg.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), pt.clone().sub(prev).normalize());
      g.add(seg);
      prev = pt;
    }

    /* 柄身小靈芝芽：扁球 + 捲邊 */
    RUYI.sprouts.forEach(function (sp) {
      var p = curve.getPoint(sp[0]), side = sp[2];
      var sg = new T.Group(); sg.position.set(p.x + side * .028, p.y + .012, p.z); g.add(sg);
      var cap = new T.Mesh(new T.SphereGeometry(sp[1], 12, 9), bodyMat);
      cap.scale.set(1.15, .38, 1.0); cap.rotation.z = side * .5; sg.add(cap);
      var curl = new T.Mesh(new T.TorusGeometry(sp[1] * .55, sp[1] * .16, 6, 14), bodyMat);
      curl.rotation.x = Math.PI / 2; curl.position.y = .006; sg.add(curl);
    });

    /* v98：靈芝雲頭改為單片扁圓蓋（照實物相：成個蓋係一塊大圓片，唔係三瓣冠），
       蓋緣加雕刻邊環，蓋面留同心捲紋。 */
    var hp = curve.getPoint(0);
    var hg = new T.Group(); hg.position.set(hp.x, hp.y + .012, hp.z); hg.rotation.x = RUYI.headTilt; g.add(hg);
    var capMain = new T.Mesh(new T.SphereGeometry(.105, 20, 14), bodyMat);
    capMain.scale.set(1.25, .32, 1.05); capMain.position.set(0, .034, .014); hg.add(capMain);
    var rim = new T.Mesh(new T.TorusGeometry(.105, .008, 6, 28), bodyMat);
    rim.rotation.x = Math.PI / 2; rim.position.set(0, .034, .014); hg.add(rim);
    /* 冠面同心捲紋 */
    [[.062, .008], [.040, .007], [.020, .006]].forEach(function (w, wi) {
      var ring = new T.Mesh(new T.TorusGeometry(w[0], w[1], 6, 24, Math.PI * 1.45), bodyMat);
      ring.rotation.x = Math.PI / 2; ring.rotation.z = wi * 1.1;
      ring.position.y = .068 - wi * .01; hg.add(ring);
    });
    /* v98：柄尾扁長方形（照實物相：柄尾係一塊扁平長方形金片） */
    var tp = curve.getPoint(1);
    var tailEnd = mesh(new T.BoxGeometry(.10, .016, .06), bodyMat, tp.x, tp.y + .004, tp.z - .03, g);
    tailEnd.rotation.x = .25; tailEnd.rotation.y = .06;
    /* v98：兩粒座腳 — 靈芝柄唔係浮喺背上，係坐喺兩粒矮腳上面 */
    var darkM = new T.MeshStandardMaterial({ color: new T.Color("#241a10"), metalness: .5, roughness: .55,
      envMap: U.ENV || null, envMapIntensity: .4 });
    [.35, .7].forEach(function (tt) {
      var pp = curve.getPoint(tt);
      cyl(.008, .010, .07, darkM, pp.x, pp.y - .035, pp.z, g, 8);
    });
    /* v98：柄身螺旋雕紋 — 一條幼管沿柄身盤旋三圈，似實物嘅密雲紋雕刻 */
    var frames = curve.computeFrenetFrames(80, false);
    var helixPts = [];
    for (var hi = 0; hi <= 80; hi++) {
      var ht = hi / 80, hp2 = curve.getPoint(ht);
      var hr = (RUYI.rHead + (RUYI.rTip - RUYI.rHead) * ht) * (1 + .28 * Math.sin(ht * 9.4)) + .001;
      var ang = ht * Math.PI * 6;
      helixPts.push(new T.Vector3(
        hp2.x + (frames.normals[hi].x * Math.cos(ang) + frames.binormals[hi].x * Math.sin(ang)) * hr,
        hp2.y + (frames.normals[hi].y * Math.cos(ang) + frames.binormals[hi].y * Math.sin(ang)) * hr,
        hp2.z + (frames.normals[hi].z * Math.cos(ang) + frames.binormals[hi].z * Math.sin(ang)) * hr));
    }
    var helix = new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(helixPts), 120, .0035, 6, false), darkM);
    helix.castShadow = true; g.add(helix);
  }

  /* v98：口中麥穗改為粗扭紋長柄垂下 —— 照實物相，鹿嘴銜住嘅係一條扭紋長柄
     （麥穗形象化），由嘴垂到胸口，唔係一穗有麥粒嘅穗頭。用戶確認：扭紋柄就係
     麥穗形象化，可以加粗垂下。穗柄加粗（半徑 .02）、垂下約 .45，柄身盤住扭紋；
     上下唇瓣照舊輕輕合攏托住穗柄，依然係「柔和含住」。注意：wheat 局部 +z 約
     等於世界向下，所以上唇喺局部 -z、下唇喺局部 +z；局部 -y 約等於世界向後
     （向胸口），穗柄垂下時要同時向局部 -y 彎，先會貼住喉胸，唔會浮喺胸前。 */
  function buildWheatEar() {
    var wheat = new T.Group();
    wheat.position.set(.02, 1.58, 1.38); wheat.rotation.set(1.42, 0, -.28); deer.add(wheat);
    /* 麥穗組標 dynamic 唔畀合併食咗（鹿本身靜止，但組結構要保留，畀 smoke test 同互動讀取） */
    wheat.userData.dynamic = true; wheatGroup = wheat; U.wheatEar = wheat;
    var stalkM = new T.MeshStandardMaterial({ color: new T.Color("#c9a24e"), metalness: .7, roughness: .4,
      envMap: U.ENV || null, envMapIntensity: .7 });
    var twistM = new T.MeshStandardMaterial({ color: new T.Color("#8a6a2a"), metalness: .7, roughness: .45,
      envMap: U.ENV || null, envMapIntensity: .5 });
    var lipM = gold();
    /* 扭紋長柄：由嘴內伸出，穿過唇間，垂到胸口 — 局部 +z 係世界向下，局部 -y 係
       世界向後（貼住喉胸）；柄身輕輕 S 形，唔係死直 */
    var stalkCurve = new T.CatmullRomCurve3([
      new T.Vector3(0, -.02, -.05),
      new T.Vector3(.008, -.06, .10),
      new T.Vector3(-.006, -.14, .22),
      new T.Vector3(.004, -.22, .34),
      new T.Vector3(0, -.30, .45)
    ]);
    var stalkTube = new T.Mesh(new T.TubeGeometry(stalkCurve, 32, .02, 10, false), stalkM);
    stalkTube.castShadow = true; wheat.add(stalkTube);
    /* 扭紋：幼管沿柄身盤旋四圈，似擰成嘅麥穗柄 */
    var sFrames = stalkCurve.computeFrenetFrames(60, false);
    var twistPts = [];
    for (var ti = 0; ti <= 60; ti++) {
      var tt = ti / 60, tp = stalkCurve.getPoint(tt), ta = tt * Math.PI * 8;
      twistPts.push(new T.Vector3(
        tp.x + (sFrames.normals[ti].x * Math.cos(ta) + sFrames.binormals[ti].x * Math.sin(ta)) * .021,
        tp.y + (sFrames.normals[ti].y * Math.cos(ta) + sFrames.binormals[ti].y * Math.sin(ta)) * .021,
        tp.z + (sFrames.normals[ti].z * Math.cos(ta) + sFrames.binormals[ti].z * Math.sin(ta)) * .021));
    }
    var twistTube = new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(twistPts), 90, .005, 6, false), twistM);
    twistTube.castShadow = true; wheat.add(twistTube);
    /* 柄尾圓頭收口 */
    var endPt = stalkCurve.getPoint(1);
    var endTip = mesh(new T.SphereGeometry(.02, 10, 8), stalkM, endPt.x, endPt.y, endPt.z, wheat);
    /* 上下唇瓣：輕輕合攏托住穗柄，似含住 — 上唇喺局部 -z（世界向上），
       下唇飽滿啲喺局部 +z（世界向下），由下托住穗柄 */
    var upperLip = mesh(new T.SphereGeometry(.032, 10, 8), lipM, 0, .01, -.03, wheat);
    upperLip.scale.set(1.5, .5, .9);
    var lowerLip = mesh(new T.SphereGeometry(.034, 10, 8), lipM, 0, .01, .03, wheat);
    lowerLip.scale.set(1.5, .7, 1.0);
    /* 嘴角：兩邊唇角向內收，包住穗柄兩側 */
    [-1, 1].forEach(function (ls) {
      var corner = mesh(new T.SphereGeometry(.02, 8, 6), lipM, ls * .026, .01, 0, wheat);
      corner.scale.set(.8, 1.1, .9);
    });
    wheat.traverse(function (o) { if (o.isMesh) o.castShadow = true; });
  }

  /* ---------------- 貼金箔 ---------------- */
  var AREA_ORDER = ["antler", "face", "belly", "legs", "back"];
  MM.gildDeer = function (area, silent) {
    var a = AREAS[area]; if (!a || patches[area]) return false;
    var foilMat = new T.MeshStandardMaterial({
      color: new T.Color("#fff3c4"), metalness: .98, roughness: .08,
      emissive: new T.Color("#ffe2a0"), emissiveIntensity: .85
    });
    var foilGeo = new T.SphereGeometry(a.s, 16, 12);
    /* 金箔皺摺：逐頂點輕微抖動，唔再係光滑金餅 */
    (function () {
      var pos = foilGeo.attributes.position;
      for (var vi = 0; vi < pos.count; vi++) {
        pos.setXYZ(vi, pos.getX(vi) + rnd(-.006, .006), pos.getY(vi) + rnd(-.004, .004), pos.getZ(vi) + rnd(-.006, .006));
      }
      foilGeo.computeVertexNormals();
    })();
    var foil = mesh(foilGeo, foilMat, a.p[0], a.p[1], a.p[2], patchGroup);
    foil.scale.set(1, .28, 1);
    foil.rotation.set(rnd(-.3, .3), rnd(0, 6.28), rnd(-.3, .3));
    for (var i = 0; i < 4; i++) {               /* 邊緣碎金 */
      mesh(new T.SphereGeometry(a.s * .22, 8, 6), foilMat,
        a.p[0] + rnd(-a.s * .8, a.s * .8), a.p[1] + rnd(-a.s * .3, a.s * .3), a.p[2] + rnd(-a.s * .3, a.s * .3), patchGroup)
        .scale.set(1, .2, 1);
    }
    var spark = new T.Sprite(new T.SpriteMaterial({ map: U.TEX.glow, color: 0xfff0c0, transparent: true, opacity: .75, blending: T.AdditiveBlending, depthWrite: false }));
    spark.scale.setScalar(a.s * 6.5); spark.position.set(a.p[0], a.p[1], a.p[2]); patchGroup.add(spark);
    foil.userData.spark = spark;
    patches[area] = foil;
    if (!silent) { MM.gildCount = (MM.gildCount || 0) + 1; }
    return true;
  };
  MM.gildedAreas = function () { return Object.keys(patches); };
  MM.resetDeer = function () {
    Object.keys(patches).forEach(function (k) { var f = patches[k]; if (f.userData.spark) patchGroup.remove(f.userData.spark); patchGroup.remove(f); delete patches[k]; });
    MM.gildCount = 0;
  };
  MM.deerOrder = AREA_ORDER;
  MM.buildDeer = init;

  /* v97 修正：金鹿係擺設，唔會呼吸、唔會郁 — 成個擺件靜止。
     鹿身、鹿角、耳、尾、麥穗、頸鈴、金箔星光全部唔郁。onFrameDeer 保留空殼，
     等 scene.js 唔使改，之後如果再有需要郁嘅擺件先加返。 */
  U.onFrameDeer = function (dt, t) { };
})();
