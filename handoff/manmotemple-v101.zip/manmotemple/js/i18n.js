/* 介面語言：語言由網址前綴決定（/fortunestick/en/），其次 ?lang=，其次上次選擇，最後跟瀏覽器。
   只負責介面字串；籤紙本身永遠是中文原文。 */
window.I18N = (function () {
  "use strict";
  var D = window.UI_STRINGS || {};
  var SUPPORTED = ["zh-Hant", "en", "ja", "th"];

  function fromPath() {
    var m = location.pathname.match(/\/(en|ja|th)\/?$/);
    return m ? m[1] : null;
  }
  function fromQuery() {
    var m = location.search.match(/[?&]lang=(en|ja|th|zh-Hant)/);
    return m ? m[1] : null;
  }
  function fromBrowser() {
    var l = (navigator.languages || [navigator.language || ""]).join(",").toLowerCase();
    if (/th/.test(l)) return "th";
    if (/ja/.test(l)) return "ja";
    if (/^en|,en/.test(l)) return "en";
    return "zh-Hant";
  }
  /* 網址前綴係唯一真相：根目錄 = 繁中，/en/ /ja/ /th/ 各自固定。
     唔好跟瀏覽器語言自動跳，否則中文版會喺英文系統嘅機變英文。 */
  var lang = fromPath() || fromQuery() || "zh-Hant";
  if (SUPPORTED.indexOf(lang) < 0) lang = "zh-Hant";

  function t(k) {
    var row = D[lang] || {}, base = D["zh-Hant"] || {};
    return row[k] != null ? row[k] : (base[k] != null ? base[k] : k);
  }
  function set(l) {
    if (SUPPORTED.indexOf(l) < 0) return;
    lang = l; apply();
  }
  function apply() {
    document.documentElement.lang = t("htmlLang");
    document.title = t("title");
    var nodes = document.querySelectorAll("[data-i18n]");
    for (var i = 0; i < nodes.length; i++) nodes[i].textContent = t(nodes[i].getAttribute("data-i18n"));
    var ph = document.querySelectorAll("[data-i18n-ph]");
    for (var j = 0; j < ph.length; j++) ph[j].setAttribute("placeholder", t(ph[j].getAttribute("data-i18n-ph")));
    var d = document.querySelectorAll("[data-i18n-aria]");
    for (var k = 0; k < d.length; k++) d[k].setAttribute("aria-label", t(d[k].getAttribute("data-i18n-aria")));
  }
  /* 語言切換：zh 回上層目錄，其餘去 ../<lang>/ */
  function href(l) {
    if (l === "zh-Hant") return "../";
    return "../" + l + "/";
  }
  return { lang: lang, t: t, set: set, apply: apply, href: href, supported: SUPPORTED };
})();
