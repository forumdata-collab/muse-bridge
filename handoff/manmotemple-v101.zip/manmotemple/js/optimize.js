/* 文武廟 · 靜態幾何合併（draw call 優化）
   將「同一材質、同一屬性、無動畫」的靜態 mesh 合併成一塊，
   draw calls 由 650+ 降到目標 <200，視覺完全不變。
   動態物件（光明燈、金鹿、聖物、祈福牌、幡、塔香）以 userData.dynamic 排除。 */
(function () {
  "use strict";
  var T = window.THREE, MM = window.MM, U = MM._;

  function sig(o) {
    var m = o.material;
    return [m.type, m.color && m.color.getHexString(), m.roughness, m.metalness,
      m.emissive && m.emissive.getHexString(), m.emissiveIntensity,
      m.map ? m.map.uuid : "", m.side, m.transparent ? 1 : 0, m.opacity,
      m.flatShading ? 1 : 0, m.alphaTest].join("|");
  }

  function keyFor(o) {
    var g = o.geometry;
    return sig(o) + "#" + Object.keys(g.attributes).sort().join(",") + "#" + (g.index ? 1 : 0);
  }

  function mergeGeos(list) {
    var first = list[0], names = Object.keys(first.attributes);
    var useIndex = !!first.index, vTotal = 0, iTotal = 0;
    list.forEach(function (g) { vTotal += g.attributes.position.count; if (useIndex) iTotal += g.index.count; });
    var out = new T.BufferGeometry();
    names.forEach(function (n) {
      var item = first.attributes[n].itemSize, arr = new Float32Array(vTotal * item), off = 0;
      list.forEach(function (g) {
        var a = g.attributes[n], len = a.count * item;
        if (a.array.length === len) arr.set(a.array, off);
        else arr.set(a.array.subarray(0, len), off);
        off += len;
      });
      out.setAttribute(n, new T.BufferAttribute(arr, item));
    });
    if (useIndex) {
      var idx = vTotal > 65535 ? new Uint32Array(iTotal) : new Uint16Array(iTotal), io = 0, vo = 0;
      list.forEach(function (g) {
        var ia = g.index.array;
        for (var i = 0; i < ia.length; i++) idx[io++] = ia[i] + vo;
        vo += g.attributes.position.count;
      });
      out.setIndex(new T.BufferAttribute(idx, 1));
    }
    out.computeBoundingSphere();
    return out;
  }

  function animTarget(o) {
    var p = o.parent, target = U.scene;
    while (p && p !== U.scene) {
      if (p.userData && (p.userData.ph !== undefined || p.userData.dynamic)) target = p;
      p = p.parent;
    }
    return target;
  }

  function isDynamic(o) {
    /* 自身有逐格動畫（旋轉／升降）→ 唔可以合併；
       上層 group 只係整體搖擺（ph）→ 可以合併，因為合併件會掛返同一 parent，跟住一齊擺。 */
    if (o.userData && (o.userData.ph !== undefined || o.userData.baseY !== undefined)) return true;
    var p = o.parent;
    while (p && p !== U.scene) {
      if (p.userData && p.userData.dynamic) return true;
      p = p.parent;
    }
    return false;
  }


  /* 第二批：無貼圖的實色 mesh → 用 vertex color 合併，按 (roughness, metalness) 分桶，
     可以再把 ~150 個獨立材質收成幾個 draw call。 */
  MM.mergeColored = function () {
    if (!U.scene) return null;
    U.scene.updateMatrixWorld(true);
    var buckets = {}, count = 0, merged = 0, absorbed = 0;

    U.scene.traverse(function (o) {
      if (!o.isMesh || o.isInstancedMesh || !o.material || Array.isArray(o.material)) return;
      var m = o.material;
      if (m.transparent || m.opacity < 1 || m.map || m.vertexColors) return;
      if (m.emissive && m.emissive.getHex() !== 0) return;      /* 發光件（燈、蠟燭）保留 */
      if (m.type !== "MeshStandardMaterial" && m.type !== "MeshLambertMaterial") return;
      if (isDynamic(o) && !(o.parent && o.parent.userData && o.parent.userData.mergedSafe)) return;
      var rf = Math.round((m.roughness === undefined ? .8 : m.roughness) * 6) / 6;
      var mt = Math.round((m.metalness === undefined ? 0 : m.metalness) * 5) / 5;
      var k = rf + "|" + mt + "|" + (o.castShadow ? 1 : 0) + "|" + (o.receiveShadow ? 1 : 0);
      (buckets[k] = buckets[k] || []).push(o);
      count++;
    });

    Object.keys(buckets).forEach(function (k) {
      var list = buckets[k];
      if (list.length < 2) return;
      try {
        var geos = [];
        list.forEach(function (o) {
          var g = o.geometry.clone();
          g.applyMatrix4(o.matrixWorld);
          var col = o.material.color || new T.Color(0xffffff);
          var n = g.attributes.position.count, arr = new Float32Array(n * 3);
          for (var i = 0; i < n; i++) { arr[i * 3] = col.r; arr[i * 3 + 1] = col.g; arr[i * 3 + 2] = col.b; }
          g.setAttribute("color", new T.BufferAttribute(arr, 3));
          if (!g.attributes.uv) {
            var uv = new Float32Array(n * 2); g.setAttribute("uv", new T.BufferAttribute(uv, 2));
          }
          geos.push(g);
        });
        var parts = k.split("|");
        var mat = new T.MeshStandardMaterial({
          vertexColors: true, roughness: +parts[0] || 0.8, metalness: +parts[1] || 0
        });
        var geo = mergeGeos(geos);
        geos.forEach(function (g) { g.dispose(); });
        var mesh = new T.Mesh(geo, mat);
        mesh.castShadow = parts[2] === "1";
        mesh.receiveShadow = parts[3] === "1";
        mesh.matrixAutoUpdate = false;
        mesh.userData.merged = true;
        U.scene.add(mesh);
        list.forEach(function (o) { if (o.parent) o.parent.remove(o); });
        merged++; absorbed += list.length;
      } catch (e) {}
    });
    MM.colorStats = { candidates: count, groups: merged, absorbed: absorbed };
    return MM.colorStats;
  };

  MM.optimizeStatic = function () {
    if (!U.scene) return null;
    U.scene.updateMatrixWorld(true);
    var groups = {}, count = 0, canon = {}, deduped = 0;

    /* 第一步：同簽名材質去重（合併前必做，否則每件都係獨立材質，永遠合併唔到） */
    U.scene.traverse(function (o) {
      if (!o.isMesh || o.isInstancedMesh || !o.material || Array.isArray(o.material)) return;
      if (isDynamic(o)) return;
      var k = sig(o);
      if (canon[k]) { o.material = canon[k]; deduped++; }
      else canon[k] = o.material;
    });

    U.scene.traverse(function (o) {
      if (!o.isMesh || o.isInstancedMesh || o.isSkinnedMesh) return;
      if (!o.material || Array.isArray(o.material)) return;
      if (o.material.transparent || o.material.opacity < 1) return;
      if (!o.geometry || !o.geometry.attributes.position) return;
      if (isDynamic(o)) return;
      var k = animTarget(o).uuid + "@" + keyFor(o);
      (groups[k] = groups[k] || []).push(o);
      count++;
    });

    var merged = 0, removed = 0;
    Object.keys(groups).forEach(function (k) {
      var list = groups[k];
      if (list.length < 2) return;
      try {
        var parent = animTarget(list[0]);
        var inv = new T.Matrix4().copy(parent.matrixWorld).invert();
        var geos = list.map(function (o) {
          var g = o.geometry.clone();
          g.applyMatrix4(new T.Matrix4().multiplyMatrices(inv, o.matrixWorld));
          return g;
        });
        var geo = mergeGeos(geos);
        geos.forEach(function (g) { g.dispose(); });
        var m = new T.Mesh(geo, list[0].material);
        m.castShadow = list.some(function (o) { return o.castShadow; });
        m.receiveShadow = list.some(function (o) { return o.receiveShadow; });
        m.matrixAutoUpdate = false;
        m.userData.merged = true;
        parent.add(m);
        list.forEach(function (o) { if (o.parent) o.parent.remove(o); });
        merged++; removed += list.length;
      } catch (e) { /* 單組失敗不影響其他 */ }
    });
    MM.optStats = { before: count, mergedGroups: merged, absorbed: removed, deduped: deduped, materials: Object.keys(canon).length };
    return MM.optStats;
  };
})();
