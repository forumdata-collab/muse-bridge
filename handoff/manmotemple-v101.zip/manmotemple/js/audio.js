/* 文武廟 · 全合成音效（Web Audio，無音檔） */
(function () {
  "use strict";
  var MM = window.MM, A = MM.audio = { ready: false, muted: false };
  var ctx, master, ambientGain, sfxGain, drone = [], noiseSrc, started = false;
  var bgmBuf = null, bgmSrc = null, bgmUrl = null, bgmLoading = false;
  var vol = { ambient: .55, sfx: .8 };

  function now() { return ctx.currentTime; }
  function noiseBuffer(sec) {
    var b = ctx.createBuffer(1, ctx.sampleRate * sec, ctx.sampleRate);
    var d = b.getChannelData(0), last = 0;
    for (var i = 0; i < d.length; i++) { var w = Math.random() * 2 - 1; last = (last + .02 * w) / 1.02; d[i] = last * 3.2; }
    return b;
  }

  A.init = function () {
    if (A.ready) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 1; master.connect(ctx.destination);
    ambientGain = ctx.createGain(); ambientGain.gain.value = 0; ambientGain.connect(master);
    sfxGain = ctx.createGain(); sfxGain.gain.value = vol.sfx; sfxGain.connect(master);
    A.ready = true;
  };

  /* 後備環境音（BGM 載入失敗時才用） */
  function buildAmbient() {
    /* ---- drone: low temple hum ---- */
    [[55, "sine", .18], [82.5, "sine", .09], [110, "triangle", .05], [164.8, "sine", .03]].forEach(function (v, i) {
      var o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
      o.type = v[1]; o.frequency.value = v[0];
      f.type = "lowpass"; f.frequency.value = 260;
      g.gain.value = 0;
      o.connect(f); f.connect(g); g.connect(ambientGain); o.start();
      var lfo = ctx.createOscillator(), lg = ctx.createGain();
      lfo.frequency.value = .05 + i * .021; lg.gain.value = v[2] * .5;
      lfo.connect(lg); lg.connect(g.gain); lfo.start();
      g.gain.setTargetAtTime(v[2], now(), 3.2 + i);
      drone.push({ o: o, g: g });
    });

    /* ---- room air / distant street ---- */
    noiseSrc = ctx.createBufferSource(); noiseSrc.buffer = noiseBuffer(6); noiseSrc.loop = true;
    var bp = ctx.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 420; bp.Q.value = .55;
    var ng = ctx.createGain(); ng.gain.value = .055;
    noiseSrc.connect(bp); bp.connect(ng); ng.connect(ambientGain); noiseSrc.start();

    /* ---- slow filtered swell (crowd murmur illusion) ---- */
    var ns2 = ctx.createBufferSource(); ns2.buffer = noiseBuffer(5); ns2.loop = true;
    var bp2 = ctx.createBiquadFilter(); bp2.type = "bandpass"; bp2.frequency.value = 950; bp2.Q.value = 1.4;
    var g2 = ctx.createGain(); g2.gain.value = .012;
    var lfo2 = ctx.createOscillator(), lg2 = ctx.createGain();
    lfo2.frequency.value = .07; lg2.gain.value = .008;
    lfo2.connect(lg2); lg2.connect(g2.gain); lfo2.start();
    ns2.connect(bp2); bp2.connect(g2); g2.connect(ambientGain); ns2.start();

  }

  /* ---- BGM：整首循環（decodeAudioData → loop，sample-accurate 無接縫） ---- */
  A.bgm = function (url) { bgmUrl = url; if (started) A.loadBgm(url); };
  A.loadBgm = function (url) {
    bgmUrl = url;
    if (!A.ready && !ctx) A.init();
    if (!ctx || bgmLoading || bgmBuf) return;
    bgmLoading = true;
    fetch(url).then(function (r) { return r.arrayBuffer(); }).then(function (ab) {
      return new Promise(function (res, rej) { ctx.decodeAudioData(ab, res, rej); });
    }).then(function (buf) {
      bgmBuf = buf; bgmLoading = false;
      A.setVolume("ambient", vol.ambient);   // 觸發 gain 由 0 淡入
      if (started) A.playBgm();
    }).catch(function (e) {
      bgmLoading = false;
      console.warn("BGM load failed, fallback to synth", e);
      if (started && !drone.length) buildAmbient();
    });
  };
  A.playBgm = function () {
    if (!bgmBuf || bgmSrc || !ctx) return;
    bgmSrc = ctx.createBufferSource();
    bgmSrc.buffer = bgmBuf;
    bgmSrc.loop = true;
    bgmSrc.connect(ambientGain);
    bgmSrc.start();
  };
  A.stopBgm = function () { try { bgmSrc && bgmSrc.stop(); } catch (e) {} bgmSrc = null; };
  A.hasBgm = function () { return !!bgmBuf; };
  A._dbg = function () { return { url: bgmUrl, loading: bgmLoading, buf: !!bgmBuf, src: !!bgmSrc, loop: !!(bgmSrc && bgmSrc.loop), started: started, ctx: ctx && ctx.state, duck: duck, ambientGain: ambientGain ? ambientGain.gain.value : null, targetAmbient: vol.ambient }; };

  A.start = function () {
    if (bgmBuf) A.playBgm();                                   // 已解碼：直接播
    else if (bgmUrl && !bgmLoading) A.loadBgm(bgmUrl);          // ctx 未備時補載
    if (!A.ready) A.init();
    if (!A.ready || started) return;
    started = true;
    if (ctx.state === "suspended") ctx.resume();

    if (!bgmBuf) buildAmbient();
    else A.playBgm();

    ambientGain.gain.setTargetAtTime(vol.ambient, now(), 2.5);
    /* occasional distant bell */
    setInterval(function () { if (!A.muted && Math.random() < .5) A.bell(.16, true); }, 42000);
  };

  /* ---- bell: inharmonic partials ---- */
  A.bell = function (gain, distant) {
    if (!A.ready) return; if (A.muted) return;
    var t = now(), out = ctx.createGain();
    out.gain.value = (gain == null ? .5 : gain) * (distant ? .55 : 1);
    var conv = ctx.createBiquadFilter(); conv.type = "lowpass";
    conv.frequency.value = distant ? 1600 : 5200;
    out.connect(conv); conv.connect(sfxGain);
    var base = distant ? 196 : 220;
    [[1, .5, 9], [2.02, .28, 7], [2.74, .16, 5.5], [3.94, .1, 4], [5.14, .06, 3], [6.9, .03, 2]].forEach(function (p, i) {
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.type = "sine"; o.frequency.value = base * p[0] * (1 + (Math.random() - .5) * .004);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(p[1] * .22, t + .012);
      g.gain.exponentialRampToValueAtTime(.0001, t + p[2]);
      o.connect(g); g.connect(out); o.start(t); o.stop(t + p[2] + .1);
    });
    /* strike transient */
    var nb = ctx.createBufferSource(); nb.buffer = noiseBuffer(.06);
    var nf = ctx.createBiquadFilter(); nf.type = "highpass"; nf.frequency.value = 2200;
    var ng = ctx.createGain(); ng.gain.setValueAtTime(.12, t); ng.gain.exponentialRampToValueAtTime(.0001, t + .12);
    nb.connect(nf); nf.connect(ng); ng.connect(out); nb.start(t);
  };

  A.drum = function () {
    if (!A.ready || A.muted) return;
    var t = now();
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = "sine"; o.frequency.setValueAtTime(110, t); o.frequency.exponentialRampToValueAtTime(46, t + .28);
    g.gain.setValueAtTime(.7, t); g.gain.exponentialRampToValueAtTime(.001, t + .55);
    o.connect(g); g.connect(sfxGain); o.start(t); o.stop(t + .6);
    var nb = ctx.createBufferSource(); nb.buffer = noiseBuffer(.08);
    var f = ctx.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 900;
    var ng = ctx.createGain(); ng.gain.setValueAtTime(.25, t); ng.gain.exponentialRampToValueAtTime(.001, t + .1);
    nb.connect(f); f.connect(ng); ng.connect(sfxGain); nb.start(t);
  };

  A.wood = function (pitch) {
    if (!A.ready || A.muted) return;
    var t = now();
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = "triangle"; o.frequency.value = pitch || 420;
    g.gain.setValueAtTime(.22, t); g.gain.exponentialRampToValueAtTime(.001, t + .12);
    o.connect(g); g.connect(sfxGain); o.start(t); o.stop(t + .14);
  };

  A.whoosh = function () {
    if (!A.ready || A.muted) return;
    var t = now();
    var nb = ctx.createBufferSource(); nb.buffer = noiseBuffer(.7);
    var f = ctx.createBiquadFilter(); f.type = "bandpass"; f.frequency.setValueAtTime(300, t);
    f.frequency.linearRampToValueAtTime(1400, t + .5); f.Q.value = .9;
    var g = ctx.createGain(); g.gain.setValueAtTime(.001, t);
    g.gain.linearRampToValueAtTime(.18, t + .18); g.gain.exponentialRampToValueAtTime(.001, t + .7);
    nb.connect(f); f.connect(g); g.connect(sfxGain); nb.start(t);
  };

  A.chime = function () {
    if (!A.ready || A.muted) return;
    var t = now();
    [[880, .18, 1.6], [1320, .1, 1.1], [1760, .05, .8]].forEach(function (p) {
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.type = "sine"; o.frequency.value = p[0] * (1 + (Math.random() - .5) * .01);
      g.gain.setValueAtTime(.0001, t); g.gain.linearRampToValueAtTime(p[1] * .3, t + .02);
      g.gain.exponentialRampToValueAtTime(.0001, t + p[2]);
      o.connect(g); g.connect(sfxGain); o.start(t); o.stop(t + p[2] + .05);
    });
  };

  A.setVolume = function (kind, v) {
    vol[kind] = v;
    if (!A.ready) return;
    if (kind === "ambient") ambientGain.gain.setTargetAtTime(A.muted ? 0 : v * duck, now(), .4);
    else sfxGain.gain.setTargetAtTime(A.muted ? 0 : v, now(), .2);
  };
  /* 廟祝語音播放時壓低 BGM；停止／結束／關閉即回復。duck 為 1 表示正常。 */
  var duck = 1;
  A.duck = function (factor) {
    duck = factor == null ? .22 : Math.max(.05, Math.min(1, factor));
    if (A.ready) ambientGain.gain.setTargetAtTime(A.muted ? 0 : vol.ambient * duck, now(), .22);
    return duck;
  };
  A.unduck = function () {
    duck = 1;
    if (A.ready) ambientGain.gain.setTargetAtTime(A.muted ? 0 : vol.ambient, now(), .4);
    return duck;
  };
  A.duckState = function () { return duck; };
  A.toggleMute = function () {
    A.muted = !A.muted;
    if (!A.ready) return A.muted;
    ambientGain.gain.setTargetAtTime(A.muted ? 0 : vol.ambient, now(), .4);
    sfxGain.gain.setTargetAtTime(A.muted ? 0 : vol.sfx, now(), .2);
    return A.muted;
  };
  A.volumes = vol;
})();
