/* 文武廟 · 擲筊核心（共用）
   以瀏覽器密碼學亂數擲筊，機率公開：聖筊 50%、笑筊 25%、陰筊 24.9%、立筊 0.1%。
   立筊視為「這一擲不算」：不算聖筊，也不中斷連續聖筊。 */
(function () {
  "use strict";
  function rand() {
    try {
      var a = new Uint32Array(1);
      (window.crypto || window.msCrypto).getRandomValues(a);
      return a[0] / 4294967296;
    } catch (e) {
      return Math.random();
    }
  }
  function roll() {
    var r = rand();
    if (r < 0.001) return "li";        // 0.1% 立筊
    if (r < 0.501) return "sheng";     // 50%
    if (r < 0.751) return "xiao";      // 25%
    return "yin";                      // 24.9%
  }
  window.DIV = {
    rand: rand,
    rollJiao: roll,
    prob: { sheng: 0.5, xiao: 0.25, yin: 0.249, li: 0.001 },
    LABEL: { sheng: "聖筊", xiao: "笑筊", yin: "陰筊", li: "立筊" }
  };
})();
