/* 文武廟 · 求籤互動（籤筒 · 搖籤 · 擲筊確認）
   獨立模組：自成 DOM + scoped CSS，不依賴、不改動 3D 場景與移動控制。
   API：
     MM.LotRitual.open({ lots, onConfirm(L), onCancel() })
     MM.LotRitual.close()      // 等同取消，不會回傳籤
     MM.LotRitual.isOpen()
   規則：
     · 只顯示籤號，永不在此模組顯示籤詩（確認後交由頁面 showLot）。
     · 一聖筊（一平一凸）方為確認，onConfirm 只會呼叫一次。
     · 笑筊／陰筊只提示再擲或重新求，候選籤號不變。
     · 關閉、Esc、取消皆走 onCancel，且只呼叫一次。
   聲明：本站求籤為數碼文化體驗，不保證占卜準確；禮儀以親身參拜為準。
*/
(function () {
  "use strict";
  var MM = window.MM = window.MM || {};
  if (MM.LotRitual) return;
  /* ---- 外語：只翻介面，不碰籤文 ---- */
  var LANG = (String(location.search).match(/[?&]lang=(en|ja|th)\b/) || [])[1] || "";
  var DICT = null;
  function tr(s, vars) {
    if (typeof s !== "string") return s;
    var out = (DICT && Object.prototype.hasOwnProperty.call(DICT, s)) ? DICT[s] : s;
    if (vars) for (var k in vars) out = out.split("{" + k + "}").join(vars[k]);
    return out;
  }
  if (LANG) {
    var sc = document.createElement("script");
    sc.src = "locales/ritual.js?v=1";
    sc.onload = function () { DICT = window.RITUAL_I18N && window.RITUAL_I18N[LANG]; };
    document.head.appendChild(sc);
  }

  var TILT = -16;            // 俯視角
  var SPIN = -14;            // 初始水平轉角（見到筒身側面）
  var TUBE_H = 150;
  var TUBE_R = 56;
  var STICK_H = 210;
  var PANELS = 14;
  var HOLD_MS = 550;         // 按住超過此時間，放手即抽籤
  var AUTO_SHAKE_MS = 950;   // 一鍵搖籤
  var DRAW_MS = 780;         // 籤枝滑出
  var JIAO_MS = 1150;        // 擲筊翻滾
  var CONFIRM_DELAY = 1900;  // 聖筊後自動確認（亦可按鈕即時確認）

  var CSS = [
    '.mmr-root{position:fixed;inset:0;z-index:88;display:flex;align-items:center;justify-content:center;',
    'padding:calc(env(safe-area-inset-top,0px) + 10px) 10px calc(env(safe-area-inset-bottom,0px) + 10px);',
    'font-family:var(--sans,system-ui,sans-serif);color:var(--ink,#f7ecd6);-webkit-tap-highlight-color:transparent}',
    '.mmr-scrim{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 38%,rgba(58,22,16,.93),rgba(8,3,2,.97) 78%);',
    'opacity:0;transition:opacity .3s ease}',
    '.mmr-root.on .mmr-scrim{opacity:1}',
    '.mmr-card{position:relative;width:100%;max-width:430px;max-height:100%;display:flex;flex-direction:column;',
    'border-radius:20px;border:1px solid rgba(230,184,100,.34);overflow:hidden;',
    'background:linear-gradient(172deg,#2b120d 0%,#1a0b07 58%,#120705 100%);',
    'box-shadow:0 24px 70px rgba(0,0,0,.72),inset 0 1px 0 rgba(255,225,180,.08);',
    'transform:translateY(14px) scale(.985);opacity:0;transition:transform .34s cubic-bezier(.22,.72,.2,1),opacity .3s ease}',
    '.mmr-root.on .mmr-card{transform:none;opacity:1}',

    /* ---- head ---- */
    '.mmr-head{display:flex;align-items:flex-start;gap:10px;padding:15px 15px 6px;flex:0 0 auto}',
    '.mmr-head h2{margin:0;font-family:var(--serif,serif);font-weight:400;font-size:16.5px;letter-spacing:.2em;color:var(--gold,#e6b864)}',
    '.mmr-sub{margin:4px 0 0;font-size:10px;letter-spacing:.14em;color:#9d7d54}',
    '.mmr-x{margin-left:auto;width:32px;height:32px;flex:0 0 auto;border-radius:50%;border:1px solid rgba(230,184,100,.36);',
    'display:grid;place-items:center;color:#c9b28c;background:rgba(0,0,0,.2);font-size:13px}',

    /* ---- stage ---- */
    '.mmr-stage{position:relative;flex:0 0 auto;height:300px;margin:2px 10px 0;overflow:hidden;touch-action:none;user-select:none;cursor:grab}',
    '.mmr-stage.hold{cursor:grabbing}',
    '.mmr-stage.dim .mmr-scene{opacity:0}',
    '.mmr-scene{position:absolute;inset:0;perspective:820px;perspective-origin:50% 42%;transition:opacity .35s ease}',
    '.mmr-rig{position:absolute;left:50%;top:50%;width:0;height:0;transform-style:preserve-3d;',
    'transform:translateY(18px) rotateX(' + TILT + 'deg) rotateY(' + SPIN + 'deg)}',
    '.mmr-shake{position:absolute;left:0;top:0;width:0;height:0;transform-style:preserve-3d;will-change:transform}',

    /* 筒身：14 塊面板圍成圓柱 */
    '.mmr-tube{position:absolute;left:0;top:0;width:0;height:0;transform-style:preserve-3d}',
    '.mmr-panel{position:absolute;left:0;top:' + (-TUBE_H / 2) + 'px;height:' + TUBE_H + 'px;margin-left:-8.6px;width:17.6px;',
    'background:linear-gradient(180deg,rgba(255,214,150,.13) 0 3px,rgba(0,0,0,.5) 3px 11px,transparent 11px),',
    'linear-gradient(0deg,rgba(230,184,100,.42) 0 2px,transparent 2px),',
    'linear-gradient(90deg,#3a0a06 0%,#6d1410 26%,#8e1c14 48%,#671211 72%,#350a06 100%);',
    'border-top:1px solid rgba(230,184,100,.5);box-shadow:inset 0 -18px 24px rgba(0,0,0,.45)}',
    '.mmr-panel::after{content:"";position:absolute;left:0;right:0;top:41%;height:2px;background:rgba(230,184,100,.32)}',
    '.mmr-lip{position:absolute;left:0;top:' + (-TUBE_H / 2 - TUBE_R - 2) + 'px;width:' + (TUBE_R * 2 + 4) + 'px;height:' + (TUBE_R * 2 + 4) + 'px;',
    'margin-left:' + (-(TUBE_R + 2)) + 'px;margin-top:0;border-radius:50%;',
    'transform:scaleY(.3);border:2px solid rgba(230,184,100,.5);background:transparent;',
    'box-shadow:inset 0 5px 14px rgba(0,0,0,.5),0 0 0 1px rgba(0,0,0,.35)}',

    /* 籤枝（多根，微微散開） */
    '.mmr-sticks{position:absolute;left:0;top:' + (TUBE_H / 2) + 'px;width:0;height:0;transform-style:preserve-3d}',
    '.mmr-stick{position:absolute;left:0;bottom:0;width:6px;height:' + STICK_H + 'px;margin-left:-3px;border-radius:2px 2px 1px 1px;',
    'background:linear-gradient(90deg,#8a6a3c,#f2dcae 38%,#d8bb84 62%,#7d5c33);',
    'box-shadow:0 1px 0 rgba(0,0,0,.5);',
    'mask-image:linear-gradient(180deg,#000 0 17%,rgba(0,0,0,.55) 24%,transparent 31%);',
    '-webkit-mask-image:linear-gradient(180deg,#000 0 17%,rgba(0,0,0,.55) 24%,transparent 31%)}',
    '.mmr-stick::after{content:"";position:absolute;left:0;right:0;top:0;height:9px;border-radius:2px 2px 0 0;background:#a3231a}',
    /* v96：取香圖示 — 三炷清香，香頭帶光暈 */
    '.mmr-take{display:flex;gap:16px;justify-content:center;padding:12px 0 4px}',
    '.mmr-take i{display:block;width:5px;height:64px;border-radius:3px;position:relative;',
    'background:linear-gradient(90deg,#8a6a3c,#f2dcae 40%,#d8bb84 60%,#7d5c33)}',
    '.mmr-take i::before{content:"";position:absolute;left:-1px;right:-1px;top:-8px;height:10px;border-radius:3px;',
    'background:#ff9a4d;box-shadow:0 0 12px rgba(255,150,70,.85)}',
    '.mmr-stick.gone{opacity:0;transition:opacity .3s ease}',

    /* 滑出的籤 */
    '.mmr-drawn{position:absolute;left:0;top:0;width:28px;height:172px;margin-left:-14px;transform-style:preserve-3d;',
    'opacity:0;pointer-events:none;transform:translate3d(0,26px,26px) rotateZ(2deg) scaleY(.72);transform-origin:50% 100%;',
    'transition:transform ' + DRAW_MS + 'ms cubic-bezier(.18,.7,.24,1),opacity .34s ease}',
    '.mmr-drawn.show{opacity:1;transform:translate3d(76px,-118px,80px) rotateZ(-12deg)}',
    '.mmr-drawn i{position:absolute;inset:0;border-radius:3px;display:block;',
    'background:linear-gradient(90deg,#8f6c3c,#f8e6bd 34%,#e6cb98 66%,#7f5c31);',
    'border:1px solid rgba(60,26,12,.55);box-shadow:0 4px 10px rgba(0,0,0,.5)}',
    '.mmr-drawn i::after{content:"";position:absolute;left:0;right:0;top:0;height:16px;border-radius:2px 2px 0 0;background:linear-gradient(180deg,#a3231a,#7d150f)}',
    '.mmr-drawn .num{position:absolute;left:3px;right:3px;top:32px;bottom:14px;display:flex;flex-direction:column;',
    'align-items:center;justify-content:center;font-family:var(--serif,serif);color:#7a120c;',
    'font-size:13.5px;line-height:1;letter-spacing:0}',
    '.mmr-drawn .num b{font-size:13.5px;font-weight:500;letter-spacing:-.02em;line-height:1}',
    '.mmr-drawn.d3 .num b{font-size:11px;letter-spacing:-.04em}',

    /* 籤號印章 */
    '.mmr-seal{display:none;align-items:center;gap:9px;padding:5px 12px;border-radius:999px;',
    'border:1px solid rgba(230,184,100,.45);background:rgba(20,9,6,.72);margin:0 0 8px;align-self:flex-start}',
    '.mmr-seal.show{display:inline-flex;animation:mmrIn .28s ease both}',
    '.mmr-seal span{font-size:9.5px;letter-spacing:.2em;color:#a98d63}',
    '.mmr-seal b{font-family:var(--serif,serif);font-weight:400;font-size:15px;letter-spacing:.08em;color:var(--gold,#e6b864)}',
    '@keyframes mmrIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}',

    /* ---- 筊杯 ---- */
    '.mmr-jiao{position:absolute;inset:0;opacity:0;pointer-events:none;transition:opacity .32s ease}',
    '.mmr-jiao.on{opacity:1}',
    '.mmr-jmat{position:absolute;left:50%;bottom:44px;width:252px;height:74px;margin-left:-126px;border-radius:50%;',
    'background:radial-gradient(ellipse at 50% 40%,rgba(230,184,100,.14),rgba(0,0,0,.5) 72%);',
    'border:1px solid rgba(230,184,100,.16);box-shadow:0 14px 34px rgba(0,0,0,.5) inset}',
    '.mmr-cup{position:absolute;left:50%;top:auto;bottom:64px;width:74px;height:58px;margin-left:-37px;',
    'border-radius:50% 50% 16% 16%/78% 78% 26% 26%;transform-style:preserve-3d;will-change:transform;',
    'box-shadow:0 12px 16px rgba(0,0,0,.4)}',
    '.mmr-cup.c1{margin-left:-104px}',
    '.mmr-cup.c2{margin-left:30px}',
    '.mmr-cup .face{position:absolute;inset:0;border-radius:inherit;display:block;backface-visibility:hidden;transition:none}',
    '.mmr-cup .face.flat{background:radial-gradient(ellipse at 42% 30%,#f3e3c1,#d9c199 46%,#ab8f66 76%,#7d6544);',
    'border:1px solid rgba(120,88,52,.7);box-shadow:inset 0 -10px 18px rgba(90,62,32,.45)}',
    '.mmr-cup .face.flat::after{content:"";position:absolute;left:14px;right:14px;bottom:16px;height:2px;border-radius:2px;background:rgba(122,18,12,.55)}',
    '.mmr-cup .face.dome{transform:rotateY(180deg);background:radial-gradient(ellipse at 40% 26%,#e0503a,#a3231a 42%,#6d1410 78%,#3d0a07);',
    'border:1px solid rgba(255,206,160,.4);box-shadow:inset -6px -10px 20px rgba(0,0,0,.5),inset 6px 8px 16px rgba(255,190,140,.18)}',
    '.mmr-cup .face.dome::after{content:"";position:absolute;left:18px;top:16px;width:14px;height:9px;border-radius:50%;',
    'background:radial-gradient(ellipse,rgba(255,235,205,.75),transparent 72%)}',

    /* ---- 說明與按鈕 ---- */
    '.mmr-body{flex:1 1 auto;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding:4px 15px 12px;touch-action:pan-y}',
    '.mmr-status{margin:2px 0 0;font-size:13px;line-height:1.72;color:#f2e2c6;letter-spacing:.02em}',
    '.mmr-status b{color:var(--gold,#e6b864);font-weight:500}',
    '.mmr-tip{margin:7px 0 0;font-size:11px;line-height:1.7;color:#a98d63}',
    '.mmr-bar{height:2px;border-radius:2px;background:rgba(230,184,100,.14);margin:10px 0 0;overflow:hidden}',
    '.mmr-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#7d5a25,var(--gold,#e6b864));transition:width .08s linear}',
    '.mmr-acts{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}',
    '.mmr-btn{flex:1 1 auto;min-width:104px;min-height:44px;padding:11px 14px;border-radius:11px;',
    'border:1px solid rgba(230,184,100,.36);background:rgba(52,20,14,.72);color:var(--ink,#f7ecd6);',
    'font:inherit;font-size:13px;letter-spacing:.08em;transition:background .18s,border-color .18s}',
    '.mmr-btn.primary{background:linear-gradient(180deg,#9c2a1c,#6d1a12);border-color:var(--gold,#e6b864);color:#ffeecb}',
    '.mmr-btn.ghost{background:transparent}',
    '.mmr-btn:disabled{opacity:.45}',
    '.mmr-btn:active{transform:translateY(1px)}',
    '.mmr-btn:focus-visible,.mmr-x:focus-visible{outline:2px solid var(--gold,#e6b864);outline-offset:2px}',
    '.mmr-fine{flex:0 0 auto;margin:0;padding:0 15px calc(env(safe-area-inset-bottom,0px) + 11px);',
    'font-size:9.5px;line-height:1.6;letter-spacing:.04em;color:#7d6444}',

    /* ---- 窄機 / 矮機 ---- */
    '@media (max-height:700px){.mmr-stage{height:246px}.mmr-scene{perspective:760px}}',
    '@media (max-width:400px){.mmr-stage{height:280px;margin:2px 6px 0}.mmr-head{padding:13px 13px 4px}',
    '.mmr-body{padding:4px 13px 10px}.mmr-fine{padding:0 13px calc(env(safe-area-inset-bottom,0px) + 10px)}',
    '.mmr-btn{min-width:0;flex:1 1 44%}}',

    '@media (prefers-reduced-motion:reduce){',
    '.mmr-card,.mmr-scrim,.mmr-seal,.mmr-jiao,.mmr-drawn{transition-duration:.16s}',
    '.mmr-drawn.show{transition:opacity .18s ease}',
    '.mmr-shake{transition:none}}'
  ].join("\n");

  var HTML = [
    '<div class="mmr-scrim" data-close="1"></div>',
    '<div class="mmr-card">',
    '  <div class="mmr-head">',
    '    <div><h2 id="mmrTitle">求籤請示</h2><p class="mmr-sub">武帝靈簽 · 關聖帝君一百籤（雷雨師）</p></div>',
    '    <button class="mmr-x" id="mmrX" aria-label="關閉求籤">✕</button>',
    '  </div>',
    '  <div class="mmr-stage" id="mmrStage">',
    '    <div class="mmr-scene" aria-hidden="true">',
    '      <div class="mmr-rig"><div class="mmr-shake" id="mmrShake">',
    '        <div class="mmr-tube" id="mmrTube"><div class="mmr-lip"></div></div>',
    '        <div class="mmr-sticks" id="mmrSticks"></div>',
    '        <div class="mmr-drawn" id="mmrDrawn"><i></i><span class="num" id="mmrNum"></span></div>',
    '      </div></div>',
    '    </div>',
    '    <div class="mmr-jiao" id="mmrJiao" aria-hidden="true">',
    '      <div class="mmr-jmat"></div>',
    '      <div class="mmr-cup c1" id="mmrCup1"><span class="face flat"></span><span class="face dome"></span></div>',
    '      <div class="mmr-cup c2" id="mmrCup2"><span class="face flat"></span><span class="face dome"></span></div>',
    '    </div>',
    '  </div>',
    '  <div class="mmr-body">',
    '    <div class="mmr-seal" id="mmrSeal" hidden><span>籤號</span><b id="mmrSealNo">第 1 籤</b></div>',
    '    <p class="mmr-status" id="mmrStatus" role="status" aria-live="polite"></p>',
    '    <div class="mmr-bar" id="mmrBarWrap"><i id="mmrBar"></i></div>',
    '    <p class="mmr-tip" id="mmrTip"></p>',
    '    <div class="mmr-acts" id="mmrActs"></div>',
    '  </div>',
    '  <p class="mmr-fine">數碼文化體驗 · 不保證占卜準確 · 禮儀以親身參拜為準</p>',
    '</div>'
  ].join("\n");

  var S = {
    open: false, phase: "ready", lots: null, cand: null, incenseTaken: false,
    onConfirm: null, onCancel: null,
    holding: false, holdStart: 0, clat: -1,
    raf: 0, timers: [], lis: [], finished: false,
    restored: null, root: null, nodes: {}, mq: null, mqFn: null,
    rng: null, forcedJiao: null, jiaoBusy: false, need: 1, sheng: 0
  };

  /* ---------- 小工具 ---------- */
  function rnd() { return (S.rng || Math.random)(); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function easeOutCubic(p) { return 1 - Math.pow(1 - p, 3); }
  function prefReduced() {
    return !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }
  function later(fn, ms) {
    var id = setTimeout(function () {
      S.timers = S.timers.filter(function (t) { return t !== id; });
      if (S.open) fn();
    }, ms);
    S.timers.push(id);
    return id;
  }
  function clearTimers() { S.timers.forEach(clearTimeout); S.timers = []; }
  function stopRaf() { if (S.raf) { cancelAnimationFrame(S.raf); S.raf = 0; } }
  function on(node, type, fn, opt) {
    node.addEventListener(type, fn, opt);
    S.lis.push([node, type, fn, opt]);
  }

  /* ---------- 建立 / 銷毀 ---------- */
  function injectStyle() {
    if (document.getElementById("mmr-style")) return;
    var st = document.createElement("style");
    st.id = "mmr-style";
    st.textContent = CSS;
    document.head.appendChild(st);
  }
  function build() {
    injectStyle();
    var root = document.createElement("div");
    root.className = "mmr-root";
    root.id = "mmrRoot";
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    root.setAttribute("aria-labelledby", "mmrTitle");
    root.innerHTML = tr(HTML);
    document.body.appendChild(root);
    S.root = root;
    S.nodes = {
      card: root.querySelector(".mmr-card"),
      stage: root.querySelector("#mmrStage"),
      shake: root.querySelector("#mmrShake"),
      tube: root.querySelector("#mmrTube"),
      sticks: root.querySelector("#mmrSticks"),
      drawn: root.querySelector("#mmrDrawn"),
      num: root.querySelector("#mmrNum"),
      seal: root.querySelector("#mmrSeal"),
      sealNo: root.querySelector("#mmrSealNo"),
      jiao: root.querySelector("#mmrJiao"),
      cup: [root.querySelector("#mmrCup1"), root.querySelector("#mmrCup2")],
      status: root.querySelector("#mmrStatus"),
      tip: root.querySelector("#mmrTip"),
      barWrap: root.querySelector("#mmrBarWrap"),
      bar: root.querySelector("#mmrBar"),
      acts: root.querySelector("#mmrActs")
    };
    buildTube(root);
    bindChrome(root);
  }
  function buildTube(root) {
    var tube = S.nodes.tube;
    for (var i = 0; i < PANELS; i++) {
      var a = i * 360 / PANELS;
      var d = document.createElement("div");
      d.className = "mmr-panel";
      d.style.transform = "rotateY(" + a + "deg) translateZ(" + TUBE_R + "px)";
      // 依角度給一點亮度差，圓柱才有轉折感
      var rel = (a + SPIN) * Math.PI / 180;
      d.style.filter = "brightness(" + (0.62 + 0.5 * Math.max(0, Math.cos(rel - 0.9))).toFixed(2) + ")";
      tube.appendChild(d);
    }
    // 多根籤枝：外圈 9 根、內圈 5 根
    var sticks = S.nodes.sticks;
    for (var k = 0; k < 9; k++) addStick(sticks, k * 40 + 7, 30, (k % 3 - 1) * 2.2, 1);
    for (var m = 0; m < 5; m++) addStick(sticks, m * 72 + 24, 15, (m % 3 - 1) * 3.4, 0.94);
  }
  function addStick(box, deg, radius, tilt, scale) {
    var s = document.createElement("div");
    s.className = "mmr-stick";
    s.style.transform = "rotateY(" + deg + "deg) translateZ(" + radius + "px) rotateZ(" + tilt + "deg)";
    s.style.height = (STICK_H * scale) + "px";
    box.appendChild(s);
  }

  /* ---------- 畫面狀態 ---------- */
  function showSeal(txt) {
    if (!S.nodes.seal) return;
    if (txt) S.nodes.sealNo.textContent = txt;
    S.nodes.seal.hidden = false;
    S.nodes.seal.classList.add("show");
  }
  function hideSeal() {
    if (!S.nodes.seal) return;
    S.nodes.seal.classList.remove("show");
    S.nodes.seal.hidden = true;
  }
  function setStatus(txt) { if (S.nodes.status) S.nodes.status.innerHTML = tr(txt); }
  function setTip(txt) { if (S.nodes.tip) S.nodes.tip.textContent = tr(txt); }
  function setBar(p) {
    if (!S.nodes.bar) return;
    S.nodes.bar.style.width = p <= 0 ? "0%" : Math.round(p * 100) + "%";
    S.nodes.barWrap.style.opacity = p > 0 ? "1" : "0";
  }
  function acts(html) { if (S.nodes.acts) S.nodes.acts.innerHTML = tr(html); }
  function btn(id) { return S.nodes.acts ? S.nodes.acts.querySelector("#" + id) : null; }

  /* v96：求籤第一步 — 先喺案頭香盤取三炷清香，取咗先可以搖籤。
     3D 場景香案左邊已有香盤（world.js buildDetails，v98 由供桌右邊移過嚟，對返取香動畫嘅企位），呢度係同一儀式嘅介面一步。 */
  function renderIncense() {
    setStatus("第一步：<b>先在案頭香盤取三炷清香</b>。<br>香盤就喺香案左邊，取香後合十默念姓名、生辰與所求，再搖籤筒。");
    setTip("取咗香先可以搖籤；未取香之前，籤筒唔會郁。");
    setBar(0);
    acts('<div class="mmr-take" aria-hidden="true"><i></i><i></i><i></i></div>' +
      '<button class="mmr-btn primary" id="mmrTake">取三炷清香</button>' +
      '<button class="mmr-btn ghost" id="mmrCancel2">取消</button>');
    var tk = btn("mmrTake");
    if (tk) tk.onclick = function () {
      S.incenseTaken = true;
      S.phase = "ready";
      renderReady();
      setStatus("已取三炷清香。<br>先靜心，默念姓名、生辰，以及一件最想釐清的事。");
    };
    var cx = btn("mmrCancel2");
    if (cx) cx.onclick = function () { cancel(); };
  }
  function renderReady() {
    setStatus("先靜心，默念姓名、生辰，以及一件最想釐清的事。");
    setTip("按住下方按鈕或籤筒搖動，鬆手後會滑出一支籤；輕觸一下亦可快速搖籤。");
    setBar(0);
    acts('<button class="mmr-btn primary" id="mmrHold" aria-describedby="mmrTip">按住搖籤</button>' +
      '<button class="mmr-btn ghost" id="mmrOne">一鍵搖籤</button>' +
      '<button class="mmr-btn ghost" id="mmrCancel">取消</button>');
    wireHold();
    var one = btn("mmrOne");
    if (one) one.onclick = function () { oneTap(); };
    var cx = btn("mmrCancel");
    if (cx) cx.onclick = function () { cancel(); };
  }
  function renderDrawn() {
    S.sheng = 0;
    var n = S.cand ? S.cand.n : 0;
    setStatus(tr("籤枝已出：<b>第 {n} 籤</b>。<br>先別急著看籤文 — 擲筊請示，得聖筊方為確認。", { n: n }));
    setTip("筊杯一面平、一面凸：一平一凸為聖筊（應允），兩平為笑筊，兩凸為陰筊。");
    acts('<button class="mmr-btn primary" id="mmrThrow">擲筊請示</button>' +
      '<button class="mmr-btn ghost" id="mmrRedraw">重新搖籤</button>');
    var t = btn("mmrThrow");
    if (t) t.onclick = function () { throwJiao(); };
    var r = btn("mmrRedraw");
    if (r) r.onclick = function () { resetDraw(true); };
  }
  function renderResult(res) {
    var need = S.need === 3 ? 3 : 1;
    if (res === "sheng" && (S.sheng || 0) < need) {
      setStatus(tr("聖筊 · 一平一凸 — 已得 <b>{got} / {need}</b> 聖筊。<br>請再擲，連續 {need} 個聖筊方為確認。", { got: S.sheng, need: need }));
      setTip("中途出現笑筊或陰筊，連續聖筊會重新計算。");
      resultActs();
    } else if (res === "sheng") {
      setStatus(tr("聖筊 · 一平一凸，<b>神明應允</b>。<br>此籤為第 {n} 籤，可看籤文。", { n: (S.cand ? S.cand.n : "") }));
      setTip(need === 3 ? "已連得三聖筊。籤詩與解說只會在確認後顯示。" : "籤詩與解說只會在確認後顯示；本頁不代為解籤。");
      acts('<button class="mmr-btn primary" id="mmrView">查看籤文</button>');
      var v = btn("mmrView");
      if (v) v.onclick = function () { finish(); };
    } else if (res === "xiao") {
      setStatus("笑筊 · 兩平。<b>神明含笑未答</b> — 問題未夠清楚，或時機未到。");
      setTip("可把所問整理成一句具體的話，再擲一次；籤號不會因而改變。");
      resultActs();
    } else {
      setStatus("陰筊 · 兩凸。<b>神明未允</b> — 宜再思量，或換一個問法。");
      setTip("同一支籤可再擲請示；如覺所問不宜，可重新搖籤另求。");
      resultActs();
    }
  }
  function resultActs() {
    acts('<button class="mmr-btn primary" id="mmrAgain">再擲一次</button>' +
      '<button class="mmr-btn ghost" id="mmrRedraw2">重新搖籤</button>' +
      '<button class="mmr-btn ghost" id="mmrClose2">關閉</button>');
    var a = btn("mmrAgain");
    if (a) a.onclick = function () { throwJiao(); };
    var r = btn("mmrRedraw2");
    if (r) r.onclick = function () { resetDraw(true); };
    var c = btn("mmrClose2");
    if (c) c.onclick = function () { cancel(); };
  }

  /* ---------- 搖籤 ---------- */
  function wireHold() {
    var h = btn("mmrHold");
    if (!h) return;
    var synth = 0; // 標記此輪由指標處理，避免 click 重複觸發
    on(h, "pointerdown", function (e) {
      if (S.phase !== "ready" || e.button > 0) return;
      e.preventDefault();
      try { h.setPointerCapture(e.pointerId); } catch (x) { }
      startHold();
      synth = Date.now();
    });
    on(h, "pointerup", function (e) { if (S.holding) { e.preventDefault(); releaseHold(); } });
    on(h, "pointercancel", function () { abortHold(); });
    on(h, "lostpointercapture", function () { if (S.holding) abortHold(); });
    on(h, "keydown", function (e) {
      if (e.key !== " " && e.key !== "Enter" && e.key !== "Spacebar") return;
      e.preventDefault();
      if (!e.repeat && S.phase === "ready" && !S.holding) startHold();
    });
    on(h, "keyup", function (e) {
      if (e.key !== " " && e.key !== "Enter" && e.key !== "Spacebar") return;
      e.preventDefault();
      if (S.holding) releaseHold();
    });
    on(h, "click", function (e) {
      // 無 pointer 事件（輔助技術或合成點擊）時仍可一鍵搖籤
      if (S.phase !== "ready") return;
      if (Date.now() - synth < 700) return;
      e.preventDefault();
      oneTap();
    });
  }

  function startHold() {
    if (S.phase !== "ready" || S.holding) return;
    S.holding = true;
    S.holdStart = performance.now();
    S.nodes.stage.classList.add("hold");
    clatter(0);
    setTip("持續搖動中…鬆手即抽籤。");
    if (prefReduced()) {
      S.raf = 0;
      setBar(0.35);
      later(function () { if (S.holding) setBar(1); }, HOLD_MS);
      return;
    }
    S.raf = requestAnimationFrame(shakeTick);
  }
  function shakeTick(ts) {
    if (!S.holding) { S.raf = 0; return; }
    var t = (ts - S.holdStart) / 1000;
    var ramp = 0.6 + Math.min(1.6, t * 2.4);
    var rx = Math.sin(t * 15.5) * 3.0 * ramp;
    var rz = Math.sin(t * 19.5 + 0.7) * 3.6 * ramp;
    var ry = Math.sin(t * 10.5) * 5.6 * ramp;
    var yy = Math.abs(Math.sin(t * 19.5)) * 3.4;
    S.nodes.shake.style.transform =
      "translate3d(" + (Math.sin(t * 21) * 2.4).toFixed(2) + "px," + (-yy).toFixed(2) + "px,0)" +
      " rotateX(" + rx.toFixed(2) + "deg) rotateY(" + ry.toFixed(2) + "deg) rotateZ(" + rz.toFixed(2) + "deg)";
    setBar(clamp((ts - S.holdStart) / HOLD_MS, 0, 1));
    if (t > 0.12) clatter(t);
    S.raf = requestAnimationFrame(shakeTick);
  }
  function clatter(t) {
    // 每 150ms 一下木聲；沒有音效模組就靜靜進行
    var n = Math.floor(t / 0.15);
    if (n <= S.clat) return;
    S.clat = n;
    sfx("wood", 420 + ((n * 37) % 160));
  }
  function releaseHold() {
    if (!S.holding) return;
    S.holding = false;
    stopRaf();
    var ms = performance.now() - S.holdStart;
    S.clat = -1;
    S.nodes.shake.style.transform = "";
    S.nodes.stage.classList.remove("hold");
    if (S.phase !== "ready") return;
    if (ms >= HOLD_MS) draw();
    else oneTap();
  }
  function abortHold() {
    if (!S.holding) return;
    S.holding = false;
    S.clat = -1;
    stopRaf();
    S.nodes.shake.style.transform = "";
    S.nodes.stage.classList.remove("hold");
    setBar(0);
    if (S.phase === "ready") { setStatus("先靜心，默念姓名、生辰，以及一件最想釐清的事。"); setTip("按住下方按鈕或籤筒搖動，鬆手後會滑出一支籤。"); }
  }

  function oneTap() {
    if (S.phase !== "ready" || S.holding) return;
    S.phase = "auto";
    acts("");
    setTip("搖籤中…");
    S.nodes.stage.classList.add("hold");
    var t0 = performance.now();
    if (!prefReduced()) {
      (function tick(ts) {
        if (S.phase !== "auto") return;
        var t = (ts - t0) / 1000;
        var ramp = 0.65 + Math.min(1.6, t * 2.6);
        S.nodes.shake.style.transform =
          "translate3d(" + (Math.sin(t * 22) * 2.6).toFixed(2) + "px," + (-Math.abs(Math.sin(t * 20)) * 3.6).toFixed(2) + "px,0)" +
          " rotateX(" + (Math.sin(t * 16) * 3.2 * ramp).toFixed(2) + "deg)" +
          " rotateY(" + (Math.sin(t * 11) * 6 * ramp).toFixed(2) + "deg)" +
          " rotateZ(" + (Math.sin(t * 20) * 4 * ramp).toFixed(2) + "deg)";
        setBar(clamp((ts - t0) / AUTO_SHAKE_MS, 0, 1));
        S.raf = requestAnimationFrame(tick);
      })(t0);
    } else { setBar(1); }
    clatter(0.2);
    later(function () {
      S.nodes.shake.style.transform = "";
      S.nodes.stage.classList.remove("hold");
      draw();
    }, prefReduced() ? 380 : AUTO_SHAKE_MS);
  }

  /* ---------- 抽籤：候選號在第一次抽籤時定下，重擲不改 ---------- */
  function draw() {
    if (S.phase === "drawing" || S.phase === "drawn") return;
    stopRaf();
    S.phase = "drawing";
    if (!S.cand) S.cand = S.lots[Math.floor(rnd() * S.lots.length) % S.lots.length];
    var n = S.cand.n;
    acts("");
    setBar(0);
    setStatus("籤枝滑出中…");
    setTip("記住籤號，再擲筊請示。");
    // 讓筒中一根籤先隱去，再把滑出的籤補上
    var sticks = S.nodes.sticks.querySelectorAll(".mmr-stick");
    if (sticks.length) sticks[(n * 7) % sticks.length].classList.add("gone");
    var num = S.nodes.num;
    num.innerHTML = "<b>" + n + "</b>";
    S.nodes.drawn.classList.toggle("d3", n >= 100);
    S.nodes.sealNo.textContent = "第 " + n + " 籤";
    S.nodes.drawn.classList.add("show");
    setBar(0);
    sfx("wood", 300);
    later(function () {
      if (S.phase !== "drawing") return;
      S.phase = "drawn";
      showSeal();
      renderDrawn();
    }, prefReduced() ? 220 : DRAW_MS);
  }

  function resetDraw(user) {
    if (S.phase === "drawing" || S.jiaoBusy) return;
    S.phase = "ready";
    if (user) S.cand = null;            // 重新求籤：換一支
    var sticks = S.nodes.sticks.querySelectorAll(".mmr-stick.gone");
    for (var i = 0; i < sticks.length; i++) sticks[i].classList.remove("gone");
    S.nodes.drawn.classList.remove("show");
    hideSeal();
    S.nodes.jiao.classList.remove("on");
    S.nodes.stage.classList.remove("dim");
    S.nodes.shake.style.transform = "";
    resetCups();
    renderReady();
  }

  /* ---------- 擲筊 ---------- */
  function resetCups() {
    for (var i = 0; i < 2; i++) {
      var c = S.nodes.cup[i];
      c.style.transform = "translate3d(0,0,0) rotateX(0deg) rotateZ(0deg)";
      c.style.opacity = "1";
    }
  }
  function jiaoValue() {
    if (S.forcedJiao) { var f = S.forcedJiao; S.forcedJiao = null; return f; }
    if (window.DIV) return DIV.rollJiao();
    var r = rnd();
    return r < 0.5 ? "sheng" : r < 0.75 ? "xiao" : "yin";
  }
  function throwJiao() {
    if (S.jiaoBusy) return;
    if (!S.cand) return;
    if (S.phase !== "drawn" && S.phase !== "jiaoResult") return;
    S.jiaoBusy = true;
    S.phase = "jiao";
    acts("");
    setBar(0);
    hideSeal();
    S.nodes.stage.classList.add("dim");
    S.nodes.jiao.classList.add("on");
    setStatus("擲筊中…");
    setTip("筊杯落地：一平一凸為聖筊，兩平為笑筊，兩凸為陰筊。");
    var res = jiaoValue();
    var target = res === "sheng" ? [0, 180] : res === "xiao" ? [0, 0] : [180, 180];
    if (res === "sheng" && rnd() < 0.5) target = [180, 0];
    var reduced = prefReduced();
    var dur = reduced ? 260 : JIAO_MS;
    var t0 = performance.now();
    var seed = [rnd(), rnd(), rnd(), rnd()];
    (function frame(ts) {
      var p = clamp((ts - t0) / dur, 0, 1);
      var e = easeOutCubic(p);
      for (var i = 0; i < 2; i++) {
        var cup = S.nodes.cup[i];
        if (reduced) {
          cup.style.transform = "rotateX(" + target[i] + "deg)";
          continue;
        }
        var arc = Math.sin(Math.PI * Math.min(1, p * 1.12)) * (86 + 22 * i);
        var spin = (1 - e) * 360 * (3 + i) * (seed[i] > 0.5 ? 1 : -1);
        var tilt = (1 - e) * (26 + 12 * seed[i + 2]) * (seed[i] > 0.5 ? 1 : -1);
        var bounce = p > 0.72 ? Math.sin(Math.PI * (p - 0.72) / 0.28) * 7 : 0;
        cup.style.transform =
          "translate3d(" + ((i === 0 ? -1 : 1) * (1 - e) * 12).toFixed(1) + "px," +
          (-(arc * (1 - p) * 0.5) + bounce).toFixed(1) + "px,0)" +
          " rotateX(" + (target[i] + spin).toFixed(1) + "deg)" +
          " rotateZ(" + tilt.toFixed(1) + "deg)";
      }
      if (p < 1) { S.raf = requestAnimationFrame(frame); return; }
      S.raf = 0;
      for (var k = 0; k < 2; k++) {
        S.nodes.cup[k].style.transform = "rotateX(" + target[k] + "deg)";
      }
      sfx("wood", 240);
      later(function () { landJiao(res); }, 170);
    })(t0);
  }
  function landJiao(res) {
    S.jiaoBusy = false;
    S.phase = "jiaoResult";
    if (res === "li") {
      sfx("wood", 240);
      S.nodes.sealNo.textContent = "第 " + S.cand.n + " 籤 · 立筊";
      showSeal();
      setStatus("立筊 · 一片筊杯立起。<b>這一擲不算</b> — 不算聖筊，也不中斷連續聖筊。");
      setTip("立筊機率約 0.1%，民間解讀不一；本頁視為請再擲一次。");
      resultActs();
      return;
    }
    if (res === "sheng") S.sheng = (S.sheng || 0) + 1; else S.sheng = 0;
    var name = res === "sheng" ? "聖筊" : res === "xiao" ? "笑筊" : "陰筊";
    sfx(res === "sheng" ? "chime" : "wood", res === "sheng" ? 0 : 200);
    S.nodes.sealNo.textContent = "第 " + S.cand.n + " 籤 · " + name;
    showSeal();
    renderResult(res);
    if (res === "sheng" && (S.sheng || 0) >= (S.need === 3 ? 3 : 1)) {
      later(function () { finish(); }, CONFIRM_DELAY);
    }
  }

  /* ---------- 確認 / 取消 / 關閉 ---------- */
  function finish() {
    if (S.finished || !S.open) return;
    if (S.phase !== "jiaoResult") return;
    S.finished = true;
    var L = S.cand;
    var cb = S.onConfirm;
    teardown(false);
    try { if (cb) cb(L); } catch (e) { console.error(e); }
  }
  function cancel() {
    if (!S.open) return;
    if (S.finished) return;              // 已確認／已取消，不重複回呼
    S.finished = true;
    var cb = S.onCancel;
    teardown(true);
    try { if (cb) cb(); } catch (e) { console.error(e); }
  }
  function teardown(byUser) {
    S.open = false;
    S.holding = false;
    S.jiaoBusy = false;
    stopRaf();
    clearTimers();
    if (S.mq && S.mqFn) { try { S.mq.removeEventListener("change", S.mqFn); } catch (e) { } }
    S.lis.forEach(function (l) { try { l[0].removeEventListener(l[1], l[2], l[3]); } catch (e) { } });
    S.lis = [];
    if (S.root && S.root.parentNode) S.root.parentNode.removeChild(S.root);
    S.root = null;
    var st = document.getElementById("mmr-style");
    if (st && st.parentNode) st.parentNode.removeChild(st);
    S.nodes = {};
    S.phase = "ready";
    S.cand = null;
    S.lots = null;
    S.onConfirm = null;
    S.onCancel = null;
    S.finished = true;
    if (S.restored && S.restored.focus) { try { S.restored.focus({ preventScroll: true }); } catch (e) { } }
    S.restored = null;
    if (byUser) document.dispatchEvent(new CustomEvent("mm:lotritual:closed"));
  }
  function sfx(kind, pitch) {
    var A = MM.audio;
    if (!A || !A.ready) return;
    try {
      if (kind === "wood" && A.wood) A.wood(pitch || 420);
      else if (kind === "chime" && A.chime) A.chime();
    } catch (e) { }
  }

  /* ---------- 共用 chrome ---------- */
  function bindChrome(root) {
    var x = root.querySelector("#mmrX");
    if (x) x.onclick = function () { cancel(); };
    var scrim = root.querySelector(".mmr-scrim");
    if (scrim) scrim.onclick = function () { cancel(); };
    on(document, "keydown", onKey);
    // 直接按住籤筒本體亦可（只註冊一次，重繪按鈕時不會疊加）
    var stage = S.nodes.stage;
    on(stage, "pointerdown", function (e) {
      if (S.phase !== "ready" || e.button > 0) return;
      e.preventDefault();
      try { stage.setPointerCapture(e.pointerId); } catch (x) { }
      startHold();
    });
    on(stage, "pointerup", function (e) { if (S.holding) { e.preventDefault(); releaseHold(); } });
    on(stage, "pointercancel", function () { abortHold(); });
    on(stage, "contextmenu", function (e) { e.preventDefault(); });
    // 系統切換減動效果時，立即停掉正在跑的抖動
    if (window.matchMedia) {
      S.mq = window.matchMedia("(prefers-reduced-motion: reduce)");
      S.mqFn = function () {
        if (S.mq.matches) { stopRaf(); S.nodes.shake && (S.nodes.shake.style.transform = ""); }
      };
      try { S.mq.addEventListener("change", S.mqFn); } catch (e) { }
    }
  }
  function onKey(e) {
    if (!S.open) return;
    if (e.key === "Escape" || e.key === "Esc") { e.preventDefault(); cancel(); return; }
    if (e.key === "Tab") return trapTab(e);
  }
  function trapTab(e) {
    if (e.key !== "Tab" || !S.root) return;
    var f = S.root.querySelectorAll('button:not([disabled]), [tabindex]:not([tabindex="-1"])');
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  /* ---------- 公開 API ---------- */
  MM.LotRitual = {
    version: "1.0.0",
    open: function (opts) {
      opts = opts || {};
      if (S.open) return false;                       // 防重入
      var lots = opts.lots || window.LOTS;
      if (!lots || !lots.length) return false;
      S.open = true;
      S.finished = false;
      S.phase = "incense";
      S.incenseTaken = false;
      S.cand = null;
      S.lots = lots;
      S.onConfirm = typeof opts.onConfirm === "function" ? opts.onConfirm : null;
      S.need = +opts.needSheng === 3 ? 3 : 1;
      S.sheng = 0;
      S.onCancel = typeof opts.onCancel === "function" ? opts.onCancel : null;
      S.restored = document.activeElement;
      build();
      // 入場
      requestAnimationFrame(function () {
        if (!S.root) return;
        S.root.classList.add("on");
      });
      renderIncense();
      var h = btn("mmrTake");
      if (h) later(function () { try { h.focus({ preventScroll: true }); } catch (e) { } }, 60);
      return true;
    },
    close: function () { if (S.open) cancel(); },
    isOpen: function () { return S.open; },
    _test: {
      setRandom: function (fn) { S.rng = fn; },
      forceJiao: function (v) { S.forcedJiao = v; },
      candidate: function () { return S.cand ? S.cand.n : null; },
      phase: function () { return S.phase; },
      debug: function () { return { raf: S.raf, timers: S.timers.length, listeners: S.lis.length, open: S.open, phase: S.phase }; }
    }
  };
})();
