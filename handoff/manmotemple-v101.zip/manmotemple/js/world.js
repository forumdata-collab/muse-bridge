/* 文武廟 · 神龕、法器、光明燈、祈福牌、香客 */
(function () {
  "use strict";
  var T = window.THREE, MM = window.MM, U = MM._;
  var scene, HX = 11, HZ = 13, HH = 9.6;
  var box, cyl, plane, mesh, mat, gold, rnd, textTexture;
  var LAMPS = [], WISHES = [], jiaoGroup, lotTube, lotSticks = [];
  var lampOn = [], lampMeshes = null;
  var photoMats = [];

  function init() {
    scene = U.scene; box = U.box; cyl = U.cyl; plane = U.plane; mesh = U.mesh;
    mat = U.mat; gold = U.gold; rnd = U.rnd; textTexture = U.textTexture;
    buildAltar();
    buildDeities();
    buildOfferings();
    buildLamps();
    buildWishRack();
    buildBellDrum();
    buildPhotos();
    buildHeavenCenser();
    buildStations();
    buildDetails();
    buildPalaceLanterns();
    buildSideEaves();
    buildCourtyardProps();
    buildNpcs();
  }

  /* ---------------- 神龕：真實相片 + 立體龕體 ---------------- */
  /* 供桌桌面高度：相片底邊同所有供品都以此為基準（舊版供品放低 0.34m，插入桌面） */
  var ATLAR_Y = 1.5;
  /* 相片以原始比例呈現，唔可以拉伸 */
  var SHRINE = { w: 6.8, aspect: 900 / 1462, z: -12.44, bottom: ATLAR_Y + .04 };
  SHRINE.h = SHRINE.w * SHRINE.aspect;
  SHRINE.top = SHRINE.bottom + SHRINE.h;

  function buildAltar() {
    var carvedM = new T.MeshStandardMaterial({ map: U.TEX.carved, roughness: .5, metalness: .22 });
    var redM = new T.MeshStandardMaterial({ map: U.TEX.lacquer, roughness: .42, metalness: .1 });
    var brocadeM = new T.MeshStandardMaterial({ map: U.TEX.brocadeRed, roughness: .9 });

    /* 供桌 */
    var g = new T.Group(); g.position.set(0, U.PZ, -9.3); scene.add(g);
    box(6.6, .14, 1.45, redM, 0, 1.02, 0, g);
    box(6.9, .12, 1.6, gold(), 0, 1.1, 0, g);
    box(6.3, .82, 1.2, mat("#3a0a06"), 0, .55, 0, g);
    plane(6.2, .8, carvedM, 0, .55, .615, g);
    for (var i = 0; i < 4; i++) box(.16, .98, .16, mat("#4a0d09"), -3 + i * 2, .49, .58, g);

    /* 神龕：雕花背板 + 2.6m 深側廊 + 龕頂。相片貼在龕腔最深處，
       前後共五層（背板 −12.62 ／ 相片 −12.44 ／ 金框 −12.37 ／ 前柱 −9.88 ／ 供桌 −8.57），
       玩家行前退後會見到視差，唔係一塊平面貼紙。 */
    box(8.6, 6.6, .24, carvedM, 0, 3.6, -12.62);
    [-1, 1].forEach(function (s) {
      box(.34, 6.6, 2.7, carvedM, s * 4.24, 3.6, -11.3);
      box(.08, 6.1, .18, gold(), s * 4.05, 3.62, -10.0);
    });
    box(8.9, .26, 2.95, mat("#5a0f08"), 0, 5.95, -11.3);
    box(9.15, .14, 3.1, gold(), 0, 5.8, -11.3);
    /* 前檐只留幼金線一條：低位橫披會擋住相片本身的「文武二帝」橫匾。 */
    box(8.8, .05, .06, gold(), 0, 5.78, -9.98);
    /* 神樓前柱：柱腳落地、柱頭承龕頂 */
    [-1, 1].forEach(function (s) {
      box(.4, 6.4, .4, carvedM, s * 4.3, 3.54, -9.88);
      box(.52, .14, .52, gold(), s * 4.3, 6.78, -9.88);
      box(.52, .14, .52, gold(), s * 4.3, .36, -9.88);
      box(.5, .5, .5, carvedM, s * 4.05, 6.42, -9.88);
    });
    /* 神座：相片底邊就落在神座頂面，供桌唔會遮住相片 */
    box(8.0, 1.2, 1.7, mat("#4c0d07"), 0, .94, -11.75);
    box(8.25, .1, 1.8, gold(), 0, 1.5, -11.75);
    plane(7.6, 1.0, carvedM, 0, .95, -10.89);
    /* 前階 */
    box(7.8, .18, 1.3, mat("#5a1209"), 0, .43, -10.5);
    box(8.0, .06, 1.35, gold(), 0, .53, -10.5);
    /* 帳幔：貼在神樓前柱內側，只遮龕口邊緣，不壓住相片主體 */
    [-1, 1].forEach(function (s) {
      var d = plane(1.15, 4.9, brocadeM, s * 3.98, 3.35, -9.9);
      d.rotation.y = -s * .13;
    });
  }

  function buildDeities() {
    /* 真實相片（用戶精修嘅上環文武廟正殿）：正面唔再擺卡通神像，只保留神像真容。
       相片放喺龕腔最深處，左右分別為關帝（相片左）與文昌帝君（相片右）。 */
    var m = new T.MeshBasicMaterial({ color: 0x1a0f0a });
    var pl = new T.Mesh(new T.PlaneGeometry(SHRINE.w, SHRINE.h), m);
    pl.position.set(0, SHRINE.bottom + SHRINE.h / 2, SHRINE.z);
    pl.userData.dynamic = true;            /* 排除 optimizeStatic 合併，保留貼圖同 UV */
    scene.add(pl);
    SHRINE.mesh = pl; U.shrinePhoto = pl; U.shrineBox = SHRINE;

    var loader = new T.TextureLoader();
    loader.load("assets/deities/altar-shrine.jpg", function (t) {
      t.encoding = T.sRGBEncoding;
      if (U.renderer && U.renderer.capabilities) t.anisotropy = Math.min(8, U.renderer.capabilities.getMaxAnisotropy());
      m.map = t; m.color.set(0xf2e7dc); m.needsUpdate = true;
      pl.userData.photoReady = true;
    }, undefined, function () { U.photoAltarError = true; });

    /* 相片四周金框，做出「神龕門框」層次 */
    var fr = gold();
    box(SHRINE.w + .46, .14, .12, fr, 0, SHRINE.bottom - .05, SHRINE.z + .07);
    box(SHRINE.w + .46, .14, .12, fr, 0, SHRINE.top + .05, SHRINE.z + .07);
    [-1, 1].forEach(function (s) {
      box(.14, SHRINE.h + .24, .12, fr, s * (SHRINE.w / 2 + .16), SHRINE.bottom + SHRINE.h / 2, SHRINE.z + .07);
    });

    /* 青龍偃月刀：立在神壇左側，同關帝同一邊（參拜者面向神壇的左方） */
    var h = new T.Group(); h.position.set(-4.95, 0, -10.4); scene.add(h);
    cyl(.045, .05, 3.6, mat("#6b3a1a", { roughness: .7 }), 0, 1.8, 0, h, 10);
    var blade = box(.12, 1.15, .42, mat("#9aa3a8", { metalness: .85, roughness: .3 }), 0, 3.5, 0, h);
    blade.rotation.z = .16;
    mesh(new T.TorusGeometry(.34, .05, 6, 16, Math.PI * 1.1), gold(), 0, 3.6, 0, h).rotation.y = Math.PI / 2;
    box(.5, .08, .5, gold(), 0, .04, 0, h);
  }

  /* ---------------- altar offerings ---------------- */
  function buildOfferings() {
    var bronze = mat("#6b5232", { metalness: .82, roughness: .38 });
    /* 主爐設於香案前中央落地香座，正面同時敬文武二帝。 */
    var g = new T.Group(); g.position.set(0, .83, -5.35); scene.add(g); U.censerGroup = g;
    var sm = U.makeSmoke(40, { base: new T.Vector3(0, 1.55, -5.35), size: .28, opacity: .18, rise: 1.4, spread: .22, speed: .3 });
    U.censerSmoke = sm;
    if (MM.Incense) MM.Incense.register({ id: "main", name: "正殿主爐", group: g, ashY: .62, approach: { x: 0, z: -1.6 }, smoke: sm });
    /* 獨立香座：石基貼地，短石柱托住三足；金圈收邊。 */
    cyl(.52, .52, .12, mat("#51483b", { roughness: .82 }), 0, -.77, 0, g, 18);
    cyl(.34, .34, .56, mat("#51483b", { roughness: .82 }), 0, -.45, 0, g, 18);
    cyl(.40, .40, .04, gold(), 0, -.65, 0, g, 18);
    cyl(.3, .42, .62, bronze, 0, .31, 0, g, 20);
    mesh(new T.TorusGeometry(.4, .035, 8, 24), bronze, 0, .58, 0, g).rotation.x = Math.PI / 2;
    [-1, 1].forEach(function (s) { var hd = mesh(new T.TorusGeometry(.12, .022, 6, 12), bronze, s * .42, .45, 0, g); hd.rotation.y = Math.PI / 2; });
    for (var i = 0; i < 3; i++) cyl(.05, .07, .28, bronze, Math.cos(i * 2.1) * .26, -.1, Math.sin(i * 2.1) * .26, g, 8);
    /* ash + incense sticks — v95：香灰堆成小丘 + 香枝粗細、火頭明暗不一 */
    cyl(.34, .34, .03, mat("#5a5348", { roughness: 1 }), 0, .62, 0, g, 18);
    mesh(new T.SphereGeometry(.22, 16, 10), mat("#6a6258", { roughness: 1 }), 0, .63, 0, g).scale.set(1, .22, 1);
    for (i = 0; i < 8; i++) {
      var s = cyl(.011, .013, .46, mat("#8b5a2b"), rnd(-.22, .22), .86, rnd(-.22, .22), g, 5);
      s.rotation.set(rnd(-.08, .08), 0, rnd(-.08, .08));
      var tip = mesh(new T.SphereGeometry(.017, 6, 5), new T.MeshBasicMaterial({ color: i % 2 ? 0xff8a3d : 0xffb060 }), s.position.x, 1.09, s.position.z, g);
      /* 香枝中段綁紅線（其中兩枝） */
      if (i % 4 === 0) { var rb = mesh(new T.TorusGeometry(.014, .004, 6, 10), mat("#a8201a"), s.position.x, .92, s.position.z, g); rb.rotation.x = Math.PI / 2; }
    }
    /* candles — v95：黃銅燭台（車床剖面 + 滴蠟盤）+ 蠟燭滴蠟 + 燭芯 + 雙層火焰 */
    U.candleFlames = [];
    [-2.55, 2.55].forEach(function (x) {
      var cg = new T.Group(); cg.position.set(x, ATLAR_Y, -9.15); scene.add(cg);
      /* 燭台：底座 → 細頸 → 滴蠟盤 */
      cyl(.13, .15, .03, gold(), 0, .015, 0, cg, 16);
      cyl(.04, .06, .08, gold(), 0, .07, 0, cg, 12);
      cyl(.11, .09, .02, gold(), 0, .12, 0, cg, 16);
      var candleMat = new T.MeshStandardMaterial({ color: new T.Color("#b8231a"), roughness: .42,
        emissive: new T.Color("#5a0c04"), emissiveIntensity: .5, envMap: U.ENV || null, envMapIntensity: .3 });
      var candle = cyl(.055, .06, .42, candleMat, 0, .34, 0, cg, 14);
      candle.castShadow = true;
      /* 頂部蠟面微凹 + 滴蠟：三滴沿燭身流下 */
      cyl(.052, .052, .012, mat("#d8a0a0", { roughness: .6 }), 0, .55, 0, cg, 14);
      [[.05, .42, .06], [-.055, .38, .09], [.02, .30, .12]].forEach(function (d) {
        var drip = mesh(new T.SphereGeometry(.014, 8, 6), mat("#d8a0a0", { roughness: .6 }), d[0], d[1], d[2], cg);
        drip.scale.set(1, 1.8, .6);
      });
      cyl(.006, .006, .03, mat("#1a0f08", { roughness: 1 }), 0, .57, 0, cg, 6);
      var fl = new T.Sprite(new T.SpriteMaterial({ map: U.TEX.flame, color: 0xffcf8a, transparent: true, blending: T.AdditiveBlending, depthWrite: false }));
      fl.scale.set(.1, .17, 1); fl.position.set(0, .63, 0); cg.add(fl);
      var flCore = new T.Sprite(new T.SpriteMaterial({ map: U.TEX.glow, color: 0xfff2c0, transparent: true, opacity: .9, blending: T.AdditiveBlending, depthWrite: false }));
      flCore.scale.set(.05, .08, 1); flCore.position.set(0, .61, 0); cg.add(flCore);
      U.candleFlames.push({ s: fl, core: flCore, base: .17, ph: Math.random() * 6.28 });
      /* 燭台底加紅布墊 */
      cyl(.14, .14, .008, mat("#7a1208", { roughness: .9 }), 0, .004, 0, cg, 16);
    });
    /* 燭光閃爍：scene.js 每格 call U.onFrameOfferings */
    U.onFrameOfferings = function (dt, t) {
      if (U.candleFlames) for (var ci = 0; ci < U.candleFlames.length; ci++) {
        var cf = U.candleFlames[ci];
        var k = 1 + Math.sin(t * 9 + cf.ph) * .07 + Math.sin(t * 23 + cf.ph * 2) * .04;
        cf.s.scale.set(.1 * k, cf.base * k, 1);
        cf.core.material.opacity = .75 + Math.sin(t * 11 + cf.ph) * .15;
        /* v97：火苗微傾 — 好似有氣流掠過，火苗輕輕左右挨 */
        cf.s.position.x = Math.sin(t * 3 + cf.ph) * .005;
      }
      /* v97：菊花花頭輕擺 — 花頭成組搖，莖唔郁 */
      if (U.flowerHeads) for (var fi = 0; fi < U.flowerHeads.length; fi++) {
        var fh = U.flowerHeads[fi];
        fh.rotation.z = fh.userData.baseRotZ + Math.sin(t * 1.3 + fh.userData.ph) * .03;
        fh.rotation.x = fh.userData.baseRotX + Math.cos(t * 1.1 + fh.userData.ph) * .02;
      }
    };
    /* v95：供桌紅布 + 青花瓷盤 + 分得清嘅果品 + 菊花 + 茶 + 發糕 + 元寶 */
    /* 紅布：錦緞枱布墊喺全部供品之下 */
    box(5.9, .012, 1.05, new T.MeshStandardMaterial({ map: U.TEX.brocadeRed, roughness: .9 }), 0, ATLAR_Y + .002, -9.5, scene);
    var porcelainM = new T.MeshStandardMaterial({ map: U.TEX.porcelain, roughness: .32, metalness: 0, envMap: U.ENV || null, envMapIntensity: .5 });
    var leafM = new T.MeshStandardMaterial({ color: new T.Color("#2f5a2a"), roughness: .7, side: T.DoubleSide, envMap: U.ENV || null, envMapIntensity: .2 });
    var stemM = mat("#5a3a1a", { roughness: .8 });
    function addLeaf(parent, x, y, z, ry) {
      var lf = mesh(new T.SphereGeometry(.055, 10, 8), leafM, x, y, z, parent);
      lf.scale.set(1.5, .18, .8); lf.rotation.y = ry || 0; lf.rotation.z = .3; lf.castShadow = true; return lf;
    }
    function makeFruit(kind, parent, x, y, z) {
      var g = new T.Group(); g.position.set(x, y, z); parent.add(g);
      var body;
      if (kind === "orange") {
        body = mesh(new T.SphereGeometry(.1, 20, 16),
          new T.MeshStandardMaterial({ map: U.TEX.orange, bumpMap: U.TEX.orange, bumpScale: .006, roughness: .5, envMap: U.ENV || null, envMapIntensity: .4 }), 0, 0, 0, g);
        mesh(new T.SphereGeometry(.016, 8, 6), mat("#7a4a12", { roughness: .8 }), 0, .095, 0, g);
        cyl(.008, .011, .04, stemM, .01, .11, 0, g, 6).rotation.z = .3;
        addLeaf(g, .07, .1, 0, .8);
      } else if (kind === "apple") {
        body = mesh(new T.SphereGeometry(.095, 20, 16),
          new T.MeshStandardMaterial({ color: new T.Color("#c03028"), roughness: .24, metalness: 0, envMap: U.ENV || null, envMapIntensity: .7 }), 0, 0, 0, g);
        body.scale.set(1, .88, 1);
        mesh(new T.SphereGeometry(.018, 8, 6), mat("#5a1a10", { roughness: .8 }), 0, .08, 0, g).scale.set(1, .5, 1);
        cyl(.007, .01, .045, stemM, 0, .1, 0, g, 6).rotation.z = -.2;
        addLeaf(g, -.06, .1, .02, -.7);
      } else { /* peach：粉紅 + 一道凹痕 + 尖頂 */
        body = mesh(new T.SphereGeometry(.1, 20, 16),
          new T.MeshStandardMaterial({ color: new T.Color("#e88a7a"), roughness: .48, envMap: U.ENV || null, envMapIntensity: .45 }), 0, 0, 0, g);
        body.scale.set(1, .95, 1);
        var cleft = mesh(new T.TorusGeometry(.085, .004, 6, 20, Math.PI * .9), mat("#b85a4a", { roughness: .7 }), 0, 0, .02, g);
        cleft.rotation.set(.3, 0, 1.1);
        mesh(new T.SphereGeometry(.012, 8, 6), mat("#7a4a3a", { roughness: .8 }), 0, .09, 0, g);
      }
      body.castShadow = true;
      g.rotation.y = rnd(0, 6.28);
      return g;
    }
    /* 左盤：橙 ×3 + 蘋果 ×2 + 桃 ×1（金字塔）；右盤：蘋果 ×3 + 桃 ×2 + 橙 ×1 */
    var fruitSets = [["orange", "orange", "apple", "peach", "orange", "apple"], ["apple", "peach", "apple", "orange", "apple", "peach"]];
    [-1.55, 1.55].forEach(function (x, k) {
      var p = new T.Group(); p.position.set(x, ATLAR_Y, -9.55); scene.add(p);
      cyl(.3, .22, .07, porcelainM, 0, .035, 0, p, 24);
      cyl(.16, .18, .04, porcelainM, 0, .01, 0, p, 18);
      /* 盤底青葉墊 */
      addLeaf(p, -.08, .075, .05, .4); addLeaf(p, .09, .075, -.04, 2.2);
      var kinds = fruitSets[k];
      for (var f = 0; f < 5; f++) {
        var a = f / 5 * 6.28;
        makeFruit(kinds[f], p, Math.cos(a) * .15, .17, Math.sin(a) * .15);
      }
      makeFruit(kinds[5], p, 0, .29, 0);
    });
    /* 花：菊花 — 花心 + 兩層花瓣 + 莖 + 葉；花瓶改用青花瓷車床瓶 */
    function makeFlower(parent, x, y, z, petalCol) {
      var g = new T.Group(); g.position.set(x, y, z); parent.add(g);
      var petalM = new T.MeshStandardMaterial({ color: new T.Color(petalCol), roughness: .75, side: T.DoubleSide });
      var centre = mesh(new T.SphereGeometry(.032, 10, 8), mat("#e8b820", { roughness: .6 }), 0, 0, 0, g);
      centre.scale.set(1, .6, 1);
      for (var layer = 0; layer < 2; layer++) {
        var nP = 7, rr = layer ? .055 : .075;
        for (var pi = 0; pi < nP; pi++) {
          var pa = pi / nP * 6.28 + layer * .45;
          var petal = mesh(new T.SphereGeometry(.038, 8, 6), petalM, Math.cos(pa) * rr, -.005 - layer * .012, Math.sin(pa) * rr, g);
          petal.scale.set(1.15, .22, .6); petal.rotation.y = -pa; petal.rotation.z = layer ? .25 : .12;
          petal.castShadow = true;
        }
      }
      return g;
    }
    [-3.3, 3.3].forEach(function (x, vi) {
      var v = new T.Group(); v.position.set(x, ATLAR_Y, -9.55); scene.add(v);
      /* 青花瓷瓶：車床剖面（闊腹、收頸、撇口） */
      var prof = [[.02, 0], [.11, .01], [.14, .06], [.145, .18], [.11, .32], [.07, .38], [.075, .42], [.095, .44]];
      var vase = mesh(new T.LatheGeometry(prof.map(function (q) { return new T.Vector2(q[0], q[1]); }), 20), porcelainM, 0, 0, 0, v);
      vase.castShadow = true;
      cyl(.07, .07, .01, mat("#7a9a8a", { roughness: .3 }), 0, .43, 0, v, 14);
      var cols = vi ? ["#e8a0b0", "#f0e2d0", "#e8a0b0"] : ["#f0e2d0", "#e8a0b0", "#f0e2d0"];
      for (var f = 0; f < 3; f++) {
        var fa = f / 3 * 6.28 + vi;
        var stem = cyl(.008, .01, .22, leafM, Math.cos(fa) * .05, .53, Math.sin(fa) * .05, v, 6);
        stem.rotation.set(Math.sin(fa) * .25, 0, Math.cos(fa) * .25);
        var fl = makeFlower(v, Math.cos(fa) * .09, .66 + (f % 2) * .05, Math.sin(fa) * .09, cols[f]);
        fl.rotation.x = Math.sin(fa) * .3; fl.rotation.z = -Math.cos(fa) * .3;
        /* v97：花頭輕擺 — 花頭 group 帶 userData.ph，合併件掛返花頭 group 上，
           成個花頭一齊輕擺，莖唔郁。baseRot 記低，擺幅喺 base 上加減。 */
        fl.userData.ph = Math.random() * 6.28;
        fl.userData.baseRotX = fl.rotation.x; fl.userData.baseRotZ = fl.rotation.z;
        (U.flowerHeads = U.flowerHeads || []).push(fl);
        addLeaf(v, Math.cos(fa + 1) * .07, .5, Math.sin(fa + 1) * .07, fa);
      }
    });
    /* 三杯清茶：青花小杯 + 茶湯面 + 托盤（供桌中央，籤筒與筊杯之間） */
    (function () {
      var tr = new T.Group(); tr.position.set(0, ATLAR_Y, -9.78); scene.add(tr);
      box(.85, .018, .28, mat("#7a1208", { roughness: .5 }), 0, .009, 0, tr);
      [-.28, 0, .28].forEach(function (tx) {
        cyl(.075, .06, .012, porcelainM, tx, .025, 0, tr, 16);
        cyl(.05, .038, .055, porcelainM, tx, .055, 0, tr, 16);
        cyl(.044, .044, .006, new T.MeshStandardMaterial({ color: new T.Color("#6a3a10"), roughness: .08, metalness: .1, envMap: U.ENV || null, envMapIntensity: .8 }), tx, .082, 0, tr, 16);
      });
    })();
    /* 發糕 ×3（右）+ 元寶 ×2（左）：供品唔再得生果花燭 */
    (function () {
      var cp = new T.Group(); cp.position.set(2.5, ATLAR_Y, -9.55); scene.add(cp);
      cyl(.22, .17, .06, porcelainM, 0, .03, 0, cp, 20);
      [[-.07, 0], [.07, .02], [0, -.07]].forEach(function (q, ci) {
        cyl(.062, .055, .06, mat(ci % 2 ? "#e8c8c0" : "#f2e8d8", { roughness: .85 }), q[0], .09, q[1], cp, 14);
        mesh(new T.TorusGeometry(.03, .005, 6, 14, Math.PI), mat("#c89890", { roughness: .85 }), q[0], .12, q[1], cp).rotation.x = Math.PI / 2;
      });
      var ig = new T.Group(); ig.position.set(-2.5, ATLAR_Y, -9.55); scene.add(ig);
      cyl(.22, .17, .05, porcelainM, 0, .025, 0, ig, 20);
      [-.06, .07].forEach(function (ix, ii) {
        var ingot = mesh(new T.SphereGeometry(.07, 16, 12),
          new T.MeshStandardMaterial({ map: U.TEX.gold, color: new T.Color("#ffffff"), metalness: .88, roughness: .3, envMap: U.ENV || null, envMapIntensity: 1 }), ix, .08, ii ? .03 : -.03, ig);
        ingot.scale.set(1.25, .5, .9); ingot.rotation.y = ii ? -.4 : .4; ingot.castShadow = true;
        mesh(new T.SphereGeometry(.028, 10, 8), mat("#7a5a1a", { metalness: .7, roughness: .4 }), ix, .095, ii ? .03 : -.03, ig).scale.set(1, .3, .7);
      });
    })();
    /* 籤筒 on the altar right */
    lotTube = new T.Group(); lotTube.position.set(1.05, ATLAR_Y, -9.62); scene.add(lotTube);
    cyl(.17, .15, .52, new T.MeshStandardMaterial({ map: U.TEX.bamboo, roughness: .6, envMap: U.ENV || null, envMapIntensity: .3 }), 0, .26, 0, lotTube, 18);
    cyl(.185, .17, .05, gold(), 0, .53, 0, lotTube, 16);
    cyl(.17, .15, .03, mat("#a8201a", { roughness: .6 }), 0, .03, 0, lotTube, 18);
    for (var n = 0; n < 26; n++) {
      var a = n / 26 * 6.28, rr = .1;
      var st = cyl(.008, .008, .62 + rnd(-.06, .06), mat("#c9a878"), Math.cos(a) * rr, .78, Math.sin(a) * rr, lotTube, 4);
      st.rotation.set(Math.cos(a) * .09, 0, Math.sin(a) * .09);
      if (n % 6 === 0) box(.035, .14, .012, mat("#a8201a"), Math.cos(a) * rr * 1.5, .96, Math.sin(a) * rr * 1.5, lotTube);
    }
    /* 筊杯 pair */
    jiaoGroup = new T.Group(); jiaoGroup.position.set(-1.0, ATLAR_Y + .01, -9.55); scene.add(jiaoGroup);
    for (var j = 0; j < 2; j++) {
      var b = makeJiaoBlock(); b.position.set(-.14 + j * .28, .04, 0); b.rotation.y = j * .6; jiaoGroup.add(b);
    }
    /* 香油箱：原本銅鐘的位置（入口左側） */
    var db = new T.Group(); db.position.set(-8.6, 0, 10.6); db.rotation.y = Math.PI; scene.add(db);
    box(1.0, .95, .7, mat("#8e1c14", { roughness: .45 }), 0, .48, 0, db);
    box(1.06, .08, .76, gold(), 0, .98, 0, db);
    box(.42, .03, .07, mat("#120806"), 0, 1.03, 0, db);
    var df = plane(.62, .62, new T.MeshStandardMaterial({ map: textTexture("香油", { size: 120, color: "#f0cd80", bg: "#5e0f08", pad: 20 }), roughness: .6 }), 0, .55, .36, db);
    U.donateBox = db;
  }

  function makeJiaoBlock() {
    var g = new T.Group();
    var m = new T.MeshStandardMaterial({ color: new T.Color("#b8341f"), roughness: .42, metalness: .06 });
    /* crescent: half-cylinder-ish */
    var sh = new T.Shape();
    sh.moveTo(-.16, 0); sh.quadraticCurveTo(0, .3, .16, 0); sh.quadraticCurveTo(0, .08, -.16, 0);
    var geo = new T.ExtrudeGeometry(sh, { depth: .34, bevelEnabled: true, bevelSize: .02, bevelThickness: .02, bevelSegments: 2 });
    geo.center();
    var b = new T.Mesh(geo, m); b.rotation.x = Math.PI / 2; g.add(b);
    var inner = new T.Mesh(geo, new T.MeshStandardMaterial({ color: new T.Color("#7e1d10"), roughness: .8 }));
    inner.scale.set(.92, .55, .94); inner.position.y = -.02; g.add(inner);
    return g;
  }

  /* ---------------- 光明燈 wall ---------------- */
  function buildLamps() {
    var cols = 12, rows = 5, cw = .38, ch = .5;
    var W = cols * cw + .4, H = rows * ch + .5;
    var g = new T.Group(); g.position.set(HX - .22, 1.0, -2.6); g.rotation.y = -Math.PI / 2; g.userData.dynamic = true; scene.add(g);
    box(W + .3, H + .3, .14, mat("#3a1a0e", { roughness: .7 }), 0, H / 2, -.06, g);
    box(W + .4, .12, .22, gold(), 0, H + .12, 0, g);
    box(W + .4, .12, .22, gold(), 0, -.02, 0, g);

    /* 60 盞燈 → 1 個 InstancedMesh（1 draw call），逐盞色用 instanceColor；
       光暈用一組 Points（1 draw call），只亮已點的燈。 */
    var N = cols * rows;
    var lampGeo = new T.PlaneGeometry(cw - .06, ch - .08);
    var lampMat = new T.MeshStandardMaterial({ color: 0xffffff, roughness: .55, emissive: new T.Color("#c9772a"), emissiveIntensity: .35 });
    var inst = new T.InstancedMesh(lampGeo, lampMat, N);
    inst.instanceMatrix.setUsage(T.StaticDrawUsage);
    var d = new T.Object3D();
    var gpos = new Float32Array(N * 3), gcol = new Float32Array(N * 3);
    for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) {
      var i = r * cols + c;
      var x = -W / 2 + .27 + c * cw, y = H - .3 - r * ch;
      d.position.set(x, y, .02); d.updateMatrix();
      inst.setMatrixAt(i, d.matrix);
      inst.setColorAt(i, new T.Color("#5a2a16"));
      gpos[i * 3] = x; gpos[i * 3 + 1] = y; gpos[i * 3 + 2] = .1;
      lampOn.push(false);
    }
    inst.instanceColor.needsUpdate = true;
    g.add(inst);

    /* 已點亮燈：獨立 overlay，只畫 lit 數量（1 draw call），emissive 高 → 真正發亮 */
    var litMat = new T.MeshStandardMaterial({ color: new T.Color("#ffe0b0"), roughness: .35, emissive: new T.Color("#ffb347"), emissiveIntensity: 1.5 });
    var litInst = new T.InstancedMesh(lampGeo, litMat, N);
    litInst.instanceMatrix.setUsage(T.DynamicDrawUsage);
    litInst.count = 0;
    litInst.frustumCulled = false;
    g.add(litInst);
    var litList = [];

    var glowGeo = new T.BufferGeometry();
    glowGeo.setAttribute("position", new T.BufferAttribute(gpos.slice(), 3));
    glowGeo.setAttribute("color", new T.BufferAttribute(gcol, 3));
    var glowMat = new T.PointsMaterial({ map: U.TEX.glow, size: .62, vertexColors: true, transparent: true,
      blending: T.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
    var glows = new T.Points(glowGeo, glowMat);
    glows.frustumCulled = false;
    g.add(glows);

    lampMeshes = { inst: inst, lit: litInst, litList: litList, dummy: d, glows: glows, geo: glowGeo, n: N, W: W, H: H, cw: cw, ch: ch };
    var title = new T.Mesh(new T.PlaneGeometry(1.4, 3.0), new T.MeshBasicMaterial({ map: textTexture("光明燈", { size: 110, vertical: true, color: "#f0cd80", bg: "#4a0d09", pad: 14 }), transparent: true }));
    title.position.set(HX - .12, 4.4, -5.4); title.rotation.y = -Math.PI / 2; scene.add(title);
    U.lampMeshes = lampMeshes;

    /* 登科及第 · 虛擬位（文昌祈求） */
    var seatMat = new T.MeshStandardMaterial({ color: "#2a1409", emissive: new T.Color("#000000"), roughness: .62, metalness: .08 });
    var seatMesh = new T.Mesh(new T.BoxGeometry(.07, 1.5, .95), seatMat);
    seatMesh.position.set(HX - .30, 2.3, -6.6); scene.add(seatMesh);
    var seatFace = new T.Mesh(new T.PlaneGeometry(.86, 1.32), new T.MeshBasicMaterial({
      map: textTexture("登科及第", { size: 92, vertical: true, color: "#e7ce8c", bg: "#2a1409", pad: 12 }), transparent: true
    }));
    seatFace.position.set(HX - .34, 2.3, -6.6); seatFace.rotation.y = -Math.PI / 2; scene.add(seatFace);
    var seatHalo = new T.Mesh(new T.PlaneGeometry(1.5, 1.9), new T.MeshBasicMaterial({
      map: U.TEX.glow, color: new T.Color("#ffb85e"), transparent: true, opacity: 0,
      blending: T.AdditiveBlending, depthWrite: false
    }));
    seatHalo.position.set(HX - .42, 2.3, -6.6); seatHalo.rotation.y = -Math.PI / 2; scene.add(seatHalo);
    var seatLight = new T.PointLight(0xffc070, 0, 4.4); seatLight.position.set(HX - .95, 2.3, -6.6); scene.add(seatLight);
    U.seat = { mat: seatMat, halo: seatHalo, light: seatLight, on: false };
  }
  MM.setSeat = function (on, animate) {
    var S = U.seat; if (!S) return;
    S.on = !!on;
    S.mat.emissive.set(on ? "#ff9d3c" : "#000000");
    S.mat.emissiveIntensity = on ? 1.1 : 0;
    S.light.intensity = on ? 1.3 : 0;
    S.halo.material.opacity = on ? .55 : 0;
    if (on && animate) {
      var t0 = performance.now(), dur = 1200;
      var tick = function () {
        var k = Math.min(1, (performance.now() - t0) / dur);
        S.halo.material.opacity = .55 * k;
        S.light.intensity = 1.3 * k;
        if (k < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }
  };
  MM.seatState = function () { return !!(U.seat && U.seat.on); };
  MM.lampState = function () { return lampOn.slice(); };
  MM.setLamp = function (i, on, animate) {
    if (i < 0 || i >= lampOn.length || !lampMeshes || !lampMeshes.inst) return;
    lampOn[i] = !!on;
    lampMeshes.inst.setColorAt(i, new T.Color(on ? "#ffdca6" : "#5a2a16"));
    lampMeshes.inst.instanceColor.needsUpdate = true;
    /* 重建 lit overlay */
    var LL = lampMeshes.litList;
    if (on) { if (LL.indexOf(i) < 0) LL.push(i); } else { LL = LL.filter(function (k) { return k !== i; }); lampMeshes.litList = LL; }
    var dm = lampMeshes.dummy;
    for (var q = 0; q < LL.length; q++) {
      var k2 = LL[q], rr = Math.floor(k2 / 12), cc = k2 % 12;
      dm.position.set(-lampMeshes.W / 2 + .27 + cc * lampMeshes.cw, lampMeshes.H - .3 - rr * lampMeshes.ch, .025); dm.updateMatrix();
      lampMeshes.lit.setMatrixAt(q, dm.matrix);
    }
    lampMeshes.lit.count = LL.length;
    lampMeshes.lit.instanceMatrix.needsUpdate = true;
    var col = lampMeshes.geo.attributes.color;
    var c = new T.Color(on ? "#ffb85e" : "#000000");
    col.setXYZ(i, c.r, c.g, c.b); col.needsUpdate = true;
    if (on && animate) {
      var s0 = .1, t0 = performance.now();
      var iv = setInterval(function () {
        var k = Math.min(1, (performance.now() - t0) / 700);
        lampMeshes.glows.material.size = .62 * (.35 + .65 * k);
        if (k >= 1) { lampMeshes.glows.material.size = .62; clearInterval(iv); }
      }, 33);
    }
  };

  /* ---------------- 祈福牌 rack ---------------- */
  function buildWishRack() {
    var g = new T.Group(); g.position.set(-HX + .5, 0, 2.2); g.rotation.y = Math.PI / 2; scene.add(g);
    [-1.9, 1.9].forEach(function (x) { box(.14, 2.5, .14, mat("#5a2416"), x, 1.25, 0, g); });
    box(4.2, .12, .12, mat("#5a2416"), 0, 2.45, 0, g);
    box(4.0, .08, .08, mat("#5a2416"), 0, 1.55, 0, g);
    g.userData.dynamic = true;
    U.wishRack = g;
    for (var i = 0; i < 14; i++) addWishTag(g, ["闔家平安", "學業進步", "身體健康", "生意興隆", "出入平安"][i % 5], false);
  }
  function addWishTag(parent, text, pop) {
    var x = rnd(-1.8, 1.8), y = rnd(1.6, 2.35), z = rnd(-.06, .06);
    var m = new T.MeshStandardMaterial({ map: textTexture(text.length > 4 ? text.slice(0, 4) : text, { size: 52, vertical: true, color: "#2a0a04", bg: "rgba(196,44,26,.96)", pad: 6 }), roughness: .9, side: T.DoubleSide });
    var tag = new T.Mesh(new T.PlaneGeometry(.17, .34), m);
    tag.position.set(x, y, z);
    tag.rotation.z = rnd(-.12, .12);
    parent.add(tag);
    tag.userData.ph = Math.random() * 6.28;
    WISHES.push(tag);
    if (pop) {
      tag.scale.set(.01, .01, 1);
      var t0 = performance.now();
      var iv = setInterval(function () {
        var k = Math.min(1, (performance.now() - t0) / 600);
        tag.scale.set(k, k, 1);
        if (k >= 1) clearInterval(iv);
      }, 30);
    }
    return tag;
  }
  MM.addWish = function (text, silent) { if (U.wishRack) addWishTag(U.wishRack, text, !silent); };

  /* ---------------- 鐘 / 鼓 ---------------- */
  var bell, drum, bellSwing = 0, drumHit = 0;
  function buildBellDrum() {
    /* 銅鐘與鼓並列於金鹿右方（面向神壇的右手邊）側邊，靠右牆一字排開 */
    var g = new T.Group(); g.position.set(9.2, 0, 2.4); g.rotation.y = -Math.PI / 2; scene.add(g);
    [-1, 1].forEach(function (s) { box(.16, 3.0, .16, mat("#4a2010"), s * .7, 1.5, 0, g); });
    box(1.7, .18, .18, mat("#4a2010"), 0, 3.0, 0, g);
    var bronze = mat("#7a5a2a", { metalness: .88, roughness: .32 });
    bell = new T.Group(); bell.position.set(0, 2.35, 0); g.add(bell);
    /* 鐘身：車床剖面（口沿外撇、肩收窄），比圓錐多層次 */
    var prof = [[.50, -.45], [.49, -.40], [.455, -.30], [.415, -.18], [.355, -.05],
                [.318, .08], [.30, .20], [.275, .30], [.235, .38], [.155, .44], [.095, .465]];
    mesh(new T.LatheGeometry(prof.map(function (q) { return new T.Vector2(q[0], q[1]); }), 36), bronze, 0, 0, 0, bell);
    /* 口沿厚唇 */
    mesh(new T.TorusGeometry(.495, .03, 8, 44), bronze, 0, -.44, 0, bell).rotation.x = Math.PI / 2;
    /* 腰箍兩道 + 肩箍 */
    [[-.28, .457], [.06, .345], [.31, .268]].forEach(function (b) {
      mesh(new T.TorusGeometry(b[1], .017, 8, 44), bronze, 0, b[0], 0, bell).rotation.x = Math.PI / 2;
    });
    /* 四條縱脊 */
    for (var bi = 0; bi < 4; bi++) {
      var ba = bi / 4 * Math.PI * 2 + Math.PI / 4;
      var rib = box(.05, .5, .014, bronze, Math.sin(ba) * .43, -.06, Math.cos(ba) * .43, bell);
      rib.rotation.y = ba; rib.rotation.x = -.06;
    }
    /* 鐘鈕：蒲牢雙耳 + 頂環 + 懸桿 */
    mesh(new T.TorusGeometry(.075, .022, 8, 20), bronze, 0, .53, 0, bell);
    [-1, 1].forEach(function (s) {
      mesh(new T.SphereGeometry(.045, 10, 8), bronze, s * .062, .49, 0, bell).scale.set(.8, 1.25, .8);
    });
    cyl(.018, .018, .26, bronze, 0, .66, 0, bell, 8);
    /* 鐘舌 */
    cyl(.012, .012, .46, bronze, 0, -.14, 0, bell, 6);
    mesh(new T.SphereGeometry(.055, 12, 10), bronze, 0, -.38, 0, bell);
    U.bell = bell;
    U.addStation("bell", "鳴鐘 · 1847 年銅鐘", 9.2, 2.4, Math.PI / 2, 2.4);
    /* 鼓：緊接銅鐘，同一側廳 */
    var d = new T.Group(); d.position.set(9.2, 0, 5.0); d.rotation.y = -Math.PI / 2; scene.add(d);
    [-1, 1].forEach(function (s) { box(.16, 2.4, .16, mat("#4a2010"), s * .9, 1.2, 0, d); });
    box(2.2, .18, .18, mat("#4a2010"), 0, 2.4, 0, d);
    drum = new T.Group(); drum.position.set(0, 1.5, 0); d.add(drum);
    var drumMat = mat("#8b2a16", { roughness: .6 });
    var dm = cyl(.62, .62, .7, drumMat, 0, 0, 0, drum, 22); dm.rotation.z = Math.PI / 2;
    var skin = mat("#e0cfae", { roughness: .85 });
    [1, -1].forEach(function (s) {
      var c = cyl(.63, .63, .05, skin, s * .36, 0, 0, drum, 22); c.rotation.z = Math.PI / 2;
    });
    for (var i = 0; i < 10; i++) {
      var a = i / 10 * 6.28;
      mesh(new T.SphereGeometry(.035, 6, 5), gold(), .38, Math.cos(a) * .6, Math.sin(a) * .6, drum);
      mesh(new T.SphereGeometry(.035, 6, 5), gold(), -.38, Math.cos(a) * .6, Math.sin(a) * .6, drum);
    }
    U.drum = drum;
    U.addStation("drum", "擊鼓 · 暮鼓晨鐘", 9.2, 5.0, Math.PI / 2, 2.4);
  }
  MM.ringBell = function () { bellSwing = 1.6; };
  MM.hitDrum = function () { drumHit = 1; };
  MM.onBellFrame = null;

  /* ---------------- photo panels ---------------- */
  function buildPhotos() {
    /* v100：左牆相片欄改為「文武廟一覽」—— 原先三格無標題，訪客唔知呢欄係做咩；
       第一格圖文不符：exterior1.jpg 影嘅係正門鐵閘告示牌，唔係花崗石門框同石鼓
       （連 app 自己的實景對照都寫明係「廟門告示」），改用 roof.jpg 綠瓦重簷。
       成欄升高 0.55，第三格相框同字幕唔再沉入地下；字幕闊度跟返文字比例，唔再拉闊。 */
    var pics = [
      ["assets/roof.jpg", "廟宇外貌 · 綠瓦重簷"],
      ["assets/coils1.jpg", "殿內塔香 · 由上而下盤旋焚燒"],
      ["assets/deities/deities-zoom.jpg", "正殿神龕 · 左關帝 · 右文昌"]
    ];
    /* 欄目標題 + 金線 */
    var titleTex = textTexture("文武廟一覽", { size: 64, color: "#e8c268" });
    var titleAsp = (titleTex.image.width && titleTex.image.height) ? titleTex.image.width / titleTex.image.height : 3.3;
    var title = new T.Mesh(new T.PlaneGeometry(0.5 * titleAsp, 0.5),
      new T.MeshBasicMaterial({ map: titleTex, transparent: true }));
    title.position.set(-HX + .3, 5.35, 7.4); title.rotation.y = Math.PI / 2; scene.add(title);
    box(.02, .035, 1.9, gold(), -HX + .22, 5.08, 7.4);
    var loader = new T.TextureLoader();
    pics.forEach(function (p, i) {
      var y = 4.15 - i * 1.55;
      var frame = box(.1, 1.22, 1.72, gold(), -HX + .22, y, 7.4);
      var m = new T.MeshBasicMaterial({ color: 0x2a1a12 });
      var pl = new T.Mesh(new T.PlaneGeometry(1.56, 1.06), m);
      pl.position.set(-HX + .29, y, 7.4); pl.rotation.y = Math.PI / 2; scene.add(pl);
      loader.load(p[0], function (t) {
        t.encoding = T.sRGBEncoding; m.map = t; m.color.set(0xffffff); m.needsUpdate = true;
      }, undefined, function () { });
      var capTex = textTexture(p[1], { size: 40, color: "#d8c4a0" });
      var capAsp = (capTex.image.width && capTex.image.height) ? capTex.image.width / capTex.image.height : 7.5;
      var cap = new T.Mesh(new T.PlaneGeometry(0.2 * capAsp, 0.2),
        new T.MeshBasicMaterial({ map: capTex, transparent: true }));
      cap.position.set(-HX + .3, y - .66, 7.4); cap.rotation.y = Math.PI / 2; scene.add(cap);
    });
  }

  /* ---------------- 天公爐（廟前） ---------------- */
  function buildHeavenCenser() {
    var g = new T.Group(); g.position.set(0, 0, 14.6); scene.add(g);
    var stone = mat("#6e675c", { roughness: .95 });
    cyl(.62, .78, .34, stone, 0, .17, 0, g, 16);
    var bronze = mat("#6b5232", { metalness: .82, roughness: .38 });
    cyl(.46, .58, .62, bronze, 0, .62, 0, g, 20);
    mesh(new T.TorusGeometry(.55, .04, 8, 24), bronze, 0, .93, 0, g).rotation.x = Math.PI / 2;
    [-1, 1].forEach(function (s) { var hd = mesh(new T.TorusGeometry(.11, .02, 6, 12), bronze, s * .5, .8, 0, g); hd.rotation.y = Math.PI / 2; });
    [-1, 1].forEach(function (s) { cyl(.06, .07, .5, bronze, s * .3, .38, .3, g, 8); });
    cyl(.42, .42, .03, mat("#5a5348", { roughness: 1 }), 0, .93, 0, g, 18);
    for (var i = 0; i < 5; i++) {
      var st = cyl(.011, .011, .44, mat("#8b5a2b"), rnd(-.28, .28), 1.15, rnd(-.28, .28), g, 5);
      st.rotation.set(rnd(-.06, .06), 0, rnd(-.06, .06));
    }
    var smH = U.makeSmoke(20, { base: new T.Vector3(0, 1.5, 14.6), size: .3, opacity: .15, rise: 1.6, spread: .3, speed: .3 });
    if (MM.Incense) MM.Incense.register({ id: "heaven", name: "天公爐", group: g, ashY: .93, approach: { x: 0, z: 15.6 }, smoke: smH });
  }

  /* ---------------- stations ---------------- */
  function buildStations() {
    U.addStation("incense", "上香 · 請香三炷", 0, -6.4, Math.PI, 3.0);
    U.addStation("altar", "正殿 · 向文武二帝參拜", 0, -3.5, Math.PI, 3.2);
    U.addStation("lot", "籤筒 · 求籤問事", 1.05, -7.6, Math.PI, 2.4);
    U.addStation("jiao", "筊杯 · 擲筊請示", -1.0, -7.6, Math.PI, 2.2);
    U.addStation("donate", "香油箱 · 添香油", -8.6, 10.6, 0, 2.0);
    U.addStation("plaque", "仰望匾額 · 帝德同沾", 0, 8.0, 0, 2.4);
    U.addStation("lamps", "光明燈 · 點一盞燈", 9.5, -2.8, Math.PI / 2, 2.4);
    U.addStation("wishes", "祈福牌 · 寫下心願", -8.4, 2.2, -Math.PI / 2, 2.2);
    U.addStation("courtyard", "天公爐 · 廟前", 0, 14.6, Math.PI, 2.6);
  }

  /* ---------------- NPC worshippers ---------------- */
  /* 跪姿善信：局部前方 = -Z（神壇方向），所以 spots 的 yaw 0 已經面向神壇，毋須再轉 π。
     root 靜止；只有 hip / spine / neck / head 分節輕躬（不做額頭貼地的五體投地）。
     整個 subtree 必須標記 dynamic，否則 optimizeStatic 會把可動肢體併入靜態合併。 */
  var KNEE = {
    cycle: 9.0, stagger: 4.5,
    hipY: .34, hipZ: .195,
    kneeX: .145, kneeY: .191, kneeZ: -.133,
    ankleX: .135, ankleY: .175, ankleZ: .167,
    footY: .148, footZ: .213
  };
  var npcGeos = {}, skinMat = null, hairMat = null;

  function npcGeo(k, make) {
    return npcGeos[k] || (npcGeos[k] = make());
  }
  function npcSegGeo(r0, r1, len) {
    return npcGeo("c" + r0 + "/" + r1 + "/" + len.toFixed(3), function () {
      return new T.CylinderGeometry(r1, r0, len, 8);
    });
  }
  /* 由 a 點到 b 點的肢段：圓柱沿兩點之間，幾何按尺寸共用 */
  function npcSeg(parent, ax, ay, az, bx, by, bz, r0, r1, m) {
    var dx = bx - ax, dy = by - ay, dz = bz - az;
    var len = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var o = mesh(npcSegGeo(r0, r1, len), m, (ax + bx) / 2, (ay + by) / 2, (az + bz) / 2, parent);
    o.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), new T.Vector3(dx, dy, dz).normalize());
    return o;
  }
  function npcSphere(parent, r, m, x, y, z) {
    return mesh(npcGeo("s" + r, function () { return new T.SphereGeometry(r, 14, 10); }), m, x, y, z, parent);
  }
  function npcBox(parent, w, h, d, m, x, y, z) {
    return mesh(npcGeo("b" + w + "/" + h + "/" + d, function () { return new T.BoxGeometry(w, h, d); }), m, x, y, z, parent);
  }

  function buildNpcs() {
    var spots = [[-2.2, -2.5, 0, true], [2.2, -2.5, 0, true], [4.6, 6.0, -1.3, false]];
    U.npcs = U.npcs || []; U.kneelers = U.kneelers || [];
    spots.forEach(function (p, i) {
      var g = p[3] ? makeNpc(i, true) : buildGuideNpc();
      g.position.set(p[0], 0, p[1]); g.rotation.y = p[2];
      scene.add(g);
      U.npcs.push(g);
      if (p[3]) {
        g.userData.kneelIndex = U.kneelers.length;
        U.kneelers.push(g);
      } else {
        /* 站立者已改為廟祝（虛擬導賞員）：保留 U.npcs 身份與站位供回歸測試 */
        g.userData.npcIndex = i;
        guide.g = g; guide.rig = g.userData.rig; guide.restYaw = p[2];
        MM.guideNPC.node = g;
      }
    });
    U.kneelers.forEach(function (g, n) { MM.poseKneelingVisitor(n, 0); });
    gmSetup();
  }
  function makeNpc(i, kneel) {
    var g = new T.Group();
    var col = ["#262429", "#2e2622", "#232a2a", "#2a2620"][i % 4];
    var robeMat = new T.MeshStandardMaterial({ color: new T.Color(col), roughness: .98 });
    var trimMat = new T.MeshStandardMaterial({ color: new T.Color(i ? "#c9a24e" : "#e8d8b0"), metalness: .6, roughness: .4 });
    var beadMat = mat("#4a2410", { roughness: .7 });
    if (kneel) {
      /* 跪姿：大腿前下、小腿向後平放、腳背貼墊，臀部貼近腳跟；
         手掌合十於胸前（跟隨胸腔，軀幹前傾時自動移動）。 */
      if (!skinMat) skinMat = mat("#b98a66", { roughness: .9 });
      if (!hairMat) hairMat = mat("#141210", { roughness: .95 });
      var K = KNEE, rig = {};
      var legs = new T.Group(); legs.name = "legs"; g.add(legs);
      [-1, 1].forEach(function (s, n) {
        var hx = s * .115, kx = s * K.kneeX, ax = s * K.ankleX;
        npcSeg(legs, hx, K.hipY, K.hipZ, kx, K.kneeY, K.kneeZ, .085, .072, robeMat).name = n ? "thighR" : "thighL";
        npcSeg(legs, kx, K.kneeY, K.kneeZ, ax, K.ankleY, K.ankleZ, .068, .055, robeMat).name = n ? "shinR" : "shinL";
        npcBox(legs, .105, .055, .21, mat("#1a1512", { roughness: .85 }), ax, K.footY, K.footZ).name = n ? "footR" : "footL";  /* v96：布鞋改深色，唔再同袍同色 */
      });
      var hip = new T.Group(); hip.name = "hip"; hip.position.set(0, K.hipY, K.hipZ); g.add(hip);
      npcSphere(hip, .17, robeMat, 0, -.03, -.01).scale.set(1.08, .84, 1.02);
      hip.children[0].name = "pelvis";
      cyl(.27, .325, .16, robeMat, 0, .005, .01, hip, 12).name = "skirt";
      /* v96：腰帶 + 裙腳邊 — 跪姿善信唔再係一色布 */
      mesh(new T.TorusGeometry(.20, .018, 8, 20), trimMat, 0, .07, 0, hip).rotation.x = Math.PI / 2;
      mesh(new T.TorusGeometry(.315, .010, 6, 20), trimMat, 0, -.07, .01, hip).rotation.x = Math.PI / 2;
      var spine = new T.Group(); spine.name = "spine"; hip.add(spine);
      cyl(.145, .178, .52, robeMat, 0, .26, 0, spine, 12).name = "torso";
      /* v96：對襟 + 三粒盤扣（前襟向神壇，即 -Z） */
      box(.055, .40, .015, trimMat, 0, .26, -.165, spine).name = "placket";
      [.12, .26, .40].forEach(function (by) {
        mesh(new T.SphereGeometry(.014, 8, 6), trimMat, 0, by, -.175, spine).name = "button";
      });
      var chest = new T.Group(); chest.name = "chest"; chest.position.set(0, .44, 0); spine.add(chest);
      [-1, 1].forEach(function (s, n) {
        npcSeg(chest, s * .155, 0, -.02, s * .17, -.14, -.09, .062, .05, robeMat).name = n ? "upperArmR" : "upperArmL";
        npcSeg(chest, s * .17, -.14, -.09, s * .028, -.085, -.165, .05, .042, robeMat).name = n ? "foreArmR" : "foreArmL";
        var h = npcSphere(chest, .046, skinMat, s * .028, -.085, -.165);
        h.scale.set(.92, 1.18, 1); h.name = n ? "handR" : "handL";
        /* v96：袖口邊 */
        mesh(new T.TorusGeometry(.048, .008, 6, 14), trimMat, s * .028, -.085, -.165, chest).rotation.set(1.2, 0, s * .4);
      });
      /* v96：合十手腕掛一串念珠（七粒，喺合十雙手前面） */
      for (var bd = 0; bd < 7; bd++) {
        var ba = bd / 7 * 6.28;
        npcSphere(chest, .013, beadMat, Math.cos(ba) * .07, -.085 + Math.sin(ba) * .05, -.20).name = "bead";
      }
      var neck = new T.Group(); neck.name = "neck"; neck.position.set(0, .52, 0); spine.add(neck);
      cyl(.052, .058, .1, skinMat, 0, .035, 0, neck, 8).name = "neckCol";
      var head = new T.Group(); head.name = "head"; head.position.set(0, .06, 0); neck.add(head);
      npcSphere(head, .135, skinMat, 0, .085, 0).name = "headBall";
      npcSphere(head, .142, hairMat, 0, .1, .026).scale.set(1, .8, 1);
      head.children[1].name = "hair";
      /* v96：髮髻 + 金簪 */
      npcSphere(head, .05, hairMat, 0, .20, -.02).name = "bun";
      mesh(new T.SphereGeometry(.012, 8, 6), trimMat, 0, .22, .06, head).name = "hairpin";
      rig.hip = hip; rig.spine = spine; rig.chest = chest; rig.neck = neck; rig.head = head; rig.k = 0;
      g.userData.rig = rig;
      g.userData.kneel = true;
      g.userData.cycle = K.cycle;
      g.userData.dynamic = true;   /* 全棵 subtree 排除 optimizer，避免四肢被合併走位 */
      return g;
    }
    cyl(.22, .4, 1.12, robeMat, 0, .56, 0, g, 10);
    cyl(.17, .22, .46, robeMat, 0, 1.35, 0, g, 10);
    mesh(new T.SphereGeometry(.145, 12, 10), mat("#b98a66", { roughness: .9 }), 0, 1.66, 0, g);
    mesh(new T.SphereGeometry(.155, 12, 8), mat("#141210"), 0, 1.7, -.02, g).scale.set(1, .8, 1);
    [-1, 1].forEach(function (s) { var arm = cyl(.06, .07, .46, robeMat, s * .23, 1.26, .05, g, 8); arm.rotation.z = s * .16; arm.rotation.x = -.25; });
    g.userData.ph = Math.random() * 6.28;
    return g;
  }

  /* ---------------- 廟祝：虛擬導賞員（固定腳本，無 AI 對話） ----------------
     畫面右下（x=4.6, z=6.0）的站立人物改為廟祝：平口唐裝短褂 + 深色長褲，
     不持法器、不穿道袍。點擊即開固定腳本對話，三個主題；對話不會移動鏡頭，
     只有使用者主動點「帶我看看」的地點時才用 MM.setCam 帶位。
     內容只寫可查證的廟史與本站互動，廟方規則一律標明「以現場告示為準」。 */
  var GM_ID = "gmPanel";
  var GUIDE_TOPICS = [
    {
      id: "history", title: "認識文武廟",
      lines: [
        "文武廟約建於一八四七至一八六二年間，位於上環荷李活道，由當時的華人紳商籌建；整個建築群由文武廟、列聖宮與公所三座組成，列聖宮與公所屬另一空間，本頁只重現文武廟正殿。",
        "殿內供奉兩位帝君：面向神壇，右邊是文昌帝君，主功名與文運；左邊是關聖帝君，重義守信，護佑商旅。",
        "一九〇八年《文武廟條例》通過，廟宇及財產交由東華醫院（今東華三院）管理；一九五八年修訂後，廟宇收入亦用於辦學、賑濟華人社會及發展東華醫療服務。",
        "入殿次序：中軸先見金鹿，再經立地大香爐，拾級而上才是文武二帝像。神壇兩側另有包公寶殿與城隍殿——面向神壇左為包公、右為城隍；兩殿在本頁暫未重現。",
        "開埠早年，文武廟與公所是華人議事、排解糾紛的地方，與上環的社區生活密不可分。",
        "二〇一〇年，文武廟建築群列為法定古蹟。"
      ],
      src: "資料：古物古蹟辦事處「文武廟建築群」法定古蹟介紹、東華三院文武廟官方介紹。"
    },
    {
      id: "rite", title: "怎樣參拜",
      lines: [
        "一般先到廟前天公爐敬天，再入正殿，向文武二帝行禮；進殿後沿中軸走過金鹿與立地大香爐，石階之上才是神壇。進出時放輕腳步，殿內保持安靜。",
        "上香以三炷為常見：先點香、後插爐。心意比數目重要，不必爭先。",
        "求籤前先默念一件最想釐清的事，搖出籤號後要擲得聖筊（一正一反）才算確認。",
        "在本頁：底部「參拜」示範三鞠躬；「上香」可選三炷清香或一炷心香；「求籤」按住籤筒搖、放手出籤，再擲筊確認。",
        "各廟做法略有不同，現場以廟方告示為準；畫面上的動作是本站的簡化互動設計，不是廟方規定。"
      ],
      src: "以上為一般華人廟宇禮俗與本頁操作的說明。"
    },
    {
      id: "tour", title: "帶我看看",
      lines: [
        "我帶你走兩個地方：先在殿中央看金鹿——善信會在鹿身貼金箔祈願；再過立地大香爐、拾級而上，到正殿神壇看文武二帝。",
        "選一個地方，我送你過去；到了慢慢看，不用急。"
      ],
      src: "帶位只移動你的位置與視線，不會替你參拜。"
    }
  ];
  var GUIDE_PLACES = [
    { key: "altar", label: "正殿神壇", station: "altar", dist: 2.5, via: [[2.9, 5.0], [2.9, .2]], note: "正殿神壇 · 面向文武二帝，右文左武。" },
    { key: "deer", label: "金鹿", station: "deer", dist: 2.4, via: [], note: "金鹿 · 鹿喻俸祿，善信貼金箔祈願。" }
  ];

  var guide = {
    g: null, rig: null, restYaw: -1.3, open: false, topic: -1,
    targetYaw: null, nod: 0, gest: 0, voiceBtn: null, playing: false,
    clickBound: false, nearWrapped: false, lastTravel: null, noteTimer: null
  };

  function buildGuideNpc() {
    var g = new T.Group();
    g.name = "guideNpc";
    var jacketM = mat("#33475b", { roughness: .95 });      /* 平口短褂：素深藍，無花紋 */
    var trousersM = mat("#1c2026", { roughness: .97 });    /* 深色長褲 */
    var shoeM = mat("#141618", { roughness: .92 });
    var goldMat = mat("#c9a24e", { metalness: .8, roughness: .35 });
    if (!skinMat) skinMat = mat("#b98a66", { roughness: .9 });
    var hairM = mat("#4a4239", { roughness: .96 });

    var hips = new T.Group(); hips.name = "hips"; hips.position.y = .86; g.add(hips);
    [-1, 1].forEach(function (s, n) {
      var hx = s * .10, kx = s * .115, ax = s * .12;
      npcSeg(hips, hx, .03, 0, kx, -.40, .02, .098, .082, trousersM).name = n ? "thighR" : "thighL";
      npcSeg(hips, kx, -.40, .02, ax, -.76, -.01, .078, .062, trousersM).name = n ? "shinR" : "shinL";
      npcBox(hips, .105, .055, .235, shoeM, ax, -.828, .05).name = n ? "footR" : "footL";
    });

    var upper = new T.Group(); upper.name = "upper"; upper.position.y = .02; hips.add(upper);
    cyl(.298, .262, .58, jacketM, 0, .30, 0, upper, 12).name = "jacket";
    cyl(.108, .118, .075, jacketM, 0, .60, 0, upper, 12).name = "collar";
    /* v96：領口金邊 */
    mesh(new T.TorusGeometry(.112, .007, 6, 16), goldMat, 0, .565, 0, upper).rotation.x = Math.PI / 2;
    box(.05, .44, .022, mat("#26333f", { roughness: .95 }), 0, .28, .272, upper).name = "placket";
    /* v96：盤扣三對 + 下擺金邊 + 胸袋巾 — 唐裝唔再係素面 */
    [.14, .28, .42].forEach(function (by) {
      mesh(new T.TorusGeometry(.018, .006, 6, 12), goldMat, 0, by, .285, upper).name = "frogButton";
      mesh(new T.SphereGeometry(.011, 8, 6), goldMat, .028, by, .285, upper).name = "frogKnot";
    });
    mesh(new T.TorusGeometry(.27, .01, 6, 20), goldMat, 0, .02, 0, upper).rotation.x = Math.PI / 2;
    box(.07, .09, .012, mat("#e8d8b0", { roughness: .9 }), -.12, .44, .27, upper).name = "pocketSquare";

    function arm(s, nm) {
      var a = new T.Group(); a.name = nm; a.position.set(s * .262, .545, 0); upper.add(a);
      npcSeg(a, 0, 0, 0, 0, -.27, .012, .073, .062, jacketM).name = nm + "Upper";
      npcSeg(a, 0, -.27, .012, 0, -.495, .038, .06, .05, jacketM).name = nm + "Fore";
      /* v96：袖口金邊 */
      mesh(new T.TorusGeometry(.055, .008, 6, 14), goldMat, 0, -.48, .036, a).rotation.x = 1.15;
      npcSphere(a, .052, skinMat, 0, -.54, .042).scale.set(.9, 1.08, 1);
      return a;
    }
    var armL = arm(-1, "armL"), armR = arm(1, "armR");

    var neck = new T.Group(); neck.name = "neck"; neck.position.set(0, .615, 0); upper.add(neck);
    cyl(.055, .062, .1, skinMat, 0, .04, 0, neck, 10).name = "neckCol";
    var head = new T.Group(); head.name = "head"; head.position.set(0, .085, 0); neck.add(head);
    npcSphere(head, .135, skinMat, 0, .09, 0).name = "headBall";
    npcSphere(head, .142, hairM, 0, .105, -.028).scale.set(1, .82, 1);
    head.children[1].name = "hair";

    /* 整個 subtree 排除 optimizeStatic；root 帶 ph 供測試辨識 */
    g.userData = {
      ph: Math.random() * 6.28, dynamic: true, guide: true, kneel: false,
      rig: { hips: hips, upper: upper, neck: neck, head: head, armL: armL, armR: armR }
    };
    g.traverse(function (o) { if (o !== g) o.userData.dynamic = true; });
    return g;
  }

  /* ---------- 對話面板 ---------- */
  function gmStyle() {
    if (document.getElementById("gmStyle")) return;
    var s = document.createElement("style");
    s.id = "gmStyle";
    s.textContent = [
      "#" + GM_ID + "{position:fixed;left:50%;bottom:calc(env(safe-area-inset-bottom,0px) + 96px);z-index:42;",
      "transform:translateX(-50%) translateY(14px);width:min(94vw,470px);max-height:52vh;overflow:auto;",
      "padding:13px 16px 12px;border-radius:16px;text-align:left;font-family:var(--sans);",
      "background:linear-gradient(168deg,rgba(46,17,11,.97),rgba(22,9,6,.98));border:1px solid var(--gold-soft);",
      "box-shadow:0 18px 50px rgba(0,0,0,.6);opacity:0;pointer-events:none;transition:opacity .24s,transform .3s}",
      "#" + GM_ID + ".open{opacity:1;pointer-events:auto;transform:translateX(-50%) translateY(0)}",
      "#" + GM_ID + " .gm-h{display:flex;align-items:flex-start;gap:8px;margin-bottom:6px}",
      "#" + GM_ID + " h3{margin:0;font-family:var(--serif);font-weight:400;font-size:15px;letter-spacing:.18em;color:var(--gold)}",
      "#" + GM_ID + " .gm-tag{display:inline-block;margin-top:5px;font-size:10px;letter-spacing:.06em;color:var(--muted);",
      "border:1px solid var(--gold-soft);border-radius:999px;padding:2px 8px}",
      "#" + GM_ID + " .gm-hb{margin-left:auto;display:flex;gap:6px}",
      "#" + GM_ID + " .gm-hb button{width:30px;height:30px;border-radius:50%;border:1px solid var(--gold-soft);",
      "background:none;color:var(--muted);font-size:13px;line-height:1}",
      "#" + GM_ID + " .gm-hb button.on{color:var(--gold);border-color:var(--gold)}",
      "#" + GM_ID + " .gm-body p{margin:0 0 9px;font-size:13.5px;line-height:1.84;letter-spacing:.02em;color:var(--ink)}",
      "#" + GM_ID + " .gm-body p.gm-src{font-size:10px;line-height:1.6;color:var(--muted);margin-bottom:4px}",
      "#" + GM_ID + " .gm-topics{display:flex;flex-wrap:wrap;gap:6px;margin:2px 0 9px}",
      "#" + GM_ID + " .gm-topics button,.gm-place{font-family:var(--sans);cursor:pointer}",
      "#" + GM_ID + " .gm-topics button{flex:0 0 auto;padding:8px 13px;border-radius:999px;border:1px solid var(--gold-soft);",
      "background:rgba(58,22,15,.75);color:var(--ink);font-size:12px;letter-spacing:.06em}",
      "#" + GM_ID + " .gm-topics button.on{background:linear-gradient(180deg,#9c2a1c,#6d1a12);border-color:var(--gold);color:#ffeecb}",
      "#" + GM_ID + " .gm-place{display:block;width:100%;margin:7px 0 0;padding:9px 12px;border-radius:10px;",
      "border:1px solid var(--gold-soft);background:rgba(0,0,0,.22);color:var(--ink);font-size:12.5px;text-align:left}",
      "#" + GM_ID + " .gm-place b{color:var(--gold);font-weight:500}",
      "#gmNote{position:fixed;left:50%;bottom:calc(env(safe-area-inset-bottom,0px) + 214px);transform:translateX(-50%);",
      "z-index:23;max-width:84vw;padding:8px 14px;border-radius:10px;background:rgba(20,8,5,.84);",
      "border:1px solid var(--gold-soft);color:var(--ink);font-size:12px;opacity:0;transition:opacity .3s;pointer-events:none;text-align:center}",
      "#gmNote.on{opacity:1}"
    ].join("");
    document.head.appendChild(s);
  }

  function gmEnsure() {
    gmStyle();
    var p = document.getElementById(GM_ID);
    if (p) return p;
    p = document.createElement("div");
    p.id = GM_ID;
    p.setAttribute("role", "dialog");
    p.setAttribute("aria-label", "廟祝對話");
    p.innerHTML = '<div class="gm-h"><div><h3>廟祝 · 陳伯</h3>' +
      '<span class="gm-tag">虛擬角色 · 預錄腳本 · 非官方</span></div>' +
      '<div class="gm-hb"><button id="gmVoice" aria-label="粵語朗讀" aria-pressed="false">粵語</button>' +
      '<button id="gmClose" aria-label="結束對話">✕</button></div></div>' +
      '<div class="gm-topics" id="gmTopics"></div>' +
      '<div class="gm-body" id="gmBody"></div>';
    document.body.appendChild(p);
    p.querySelector("#gmClose").onclick = gmClose;
    guide.voiceBtn = p.querySelector("#gmVoice");
    guide.voiceBtn.onclick = function () {
      if (guide.playing) gmStopVoice();
      else gmSpeak();
    };
    return p;
  }

  function gmRender() {
    var p = gmEnsure();
    var body = p.querySelector("#gmBody"), tp = p.querySelector("#gmTopics");
    var t = guide.topic >= 0 ? GUIDE_TOPICS[guide.topic] : null;
    var html = "";
    if (!t) {
      html = "<p>善信你好，我是文武廟的廟祝。想聽哪一方面？</p>" +
        "<p class='gm-src'>廟內講解為預先寫定的固定腳本，不是即時對話。</p>";
    } else {
      t.lines.forEach(function (l) { html += "<p>" + l + "</p>"; });
      if (t.id === "tour") {
        GUIDE_PLACES.forEach(function (pl) {
          html += "<button class='gm-place' data-place='" + pl.key + "'><b>" + pl.label + "</b> · 帶我過去</button>";
        });
      }
      html += "<p class='gm-src'>" + t.src + "</p>";
    }
    html += "<p class='gm-src'>粵語錄音由本站錄製；按右上「粵語」才會播放，不會自動出聲。內容為預錄腳本，並非即時對話。</p>";
    body.innerHTML = html;
    var bh = "";
    GUIDE_TOPICS.forEach(function (x, i) {
      bh += "<button data-t='" + i + "' class='" + (guide.topic === i ? "on" : "") + "'>" + x.title + "</button>";
    });
    tp.innerHTML = bh;
    tp.onclick = function (e) {
      var b = e.target.closest("[data-t]");
      if (!b) return;
      gmChoose(+b.getAttribute("data-t"));
    };
    body.onclick = function (e) {
      var b = e.target.closest("[data-place]");
      if (!b) return;
      gmTravel(b.getAttribute("data-place"));
    };
  }

  /* ---------- 粵語語音：預先產生的 edge-tts 靜態錄音（zh-HK WanLung） ----------
     不在開啟或切換主題時自動播放；只有使用者按「粵語」才播。
     播放時壓低 BGM，結束／停止／關閉即回復音量。
     錄音失敗才退回瀏覽器粵語語音（只接受 zh-HK/zh-MO/yue，不用華語代讀）；
     兩者皆無時顯示真實提示，不假裝有聲。 */
  var GM_VOICE_BASE = "assets/voice/";
  var gmAudio = null, gmSpeakToken = 0;

  function gmVoiceKey() {
    return guide.topic >= 0 ? GUIDE_TOPICS[guide.topic].id : "greet";
  }
  function gmText() {
    return guide.topic >= 0 ? GUIDE_TOPICS[guide.topic].lines.join(" ") : "善信你好，我係文武廟嘅廟祝陳伯。想聽邊一方面？";
  }
  function gmAudioEl() {
    if (gmAudio) return gmAudio;
    gmAudio = new Audio();
    gmAudio.preload = "auto";
    gmAudio.addEventListener("ended", function () { gmStopVoice(); });
    gmAudio.addEventListener("error", function () { if (guide.playing) gmVoiceFail(gmAudio.src); });
    return gmAudio;
  }
  function gmDuck() { if (MM.audio && MM.audio.duck) { try { MM.audio.duck(.2); } catch (e) { } } }
  function gmUnduck() { if (MM.audio && MM.audio.unduck) { try { MM.audio.unduck(); } catch (e) { } } }
  function gmMark(on) {
    guide.playing = !!on;
    if (!guide.voiceBtn) return;
    guide.voiceBtn.classList.toggle("on", !!on);
    guide.voiceBtn.setAttribute("aria-pressed", on ? "true" : "false");
    guide.voiceBtn.textContent = on ? "停止" : "粵語";
  }
  function gmPickCantoVoice() {
    if (!("speechSynthesis" in window)) return null;
    var vs = window.speechSynthesis.getVoices() || [], i, v;
    for (i = 0; i < vs.length; i++) {
      v = vs[i];
      if (/^zh[-_](hk|mo)/i.test(v.lang || "") || /cantonese|粵|yue/i.test(v.name || "")) return v;
    }
    return null;
  }
  function gmVoiceFail(src) {
    gmMark(false); gmUnduck();
    var v = gmPickCantoVoice();
    if (v) {
      try {
        var synth = window.speechSynthesis;
        var u = new window.SpeechSynthesisUtterance(gmText().replace(/[「」『』]/g, ""));
        u.voice = v; u.lang = v.lang || "zh-HK"; u.rate = .96; u.pitch = .96; u.volume = .9;
        synth.cancel(); synth.speak(u);
        gmMark(true);
        u.onend = function () { gmStopVoice(); };
        return;
      } catch (e) { }
    }
    gmNote("此裝置未能播放粵語錄音，亦沒有粵語語音；以下文字就是完整內容。");
  }
  function gmSpeak() {
    gmStopVoice();
    var key = gmVoiceKey(), token = ++gmSpeakToken;
    var a = gmAudioEl();
    try {
      a.src = GM_VOICE_BASE + key + ".mp3";
      var pr = a.play();
      gmDuck(); gmMark(true);
      if (pr && pr.catch) pr.catch(function () { if (token === gmSpeakToken) gmVoiceFail(); });
    } catch (e) { gmVoiceFail(); }
  }
  function gmStopVoice() {
    gmSpeakToken++;
    if (gmAudio) { try { gmAudio.pause(); gmAudio.currentTime = 0; } catch (e) { } }
    try { if ("speechSynthesis" in window) window.speechSynthesis.cancel(); } catch (e) { }
    gmMark(false); gmUnduck();
  }

  function gmNote(text) {
    var n = document.getElementById("gmNote");
    if (!n) { n = document.createElement("div"); n.id = "gmNote"; document.body.appendChild(n); }
    n.textContent = text;
    n.classList.add("on");
    clearTimeout(guide.noteTimer);
    guide.noteTimer = setTimeout(function () { n.classList.remove("on"); }, 3600);
  }

  function gmOpen() {
    if (!guide.g) return;
    guide.open = true;
    guide.topic = -1;
    guide.nod = 1;
    gmFaceTarget();
    var p = gmEnsure();
    gmRender();
    p.classList.add("open");
    if (MM.audio && MM.audio.wood) { try { MM.audio.wood(1); } catch (e) { } }
  }
  function gmClose() {
    guide.open = false;
    var p = document.getElementById(GM_ID);
    if (p) p.classList.remove("open");
    gmStopVoice();
    if (guide.g) guide.targetYaw = guide.restYaw;
  }
  function gmChoose(i) {
    var t = GUIDE_TOPICS[i];
    if (!t) return;
    guide.topic = i;
    guide.nod = Math.max(guide.nod, .8);
    gmStopVoice();
    gmRender();
    if (MM.audio && MM.audio.wood) { try { MM.audio.wood(1.1); } catch (e) { } }
  }
  function gmFaceTarget() {
    if (!guide.g || !U.player) return;
    guide.targetYaw = Math.atan2(U.player.x - guide.g.position.x, U.player.z - guide.g.position.z);
  }
  function gmFacingDot() {
    if (!guide.g || !U.player) return 0;
    var dx = U.player.x - guide.g.position.x, dz = U.player.z - guide.g.position.z;
    var d = Math.hypot(dx, dz) || 1;
    return Math.sin(guide.g.rotation.y) * (dx / d) + Math.cos(guide.g.rotation.y) * (dz / d);
  }
  function gmPlace(key) {
    for (var i = 0; i < GUIDE_PLACES.length; i++) if (GUIDE_PLACES[i].key === key) return GUIDE_PLACES[i];
    return null;
  }
  function gmBlocked(x1, z1, x2, z2) {
    var obs = U.obstacles || [], i;
    var vx = x2 - x1, vz = z2 - z1, L = vx * vx + vz * vz || 1;
    for (i = 0; i < obs.length; i++) {
      var o = obs[i];
      if (o.r > 2) continue;                       /* 大型裝飾圈不當作通道障礙 */
      var t = ((o.x - x1) * vx + (o.z - z1) * vz) / L;
      t = Math.max(0, Math.min(1, t));
      var dx = x1 + vx * t - o.x, dz = z1 + vz * t - o.z;
      if (Math.hypot(dx, dz) < o.r + .30) return true;
    }
    return false;
  }
  function gmTravel(key) {
    var pl = gmPlace(key);
    if (!pl) return false;
    var s = U.stations && U.stations[pl.station];
    if (!s) return false;
    if (MM.Incense && MM.Incense.isBusy && MM.Incense.isBusy()) {
      gmNote("儀式進行中，稍後再帶你過去。");
      return false;
    }
    var dx = Math.sin(s.face) * pl.dist, dz = Math.cos(s.face) * pl.dist;
    var tx = s.x - dx, tz = s.z - dz;
    guide.lastTravel = { key: key, label: pl.label, station: pl.station, target: [tx, tz], yaw: s.face, at: Date.now() };
    gmClose();
    var p = U.player;
    var direct = !p || !gmBlocked(p.x, p.z, tx, tz);
    /* 直線被香案／金鹿基座擋住時，沿中央通道繞行，避免碰撞卡住。 */
    var legs = direct ? [] : (pl.via || []).slice();
    var step = function (i) {
      if (i < legs.length) {
        MM.walkTo(legs[i][0], legs[i][1], null, function () { step(i + 1); });
      } else {
        MM.setCam(tx, tz, s.face, -.06);
        gmNote(pl.note);
      }
    };
    step(0);
    return true;
  }

  /* 點擊廟祝本體（不干擾拖曳轉視角：位移 >8px 或按住 >600ms 視為拖曳） */
  function gmHit(cx, cy) {
    if (!U.camera || !guide.g || !U.renderer) return false;
    var r = U.renderer.domElement.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    var ndc = new T.Vector2(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
    var ray = new T.Raycaster();
    ray.setFromCamera(ndc, U.camera);
    var hits = ray.intersectObject(guide.g, true);
    if (!hits.length) return false;
    if (hits[0].distance > 8) { gmNote("走近一點，再點一下廟祝。"); return false; }
    return true;
  }
  function gmBindClick() {
    if (guide.clickBound || !U.renderer) return;
    guide.clickBound = true;
    var el = U.renderer.domElement, down = null;
    el.addEventListener("pointerdown", function (e) {
      down = { x: e.clientX, y: e.clientY, t: Date.now() };
    }, { passive: true });
    el.addEventListener("pointerup", function (e) {
      if (!down) return;
      var moved = Math.hypot(e.clientX - down.x, e.clientY - down.y), held = Date.now() - down.t;
      down = null;
      if (moved > 8 || held > 600) return;
      if (gmHit(e.clientX, e.clientY)) gmOpen();
    }, { passive: true });
  }

  /* 靠近時提示可對話，沿用 app.js 的 near chip（不新增按鈕、不強制開鏡頭） */
  function gmWrapNear() {
    if (guide.nearWrapped || !MM.onNear) return;
    guide.nearWrapped = true;
    var orig = MM.onNear;
    MM.onNear = function (s) {
      if (s && s.id === "guide") {
        var el = document.getElementById("nearChip");
        if (!el) return;
        el.classList.remove("hidden");
        el.innerHTML = "<span>廟祝 · 問問廟祝</span><b style='color:#ffe0a6'>對話 ›</b>";
        el.onclick = function () { gmOpen(); };
        return;
      }
      orig(s);
    };
  }

  var gmNameTag = null, gmTagPoint = new T.Vector3();
  function gmUpdateNameTag() {
    if (!gmNameTag || !guide.g || !U.camera || !U.renderer) return;
    gmTagPoint.set(4.6, 2.18, 6.0).project(U.camera);
    var r = U.renderer.domElement.getBoundingClientRect();
    var x = r.left + (gmTagPoint.x + 1) * r.width / 2;
    var y = r.top + (1 - gmTagPoint.y) * r.height / 2;
    var hidden = guide.open || gmTagPoint.z < -1 || gmTagPoint.z > 1 ||
      x < r.left + 66 || x > r.right - 66 || y < r.top + 145 || y > r.bottom - 130;
    gmNameTag.hidden = hidden;
    if (!hidden) { gmNameTag.style.left = x + 'px'; gmNameTag.style.top = y + 'px'; }
  }
  function gmSetup() {
    gmBindClick();
    if (!gmNameTag) {
      gmNameTag = document.createElement('button');
      gmNameTag.id = 'guideNameTag'; gmNameTag.type = 'button';
      gmNameTag.setAttribute('aria-label', '請教廟祝，點擊開始對話');
      gmNameTag.innerHTML = '<b style="display:block;font-size:15px">廟祝</b><span style="font-size:12px">點我傾偈 ›</span>';
      gmNameTag.style.cssText = 'position:fixed;z-index:12;transform:translate(-50%,-100%);padding:7px 15px;border:1px solid #eac989;border-radius:8px;background:rgba(45,23,15,.94);color:#ffe4ad;line-height:1.5;text-align:center;cursor:pointer;box-shadow:0 3px 12px #0006;min-width:110px;pointer-events:auto;';
      gmNameTag.hidden = true;
      gmNameTag.addEventListener('click', function (e) { e.stopPropagation(); gmOpen(); });
      document.body.appendChild(gmNameTag);
    }
    (U.obstacles = U.obstacles || []).push({ x: 4.6, z: 6.0, r: .45 });
    if (U.stations && !U.stations.guide) {
      U.addStation("guide", "廟祝 · 問問廟祝", 4.6, 6.0, Math.PI * 1.5, 2.4);
    }
  }

  function gmUpdate(dt, t) {
    gmUpdateNameTag();
    var r = guide.rig;
    if (!r) return;
    if (guide.targetYaw != null) {
      var d = ((guide.targetYaw - guide.g.rotation.y + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      if (Math.abs(d) < .006) { guide.g.rotation.y = guide.targetYaw; guide.targetYaw = null; }
      else guide.g.rotation.y += d * Math.min(1, dt * 5);
    }
    var breath = Math.sin(t * 1.05) * .008;
    r.hips.position.y = .86 + breath;
    r.upper.rotation.x = -.02 + Math.sin(t * .82) * .012;
    r.upper.rotation.z = Math.sin(t * .61) * .01;
    var look = guide.open ? 0 : Math.sin(t * .37) * .16;
    r.neck.rotation.y = look * .5;
    r.head.rotation.y = look;
    if (guide.nod > 0) {
      guide.nod = Math.max(0, guide.nod - dt / .95);
      var k = Math.sin(Math.PI * (1 - guide.nod));
      r.head.rotation.x = -.26 * k;
      r.neck.rotation.x = -.09 * k;
    } else {
      r.head.rotation.x = -.03 + Math.sin(t * .9) * .01;
      r.neck.rotation.x = -.02;
    }
    guide.gest += (guide.open ? 1 : -1) * dt * 2.2;
    guide.gest = Math.max(0, Math.min(1, guide.gest));
    r.armR.rotation.x = -.10 - .40 * guide.gest;
    r.armR.rotation.z = .16 + .10 * guide.gest;
    r.armL.rotation.x = -.08 + Math.sin(t * .7) * .02;
    r.armL.rotation.z = -.16;
  }

  MM.guideNPC = {
    id: "guide", name: "廟祝 · 陳伯", virtual: true, scripted: true,
    spots: [4.6, 6.0], topics: GUIDE_TOPICS, places: GUIDE_PLACES,
    node: null,
    isOpen: function () { return !!guide.open; },
    currentTopic: function () { return guide.topic; },
    open: gmOpen, close: gmClose, choose: gmChoose, travelTo: gmTravel,
    faceUser: function () { gmFaceTarget(); },
    facingDot: gmFacingDot,
    yaw: function () { return guide.g ? guide.g.rotation.y : 0; },
    lastTravel: function () { return guide.lastTravel; },
    voiceState: function () {
      return {
        playing: !!guide.playing,
        src: gmAudio ? gmAudio.src : null,
        paused: gmAudio ? gmAudio.paused : true,
        currentTime: gmAudio ? gmAudio.currentTime : 0,
        duck: MM.audio && MM.audio.duckState ? MM.audio.duckState() : null,
        speech: !!("speechSynthesis" in window) && !!window.speechSynthesis.speaking
      };
    },
    _audio: function () { return gmAudioEl(); },
    reset: function () {
      gmClose(); guide.lastTravel = null;
      if (guide.g) { guide.g.rotation.y = guide.restYaw; guide.targetYaw = null; }
      guide.nod = 0; guide.gest = 0;
    }
  };

  /* 跪拜動畫：一個循環 = 4.5s 緩慢俯身（含短暫停留）+ 4.5s 靜止休息；
     兩位善信相差半個循環，一位躬身時另一位休息。 */
  function npcSmooth(u) { u = u < 0 ? 0 : u > 1 ? 1 : u; return u * u * (3 - 2 * u); }
  function npcBowCurve(p) {
    if (p < .10 || p >= .62) return 0;
    if (p < .30) return npcSmooth((p - .10) / .20);
    if (p < .40) return 1;
    return npcSmooth(1 - (p - .40) / .22);
  }
  /* 測試與正式動畫共用同一支姿態函數：index = 第幾位跪姿善信，time = 秒 */
  MM.poseKneelingVisitor = function (index, time) {
    var g = U.kneelers && U.kneelers[index];
    if (!g || !g.userData.rig) return 0;
    var r = g.userData.rig;
    var p = ((((time + KNEE.stagger * index) % KNEE.cycle) + KNEE.cycle) % KNEE.cycle) / KNEE.cycle;
    var k = npcBowCurve(p);
    var breath = Math.sin(time * 1.15 + index * 2.1) * .014 * (1 - k);
    r.hip.rotation.x = -(.04 + .07 * k);
    r.spine.rotation.x = -(.10 + .46 * k) + breath;
    r.spine.position.y = -.02 * k;
    r.spine.position.z = -.015 * k;
    r.neck.rotation.x = -(.06 + .10 * k) - breath * .5;
    r.head.rotation.x = -(.04 + .06 * k);
    r.k = k;
    return k;
  };


  /* ---------------- extra furnishings ---------------- */
  function buildDetails() {
    /* 善信與拜墊共用站位；中央留給使用者，避開香案與主爐。 */
    [-2.2, 0, 2.2].forEach(function (x) {
      var g = new T.Group(); g.position.set(x, 0, x === 0 ? -1.6 : -2.5); scene.add(g);
      box(1.18, .1, 1.12, mat("#7c1a12", { roughness: .9 }), 0, .05, 0, g);
      box(1.24, .04, 1.18, gold(), 0, .02, 0, g);
      box(.98, .02, .92, mat("#a8321f", { roughness: 1 }), 0, .11, 0, g);
      var t = new T.Mesh(new T.PlaneGeometry(.4, .4), new T.MeshBasicMaterial({ map: textTexture("拜", { size: 80, color: "#e2b878" }), transparent: true }));
      t.rotation.x = -Math.PI / 2; t.position.set(0, .122, 0); g.add(t);
    });
    /* 香案 with censer：按實地平面圖，香案在神壇平台上、神案之前，
       唔再擺喺石階前面擋住上殿嘅樓梯。 */
    var t = new T.Group(); t.position.set(0, U.PZ, -8.28); scene.add(t);
    box(4.6, .08, .5, mat("#5a1a10", { roughness: .6 }), 0, .92, 0, t);
    box(4.8, .06, .58, gold(), 0, .98, 0, t);
    [-2.0, 2.0].forEach(function (x) {
      box(.16, .9, .16, mat("#3f0d08"), x, .45, .2, t);
      box(.16, .9, .16, mat("#3f0d08"), x, .45, -.2, t);
    });
    var bronze = mat("#6b5232", { metalness: .82, roughness: .38 });
    var cg = new T.Group(); cg.position.set(0, 1.01, 0); t.add(cg);  /* v96：爐座落喺金邊枱面頂（1.01），唔再沉入枱面 */
    var smF = U.makeSmoke(24, { base: new T.Vector3(0, 1.99 + U.PZ, -8.28), size: .3, opacity: .16, rise: 1.5, spread: .25, speed: .34 });
    if (MM.Incense) MM.Incense.register({ id: "front", name: "香案爐", group: cg, ashY: .66, approach: { x: -1.3, z: -7.1 }, smoke: smF });
    /* v98：香盤移去香案左邊 — v96 擺喺供桌右邊（x=+.55），但取香動畫（incense.js「到香案前取三炷清香」）係行去香案左邊 approach (-1.3, -7.1)，兩邊唔對。家下香盤放喺香案枱面左邊，正正係取香企位前方，動畫同字幕一致。
       黃銅淺盤 + 紅布墊 + 三炷平放清香 + 五炷紮埋嘅備用香。 */
    (function () {
      var tr = new T.Group(); tr.position.set(-1.3, 1.01, 0); t.add(tr);
      cyl(.22, .16, .03, gold(), 0, .015, 0, tr, 20);
      mesh(new T.TorusGeometry(.21, .012, 6, 24), gold(), 0, .03, 0, tr).rotation.x = Math.PI / 2;
      cyl(.19, .19, .008, mat("#7a1208", { roughness: .9 }), 0, .032, 0, tr, 20);
      /* 三炷平放清香（取香用）：香身 + 紅色香頭 */
      [-.055, 0, .055].forEach(function (tz, ti) {
        var st = cyl(.008, .008, .42, mat("#c9a878", { roughness: .8 }), 0, .048, tz, tr, 6);
        st.rotation.z = Math.PI / 2; st.rotation.y = (ti - 1) * .06;
        mesh(new T.SphereGeometry(.011, 8, 6), mat("#a8201a", { roughness: .6 }), .21, .048, tz + (ti - 1) * .012, tr);
      });
      /* 五炷備用香紮埋一束，紅線綁住 */
      for (var bi = 0; bi < 5; bi++) {
        var bs = cyl(.007, .007, .40, mat("#b89a68", { roughness: .8 }), -.02 + bi * .012, .075, -.12, tr, 5);
        bs.rotation.x = Math.PI / 2 - .12; bs.rotation.z = .08;
      }
      mesh(new T.TorusGeometry(.035, .006, 6, 14), mat("#a8201a", { roughness: .7 }), .01, .075, -.12, tr).rotation.x = .3;
      var tag = new T.Mesh(new T.PlaneGeometry(.16, .05), new T.MeshBasicMaterial({ map: textTexture("香盤", { size: 44, color: "#f0cd80", bg: "#5e0f08", pad: 8 }), transparent: true }));
      tag.position.set(0, .045, .225); tag.rotation.x = -.5; tr.add(tag);
      U.incenseTray = tr; U.lotIncenseTray = tr;
    })();
    cyl(.24, .34, .5, bronze, 0, .41, 0, cg, 20);  /* v96：爐身由三足托起，爐底喺 .16，唔再貼枱 */
    [-1, 1].forEach(function (s) { var hd = mesh(new T.TorusGeometry(.09, .018, 6, 12), bronze, s * .34, .50, 0, cg); hd.rotation.y = Math.PI / 2; });
    /* v96：三足由枱面（y=0）托到爐底（y=.16）—— 舊版足中心喺 -.06，足底穿到枱面以下 */
    for (var i = 0; i < 3; i++) cyl(.04, .055, .16, bronze, Math.cos(i * 2.1) * .2, .08, Math.sin(i * 2.1) * .2, cg, 8);
    cyl(.27, .27, .02, mat("#5a5348"), 0, .66, 0, cg, 16);
    for (i = 0; i < 5; i++) cyl(.01, .01, .38, mat("#8b5a2b"), rnd(-.16, .16), .85, rnd(-.16, .16), cg, 5);

    /* 木魚 + mallet */
    var w = new T.Group(); w.position.set(-1.9, 1.01, 0); t.add(w);
    mesh(new T.SphereGeometry(.2, 16, 12), mat("#6b3b1c", { roughness: .55 }), 0, .16, 0, w).scale.set(1.1, .8, 1);
    box(.34, .04, .05, mat("#b98c3e", { metalness: .6 }), .05, .36, 0, w).rotation.z = .3;

    /* hanging red banners */
    [["平安", -6.9], ["福", 6.9]].forEach(function (b) {
      var g = new T.Group(); g.position.set(b[1], 4.4, -7.2); scene.add(g);
      var m = new T.MeshStandardMaterial({ color: new T.Color("#9c1f14"), roughness: .85, side: T.DoubleSide });
      box(1.1, 2.6, .04, m, 0, 0, 0, g);
      box(1.24, .12, .1, gold(), 0, 1.36, 0, g);
      var ch = new T.Mesh(new T.PlaneGeometry(.62, .62), new T.MeshBasicMaterial({ map: textTexture(b[0], { size: 140, color: "#f6d38a", glow: true }), transparent: true }));
      ch.position.set(0, .55, .05); g.add(ch);
      var ch2 = new T.Mesh(new T.PlaneGeometry(.5, .5), new T.MeshBasicMaterial({ map: textTexture("吉祥", { size: 90, color: "#e9c37c" }), transparent: true }));
      ch2.position.set(0, -.35, .05); g.add(ch2);
      g.userData.ph = Math.random() * 6.28; U.banners = U.banners || []; U.banners.push(g);
    });

    /* extra offering boxes on the altar */
    [-2.2, 2.2].forEach(function (x) {
      var p = new T.Group(); p.position.set(x, ATLAR_Y, -9.95); scene.add(p);
      box(.3, .18, .3, gold(), 0, .09, 0, p);
      box(.26, .12, .26, mat("#8e1c14"), 0, .24, 0, p);
    });

    /* distant city silhouette */
    var cityMat = mat("#120c0b", { roughness: 1 });
    for (var k = 0; k < 12; k++) {
      var bw = rnd(3, 7), bh = rnd(8, 22), bx = rnd(-34, 34), bz = rnd(34, 46);
      box(bw, bh, bw, cityMat, bx, bh / 2, bz, null);
      for (var wnd = 0; wnd < 6; wnd++) {
        if (Math.random() > .6) mesh(new T.PlaneGeometry(.35, .5), new T.MeshBasicMaterial({ color: 0xffd79a, transparent: true, opacity: .35 }), bx + rnd(-bw / 2 + .5, bw / 2 - .5), rnd(2, bh - 1), bz - bw / 2 - .02, null);
      }
    }
    /* street lamps in the courtyard */
    [-9, 9].forEach(function (x) {
      var g = new T.Group(); g.position.set(x, 0, 22.5); scene.add(g);
      cyl(.08, .11, 3.2, mat("#26201a"), 0, 1.6, 0, g, 8);
      box(.5, .5, .5, mat("#e8c48a", { emissive: "#ffb860", emissiveIntensity: .8 }), 0, 3.3, 0, g);
      var spr = new T.Sprite(new T.SpriteMaterial({ map: U.TEX.glow, color: 0xffb060, transparent: true, opacity: .4, blending: T.AdditiveBlending, depthWrite: false }));
      spr.scale.setScalar(2.6); spr.position.set(0, 3.3, 0); g.add(spr);
      /* v97：街燈光暈呼吸 — 記低，等 U.onFrame 每格輕輕脈動 */
      (U.streetLampGlows = U.streetLampGlows || []).push({ spr: spr, ph: Math.random() * 6.28 });
    });
  }

  MM.enableShadows = function () {
    if (!U.renderer || !U.lights || !U.lights.spot) return;
    U.renderer.shadowMap.enabled = true;
    U.lights.spot.castShadow = true;
    scene.traverse(function (o) {
      if (!o.isMesh) return;
      o.receiveShadow = true;
      var m = o.material;
      if (!m || m.transparent) { o.castShadow = false; return; }
      if (!o.geometry.boundingSphere) o.geometry.computeBoundingSphere();
      var r = o.geometry.boundingSphere ? o.geometry.boundingSphere.radius : 0;
      var sc = Math.max(Math.abs(o.scale.x), Math.abs(o.scale.y), Math.abs(o.scale.z));
      o.castShadow = r * sc >= .34;   /* 細件（燈格、釘、花瓣）不投影，省 shadow pass */
    });
  };


  /* ---------------- 宮燈（八角絹燈，許願燈） ---------------- */
  function lanternPanelTex() {
    var t = U.cvs(256, 256, function (x, w, h) {
      x.fillStyle = "#f2e2bf"; x.fillRect(0, 0, w, h);
      /* 絹面暈染 */
      var g = x.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, w * .7);
      g.addColorStop(0, "rgba(255,246,220,.9)"); g.addColorStop(1, "rgba(214,170,110,.35)");
      x.fillStyle = g; x.fillRect(0, 0, w, h);
      /* 彩繪：折枝花 + 雲紋 */
      x.strokeStyle = "rgba(150,40,30,.55)"; x.lineWidth = 2;
      for (var i = 0; i < 3; i++) {
        var cx = 40 + i * 80, cy = 150 - (i % 2) * 40;
        x.beginPath(); x.moveTo(cx, cy + 40); x.quadraticCurveTo(cx + 18, cy, cx + 6, cy - 34); x.stroke();
        for (var k = 0; k < 4; k++) {
          x.beginPath(); x.arc(cx + 8 + Math.cos(k * 1.6) * 14, cy - 10 + Math.sin(k * 1.6) * 12, 6, 0, 6.28); x.stroke();
        }
      }
      x.strokeStyle = "rgba(180,120,40,.6)"; x.lineWidth = 3;
      x.beginPath(); x.moveTo(0, 26); x.bezierCurveTo(70, 6, 180, 46, 256, 20); x.stroke();
      x.beginPath(); x.moveTo(0, 232); x.bezierCurveTo(70, 212, 180, 252, 256, 226); x.stroke();
    });
    return t;
  }
  function buildPalaceLanterns() {
    var panel = lanternPanelTex();
    var frame = new T.MeshStandardMaterial({ color: new T.Color("#8a5a20"), metalness: .8, roughness: .35 });
    var silk = new T.MeshStandardMaterial({ map: panel, roughness: .9, emissive: new T.Color("#ffcf8a"), emissiveIntensity: .35, side: T.DoubleSide });
    [[-3.4, 3.2], [0, 3.2], [3.4, 3.2], [-3.4, .6], [3.4, .6]].forEach(function (p, i) {
      var g = new T.Group(); g.position.set(p[0], 4.2, p[1]); scene.add(g);
      cyl(.012, .012, 2.0, mat("#3a2412"), 0, 1.0, 0, g, 4);
      var body = cyl(.27, .27, .52, silk, 0, 0, 0, g, 8);
      cyl(.3, .3, .05, frame, 0, .27, 0, g, 8);
      cyl(.3, .3, .05, frame, 0, -.27, 0, g, 8);
      /* 八角頂 */
      mesh(new T.ConeGeometry(.33, .22, 8), frame, 0, .4, 0, g);
      /* 流蘇 */
      cyl(.028, .045, .34, mat("#a8281c", { roughness: .9 }), 0, -.48, 0, g, 6);
      for (var t = 0; t < 5; t++) cyl(.006, .006, .18, mat("#c0331f"), Math.cos(t * 1.26) * .03, -.72, Math.sin(t * 1.26) * .03, g, 4);
      var spr = new T.Sprite(new T.SpriteMaterial({ map: U.TEX.glow, color: 0xffc074, transparent: true, opacity: .5, blending: T.AdditiveBlending, depthWrite: false }));
      spr.scale.setScalar(1.5); g.add(spr);
      g.userData.ph = Math.random() * 6.28; g.userData.baseY = 4.2;
      (U.palaceLanterns = U.palaceLanterns || []).push(g);
    });
  }

  /* ---------------- 兩側捲棚頂廂房 ---------------- */
  function buildSideEaves() {
    var tile = new T.MeshStandardMaterial({ map: U.TEX.roof, roughness: .7 });
    [-1, 1].forEach(function (s) {
      var r = new T.Mesh(new T.CylinderGeometry(1.25, 1.25, HZ * 2 - .8, 18, 1, true, 0, Math.PI), tile);
      r.rotation.z = Math.PI / 2; r.rotation.y = Math.PI / 2;
      r.position.set(s * (HX - .55), 4.75, 0);
      r.material.side = T.DoubleSide; scene.add(r);
      for (var z = -10; z <= 10; z += 5) {
        cyl(.11, .13, 4.6, mat("#4a1a10"), s * (HX - 1.55), 2.3, z, null, 10);
      }
      box(.12, .14, HZ * 2 - .8, gold(), s * (HX - .35), 4.1, 0);
    });
  }

  /* ---------------- 桃花樹 + 人力車（廟前打卡位） ---------------- */
  function buildCourtyardProps() {
    [-3.6, 3.6].forEach(function (x, i) {
      var g = new T.Group(); g.position.set(x, 0, 19.4); scene.add(g);
      cyl(.16, .24, 1.7, mat("#4a2c18", { roughness: .9 }), 0, .85, 0, g, 8);
      for (var b = 0; b < 6; b++) {
        var a = b / 6 * 6.28, br = cyl(.05, .09, 1.1, mat("#4a2c18"), Math.cos(a) * .35, 1.9, Math.sin(a) * .35, g, 6);
        br.rotation.z = Math.cos(a) * .5; br.rotation.x = Math.sin(a) * .5;
      }
      var pink = [0xf6b8c8, 0xf9d0da, 0xef9db4];
      for (var k = 0; k < 46; k++) {
        var rr = rnd(.2, 1.0), aa = Math.random() * 6.28, hh = rnd(1.9, 3.0);
        mesh(new T.SphereGeometry(rnd(.07, .15), 6, 5), mat(pink[k % 3], { roughness: .95 }), Math.cos(aa) * rr, hh, Math.sin(aa) * rr, g);
      }
      /* 紅繩許願卡 */
      for (var c = 0; c < 5; c++) box(.06, .1, .01, mat("#c0392b"), rnd(-.8, .8), rnd(1.2, 2.2), rnd(-.8, .8), g);
      U.addStation("peach" + i, "桃花樹 · 拍照打卡", x, 19.4, Math.PI, 2.0);
    });

    /* 人力車 */
    var r = new T.Group(); r.position.set(6.4, 0, 20.6); r.rotation.y = -.5; scene.add(r);
    var wood = mat("#5a2a14", { roughness: .8 });
    box(1.5, .12, 1.05, wood, 0, .55, 0, r);
    box(1.5, .55, .1, wood, 0, .82, -.5, r);
    box(.95, .1, .9, mat("#8a1f14", { roughness: .85 }), .1, .63, 0, r);
    /* 車篷 */
    var top = new T.Mesh(new T.CylinderGeometry(.72, .72, 1.35, 16, 1, true, 0, Math.PI), mat("#2a1a12", { roughness: .9, side: T.DoubleSide }));
    top.rotation.z = Math.PI / 2; top.rotation.y = Math.PI / 2; top.position.set(-.05, .62, 0); r.add(top);
    /* 輪 */
    [-1, 1].forEach(function (s) {
      var w = new T.Mesh(new T.TorusGeometry(.5, .05, 8, 20), wood); w.position.set(-.35, .5, s * .62); w.rotation.y = Math.PI / 2; r.add(w);
      for (var sp = 0; sp < 8; sp++) {
        var spoke = cyl(.015, .015, .95, mat("#7a4a22"), -.35, .5, s * .62, r, 4);
        spoke.rotation.x = sp / 8 * Math.PI; spoke.rotation.z = .4;
      }
    });
    /* 拉桿 */
    [-1, 1].forEach(function (s) {
      var h = cyl(.035, .04, 1.2, wood, .95, .62, s * .35, r, 6);
      h.rotation.z = -.9;
    });
    U.addStation("rickshaw", "人力車 · 拍照打卡", 6.4, 20.6, Math.PI, 2.0);
  }

  /* ---------------- per-frame ---------------- */
  U.onFrame = function (dt, t) {
    /* bell swing */
    if (bellSwing > 0) {
      bellSwing = Math.max(0, bellSwing - dt * .9);
      if (bell) bell.rotation.z = Math.sin(bellSwing * 14) * .18 * bellSwing;
    }
    if (drumHit > 0) {
      drumHit = Math.max(0, drumHit - dt * 2.4);
      if (drum) drum.scale.setScalar(1 + Math.sin(drumHit * 12) * .03 * drumHit);
    }
    if (U.palaceLanterns) for (i = 0; i < U.palaceLanterns.length; i++) { var pl = U.palaceLanterns[i]; pl.rotation.z = Math.sin(t * .7 + pl.userData.ph) * .03; pl.position.y = pl.userData.baseY + Math.sin(t * .9 + pl.userData.ph) * .015; }
    /* wish tags sway */
    for (var i = 0; i < WISHES.length; i++) {
      var w = WISHES[i];
      w.rotation.z = Math.sin(t * 1.4 + w.userData.ph) * .1;
      w.rotation.x = Math.sin(t * 1.1 + w.userData.ph) * .05;
    }
    if (U.banners) for (i = 0; i < U.banners.length; i++) U.banners[i].rotation.z = Math.sin(t * .8 + U.banners[i].userData.ph) * .012;
    for (i = 0; i < U.coilTags.length; i++) { var tg = U.coilTags[i]; tg.rotation.z = Math.sin(t * 1.6 + tg.userData.ph) * .08; }
    /* npcs breathe；跪姿善信由 MM.poseKneelingVisitor 驅動（root 保持靜止）；
       廟祝由 gmUpdate 驅動（面向善信、點頭、抬手手勢） */
    if (U.npcs) for (i = 0; i < U.npcs.length; i++) {
      var n = U.npcs[i];
      if (n.userData.guide) { gmUpdate(dt, t); continue; }
      if (n.userData.kneel) { MM.poseKneelingVisitor(n.userData.kneelIndex, t); continue; }
      n.position.y = Math.sin(t * .9 + n.userData.ph) * .012;
      n.rotation.z = Math.sin(t * .4 + n.userData.ph) * .01;
    }
    /* lamp flicker */
    if (U.lampLight) U.lampLight.intensity = .42 + Math.sin(t * 3.1) * .04;
    /* v97：庭院街燈光暈呼吸 */
    if (U.streetLampGlows) for (var sli = 0; sli < U.streetLampGlows.length; sli++) {
      var sg = U.streetLampGlows[sli];
      sg.spr.material.opacity = .35 + Math.sin(t * 1.3 + sg.ph) * .08;
    }
    if (U.lotShake) updateLot(dt, t);
    if (U.jiaoAnim) updateJiao(dt, t);
  };

  /* ---------------- 求籤 shake ---------------- */
  var lotState = null;
  MM.shakeLot = function (cb) {
    lotState = { t: 0, cb: cb, done: false };
    U.lotShake = true;
    setTimeout(function () { if (lotState && !lotState.done) { lotState.done = true; U.lotShake = false; if (lotState.cb) lotState.cb(); } }, 1900);
  };
  function updateLot(dt, t) {
    if (!lotState) return;
    lotState.t += dt;
    var k = lotState.t;
    if (k < 1.15) {
      lotTube.rotation.z = Math.sin(k * 42) * .16 * (1 - k / 1.6);
      lotTube.rotation.x = Math.cos(k * 37) * .1 * (1 - k / 1.6);
      lotTube.position.y = ATLAR_Y + Math.abs(Math.sin(k * 26)) * .05;
    } else if (!lotState.done) {
      lotState.done = true;
      lotTube.rotation.set(0, 0, 0); lotTube.position.y = ATLAR_Y;
      /* one stick pops out */
      var st = cyl(.012, .012, .5, mat("#e6d2ab"), 0, 0, 0, lotTube, 6);
      st.position.set(rnd(-.06, .06), .9, rnd(-.06, .06));
      U.lotStick = st;
      U.lotShake = false;
      if (lotState.cb) lotState.cb();
    }
  }

  /* ---------------- 擲筊 ---------------- */
  var jiaoState = null;
  MM.throwJiao = function (result, cb) {
    /* clear previous blocks */
    scene.children.slice().forEach(function (o) { if (o.userData && o.userData.jiao) scene.remove(o); });
    jiaoState = { t: 0, result: result, cb: cb, blocks: [], fired: false };
    setTimeout(function () {
      if (jiaoState && !jiaoState.fired) { jiaoState.fired = true; var f = jiaoState.cb; jiaoState = null; U.jiaoAnim = false; if (f) f(); }
    }, 2400);
    jiaoGroup.visible = true;
    /* two blocks fly, land in front of the altar */
    for (var i = 0; i < 2; i++) {
      var b = makeJiaoBlock();
      b.position.set(rnd(-.2, .2), ATLAR_Y + .5, -9.2); b.userData.jiao = true;
      scene.add(b);
      jiaoState.blocks.push({ g: b, vx: rnd(-.5, .5), vy: rnd(.8, 1.4), vz: rnd(-.4, .6),
        rx: rnd(-4, 4), ry: rnd(-4, 4), rz: rnd(-4, 4), landed: false, i: i });
    }
    U.jiaoAnim = true;
  };
  function updateJiao(dt, t) {
    if (!jiaoState) return;
    jiaoState.t += dt;
    var done = true;
    jiaoState.blocks.forEach(function (b) {
      if (b.landed) return;
      b.vy -= 6.2 * dt;
      b.g.position.x += b.vx * dt; b.g.position.y += b.vy * dt; b.g.position.z += b.vz * dt;
      b.g.rotation.x += b.rx * dt; b.g.rotation.y += b.ry * dt; b.g.rotation.z += b.rz * dt;
      var floor = ATLAR_Y;
      if (b.g.position.y <= floor) {
        b.g.position.y = floor;
        b.landed = true;
        /* 立筊：第一片立起（0.1%），其餘照常落地 */
        if (jiaoState.result === "li" && b.i === 0) {
          b.g.position.y = floor + .17;
          b.g.rotation.set(Math.PI / 2, rnd(-.12, .12), Math.PI / 2);
        } else {
        /* orient: flat up or round up */
        var flatUp;
        if (b.i === 0) flatUp = (jiaoState.result !== "yin");
        else flatUp = (jiaoState.result === "xiao");
        /* 聖: one flat-one round; 笑: both flat; 陰: both round */
        var rot = flatUp ? 0 : Math.PI;
        b.g.rotation.set(rot + rnd(-.1, .1), rnd(-.3, .3), rnd(-.1, .1));
        }
        b.g.position.z = -8.9 + b.i * .22;
        b.g.position.x = rnd(-.5, .5);
      } else done = false;
    });
    if (done && jiaoState.t > 1.6) {
      U.jiaoAnim = false;
      var cb = jiaoState.cb; jiaoState.fired = true; jiaoState = null;
      if (cb) cb();
    }
  }
  MM.clearJiao = function () {
    U.scene.children.slice().forEach(function (o) {
      if (o.userData && o.userData.jiao) U.scene.remove(o);
    });
  };

  /* 兼容舊呼叫：實際插香統一由 MM.Incense 處理 */
  MM.addIncenseStick = function (name) {
    if (!MM.Incense) return 0;
    var c = name ? MM.Incense.byId({ "天公爐": "heaven", "香案爐": "front", "正殿主爐": "main" }[name] || name) : MM.Incense.nearest().censer;
    if (!c) return 0;
    MM.lastCenserName = c.name;
    return MM.Incense.offer(c.id, 1) ? c.total : 0;
  };

  /* expose build + init hook */
  MM.buildWorld = init;
  U.addWishTag = addWishTag;
  U.updateJiao = updateJiao;
  U.lampMeshes = lampMeshes;
})();
