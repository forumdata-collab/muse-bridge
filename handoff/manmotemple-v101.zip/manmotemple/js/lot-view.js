/* 籤文顯示層 · 單一規則來源
   3D 求籤彈窗（js/app.js 的 showLot）與 /fortunestick/ 全文頁都由此取同一套文字規則
   與內容：籤紙優先、解曰標點、異文判準、聖意白話、白話導讀。
   兩頁只各自決定版式（3D 直排字欄／全文頁卡片），不再各自實作規則，免得內容漂移。 */
window.LotView = (function () {
  "use strict";

  var NAME = "武帝靈簽";

  /* 異體字折疊：這些字形差異不算異文（空格、標點同樣不算） */
  var VFOLD = {'裏':'裡','爲':'為','却':'卻','簽':'籤','灾':'災','强':'強','携':'攜','着':'著','鬭':'鬥','衆':'眾','敎':'教','悞':'誤','妬':'妒','効':'效','纔':'才','佔':'占','歎':'嘆','祐':'佑','癒':'愈','閒':'閑','准':'準','儘':'盡','癡':'痴','谷':'穀','脚':'腳','沾':'霑','槪':'概','旡':'無','徧':'遍','沈':'沉','峯':'峰','羣':'群','箇':'個','跡':'迹','喫':'吃'};
  var STRIP = /[\s。，、；：,.;:!?！？]/g;
  var PUNCT = /[。，、；：！？]/;

  /* 籤號用中文數字：18→十八、28→廿八、48→四十八（只在籤紙上，UI 清單仍用阿拉伯數字） */
  function cnNum(n) {
    n = parseInt(n, 10);
    if (!n || n < 1) return "";
    var d = ["〇", "一", "二", "三", "四", "五", "六", "七", "八", "九"];
    if (n < 10) return d[n];
    if (n === 10) return "十";
    if (n < 20) return "十" + d[n - 10];
    if (n < 30) return "廿" + (n === 20 ? "" : d[n - 20]);
    if (n === 100) return "一百";
    if (n < 100) {
      var t = Math.floor(n / 10), u = n % 10;
      return d[t] + "十" + (u ? d[u] : "");
    }
    return String(n);
  }

  /* 介面文字：有 I18N 用譯文，否則用中文原文（籤紙本身永遠中文） */
  function T(k, dflt, vars) {
    var v = (window.I18N && window.I18N.t) ? window.I18N.t(k) : null;
    if (!v || v === k) v = dflt || k;
    if (vars) for (var p in vars) v = v.replace(new RegExp("\\{" + p + "\\}", "g"), vars[p]);
    return v;
  }
  var CUR = "zh-Hant";            /* 目前渲染語言；避免遞歸時用錯全域語言 */
  function isZh() { return CUR === "zh-Hant"; }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }
  function strip(t) { return String(t == null ? "" : t).replace(STRIP, ""); }
  function vfold(t) {
    var s = strip(t), o = "", i, k;
    for (i = 0; i < s.length; i++) { k = s.charAt(i); o += VFOLD[k] || k; }
    return o;
  }
  function hasPunct(s) { return PUNCT.test(String(s == null ? "" : s)); }
  function arr(a) { return Array.isArray(a) ? a : (a ? [a] : []); }
  function multi(v) {
    if (v == null) return [];
    return (Array.isArray(v) ? v : String(v).split(/\r?\n/))
      .map(function (x) { return String(x == null ? "" : x).trim(); })
      .filter(Boolean);
  }
  /* 句與句之間補「　」；上一句已帶標點就唔再加，否則會出「病患時時命蹇衰，　何須…」 */
  function joinClauses(a) {
    var out = "";
    (a || []).forEach(function (x) {
      var s = String(x == null ? "" : x).trim();
      if (!s) return;
      if (out && !/[，。、；：！？]$/.test(out)) out += "　";
      out += s;
    });
    return out;
  }

  /* 坊間通行本欄位（缺欄才 fallback 頂層） */
  function lib(l) {
    l = l || {};
    var b = l.lib || {};
    return {
      poem: b.poem || arr(l.poem),
      shengyi: b.shengyi || arr(l.shengyi),
      bixian: b.bixian || arr(l.bixian),
      jieyue: b.jieyue || l.jieyue || "",
      ancient: b.ancient || l.storyLib || l.story || ""
    };
  }

  /* 廟方籤版優先：有實物籤紙者，原文分頁一律以籤紙為準。
     解曰若籤紙與校訂本「去標點後逐字相同」，沿用校訂本標點（只加標點、不改字）。 */
  function plaqueView(L) {
    if (!L || !L.temple) return L;
    var t = L.temple, o = {}, k;
    for (k in L) if (Object.prototype.hasOwnProperty.call(L, k)) o[k] = L[k];
    if (t.poem) {
      var pl = String(t.poem).split(/\s+/).filter(Boolean);
      if (pl.length >= 4) o.poem = pl;
    }
    if (t.shengyi) {
      var sy = String(t.shengyi).split(/\s+/).filter(Boolean);
      if (sy.length >= 4) o.shengyi = sy;
    }
    if (t.bixian) {
      var bx = String(t.bixian).split(/\s+/).filter(Boolean);
      if (bx.length >= 2) o.bixian = bx;
    }
    o._jieyuePunct = false;
    o._jieyueRaw = false;
    o._jieyueAdded = false;
    if (t.jieyue) {
      if (t.jieyueP) {
        /* 籤紙原文無標點：本站按句意補（只加標點、不改字），原文另存 temple.jieyue */
        o.jieyue = t.jieyueP;
        o._jieyueAdded = true;
      } else if (strip(t.jieyue) === strip(L.jieyue)) {
        o.jieyue = L.jieyue;
        if (!hasPunct(t.jieyue) && hasPunct(L.jieyue)) o._jieyuePunct = true;
      } else {
        o.jieyue = t.jieyue;
        o._jieyueRaw = !hasPunct(t.jieyue);
      }
    }
    if (t.ancient) o.story = t.ancient;
    o.dongpo = "";            /* 東坡解只見於坊間通行本，非籤紙內容 */
    o._plaque = true;
    return o;
  }

  /* 解曰小註：講明標點從何而來，細字，不與正文爭層級 */
  function jieyueNote(P) {
    if (!P || !P._plaque) return "";
    if (P._jieyueAdded) return "<p class='lv-note'>" + esc(T("jieyueAdded", "籤紙原文無標點；標點為本站所加、不改字。")) + "</p>";
    if (P._jieyuePunct) return "<p class='lv-note'>" + esc(T("jieyuePunct", "籤紙原文無標點；本站只加標點、不改字，方便閱讀。")) + "</p>";
    if (P._jieyueRaw) return "<p class='lv-note'>" + esc(T("jieyueRaw", "籤紙原文無標點，且與坊間本用字有異，照錄。")) + "</p>";
    return "";
  }

  /* 聖意：拆成「問事類別 + 指示」，配白話短註（共用詞典，唔逐籤硬寫） */
  var SY_CAT = [
    ["功名", "學業 · 考試 · 事業"], ["名利", "名聲與財利"], ["名與利", "名聲 · 財利"], ["求名", "學業 · 考試"], ["問名", "學業 · 考試"], ["圖名", "學業 · 考試"],
    ["財帛", "金錢 · 收入"], ["財祿", "金錢 · 收入"], ["財利", "金錢 · 收入"], ["財物", "金錢 · 財物"], ["求財", "金錢 · 投資"],
    ["福祿", "福氣 · 財祿"],
    ["詞訟", "官司 · 爭執"], ["訟", "官司 · 爭執"], ["官事", "官府 · 法律"],
    ["病", "健康 · 治病"], ["婚姻", "感情 · 婚姻"], ["婚", "感情 · 婚姻"], ["行人", "等人 · 消息"], ["問行人", "等人 · 消息"], ["探行人", "等人 · 消息"],
    ["音信", "消息 · 書信"], ["問信", "消息 · 書信"], ["遠信", "消息 · 書信"], ["失物", "失物 · 尋找"],
    ["謀望", "計劃 · 目標"], ["謀事", "計劃 · 目標"], ["作事", "事情 · 行動"], ["事", "事情 · 行動"],
    ["孕", "懷孕 · 子息"], ["產", "生產"], ["家宅", "家庭 · 住所"], ["家道", "家庭 · 家運"], ["家", "家庭 · 家運"],
    ["福壽", "福氣 · 壽元"], ["壽", "壽元"], ["出", "出門 · 遠行"], ["行", "出行 · 變動"], ["財", "金錢"],
    ["墳墓", "祖先 · 陰地"], ["命", "命格 · 運勢"], ["子息", "子女 · 生育"], ["六甲", "懷孕"], ["田產", "置業 · 田產"], ["陰地", "祖先 · 陰地"]
  ];
  var SY_VERDICT = {
    "遂": "順遂可成", "豐": "豐足", "得理": "佔理，可勝", "莫抗": "不宜硬碰，宜和解", "宜和": "和解為上", "和解": "和解為上",
    "息": "宜平息", "宜息": "宜平息", "莫興": "不宜興訟", "勿鬥": "不宜爭鬥", "必勝": "有理可勝", "得勝": "可勝",
    "終凶": "久爭必傷", "不利": "不利", "反覆": "反覆難定", "多憂": "多憂累", "難明": "一時難明", "漸理": "慢慢理順",
    "即瘳": "很快痊癒", "即癒": "很快痊癒", "即安": "很快平安", "速醫": "及早醫治", "審醫": "仔細找對醫生", "改醫": "宜換醫生",
    "可醫": "可以治好", "醫治": "及早就醫", "難癒": "復原需時", "難痊": "復原需時", "拖延": "會拖一段時間", "瘥遲": "痊癒較慢",
    "漸瘳": "漸漸好轉", "漸康": "漸漸康復", "漸安": "漸漸平安", "易安": "容易平安", "無災": "無大礙", "有祟": "宜祈福化解",
    "宜禳": "宜祈福化解", "禱神": "宜祈福", "禱安": "祈福後平安", "禱愈": "祈福後痊癒", "者凶": "情況較險", "多險": "反覆要多加小心",
    "至": "會到", "回": "會回來", "歸": "會歸來", "還": "會回來", "動": "已有動靜", "近": "快有消息", "遠": "仍在遠處", "遲": "會遲",
    "阻": "有阻滯", "無": "難成", "賒": "會拖", "遣": "要主動安排",
    "合": "可成", "成": "可成", "可成": "可成", "有成": "可成", "合成": "可成", "即合": "很快成事", "良": "是好緣",
    "不合": "不合", "未合": "未合", "不成": "難成", "莫求": "不宜強求", "莫許": "不宜答應", "宜慎": "要謹慎", "宜定": "可定下來",
    "守舊": "宜守舊", "守己": "宜守本分", "保守": "宜保守", "尚可": "尚可", "可求": "可以爭取", "有望": "有希望", "難成": "難成",
    "有": "有", "平": "平穩", "輕": "偏弱", "耗": "會消耗", "散": "會散失", "空": "落空", "損": "有損失", "平常": "普普通通",
    "吉": "吉利", "大吉": "大吉", "終吉": "最終轉吉", "和吉": "和則吉", "方吉利": "做對方向才吉", "皆吉利": "各方面都吉",
    "待時": "要等時機", "待春時": "待春天", "待卯時": "待卯時", "時未通": "時運未通", "運至": "好運將至",
    "宜守": "宜守", "宜待": "宜等", "宜靜": "宜靜", "謹慎": "要謹慎", "莫貪求": "不要貪多", "勿貪": "不要貪", "莫貪": "不要貪",
    "向善": "多行善", "修德": "修德積福", "作福力": "多作福", "祈福佑": "祈福可保", "存忠信": "守住忠信",
    "為貴": "以和為貴", "百事亨": "諸事順", "百無憂": "無憂", "皆大吉": "非常好",
    "有所遇": "會遇到", "待時至": "等時機到", "終無利": "最終無利", "事無成": "難成", "事無就": "難成事",
    "貴人": "有貴人", "遇貴人": "有貴人", "遇賢人": "遇貴人", "喜慶來": "有喜事", "喜相尋": "喜事會來", "團圓": "一家團圓",
    "全": "圓滿", "貴顯": "顯達", "有分": "分內可得", "無分": "難得"
  };
  function syTone(v) {
    if (/凶|險|難|阻|無|不|散|耗|憂|損|空|遲|爭|鬥|災|祟|刑/.test(v)) return "bad";
    if (/吉|遂|成|得|安|豐|至|回|合|喜|貴|榮|亨|順|康|瘳|癒/.test(v)) return "good";
    return "";
  }
  /* 聖意白話字典：zh 原文 → 目標語言；字典未載入就回落中文 */
  function SYG(kind, zh) {
    var D = window.SHENGYI && window.SHENGYI[CUR];
    return (D && D[kind] && D[kind][zh]) || "";
  }
  function syGloss(item) {
    var cat = "", key = "", rest = String(item == null ? "" : item);
    for (var i = 0; i < SY_CAT.length; i++) {
      if (rest.indexOf(SY_CAT[i][0]) === 0) { key = SY_CAT[i][0]; cat = SY_CAT[i][1]; rest = rest.slice(key.length); break; }
    }
    var v = SY_VERDICT[rest] || "";
    var tone = syTone(rest || item);
    if (!v) v = tone === "good" ? "可以" : tone === "bad" ? "不宜強求" : (cat ? "平穩" : "原文用語 · 宜參看籤詩");
    return { cat: cat, key: key, verdict: v, rest: rest, tone: tone };
  }
  /* 聖意逐項白話：收在 <details>，預設收起，免壓過正文 */
  function glossHtml(src, L) {
    var sy = arr(src && src.shengyi);
    if (!sy.length) return "";
    var zh = isZh();
    if (!zh) {
      /* 外語用「每支籤的聖意全段意譯」，比逐字對譯準確；無譯文就整塊收起 */
      var tr = L && L.l10n && L.l10n[CUR] && L.l10n[CUR].shengyi;
      if (!tr) return "";
      return "<details class='lot-gloss-wrap'><summary>" + esc(T("glossSummary", "聖意逐項白話（本站整理）")) +
        "</summary><div class='lot-gloss'><p class='gloss-para'>" + esc(tr) + "</p></div></details>";
    }
    var rows = sy.map(function (t) {
      var g = syGloss(String(t));
      var cat = g.cat, ver = g.verdict;
      if (!zh) {
        /* 只保留真正譯得到嘅項目，唔好每行都寫「見籤詩」 */
        var GENERIC = { "可以": 1, "不宜強求": 1, "平穩": 1, "原文用語 · 宜參看籤詩": 1 };
        cat = SYG("cat", g.key);
        ver = SYG("val", g.verdict);
        if (!cat || !ver || GENERIC[g.verdict]) return "";
        return "<div class='lot-gloss-row'><b>" + esc(cat) + "</b><span>" + esc(ver) + "</span></div>";
      }
      return "<div class='lot-gloss-row'><b>" + esc(t) + "</b><span>" + esc((cat ? cat + " · " : "") + ver) + "</span></div>";
    }).join("");
    /* 外語要字典已載入才顯示，否則留空（唔好中英夾雜） */
    if (!zh && !(window.SHENGYI && window.SHENGYI[CUR])) return "";
    if (!zh && !rows) return "";
    return "<details class='lot-gloss-wrap'><summary>" + esc(T("glossSummary", "聖意逐項白話（本站整理）")) +
      "</summary><div class='lot-gloss'>" + rows + "</div></details>";
  }

  /* 籤詩直排字欄：每句一欄，第一句在最右（容器用 row-reverse）。
     唔可以用 writing-mode：Chromium 窄屏會疊字，實測過。 */
  function poemCols(src) {
    var out = "";
    arr(src).forEach(function (line) {
      var chars = Array.from(String(line).replace(/[，。、；：,.;:]/g, "")).filter(function (ch) { return !/\s/.test(ch); });
      if (!chars.length) return;
      out += "<div class='pcol'>" + chars.map(function (ch) { return "<i>" + esc(ch) + "</i>"; }).join("") + "</div>";
    });
    return out;
  }

  /* 原籤紙分頁的內文區塊（聖意／碧仙註／解曰）：黃紙紅字版式兩頁共用 */
  function sectionsHtml(src, opts) {
    opts = opts || {};
    var h = "";
    var syRaw = arr(src.shengyi).map(function (t) { return "<span>" + esc(t) + "</span>"; }).join("");
    if (syRaw) h += "<div class='lot-orig-sec'><h4>聖意</h4><div class='lot-sy'>" + syRaw + "</div></div>";
    var bx = multi(src.bixian);
    if (bx.length) {
      var half = Math.ceil(bx.length / 2);
      var rows = [bx.slice(0, half), bx.slice(half)].filter(function (a) { return a.length; });
      h += "<div class='lot-orig-sec'><h4>碧仙註</h4><div class='lot-verse'>" + rows.map(function (a) {
        return a.map(function (t) { return esc(t) + (/[，。、；：]$/.test(String(t)) ? "" : "　"); }).join("").replace(/　+$/, "");
      }).join("<br>") + "</div></div>";
    }
    var jy = multi(src.jieyue);
    if (jy.length) h += "<div class='lot-orig-sec'><h4>解曰</h4>" +
      jy.map(function (t) { return "<p class='lot-orig-p'>" + esc(t) + "</p>"; }).join("") +
      (opts.plaque ? jieyueNote(src) : "") + "</div>";
    if (src.dongpo) h += "<div class='lot-orig-sec'><h4>東坡解</h4><p class='lot-orig-p'>" + esc(src.dongpo) +
      "</p><p class='small muted'>pdways.com 原文照錄，原文無標點，未加改動。</p></div>";
    return h;
  }

  /* ---------- 原籤紙：直排垂直網格（由右至左） ----------
     所有欄共用「字格」--cell：每個字佔一格，空隙用 .gap，令全版節奏一致。
     結構：籤號欄 → 籤詩（兩欄，各兩句）→ 聖意／碧仙註／解曰（標題齊頂、內文齊起）。
     parts：字串 或 {t}/{gap}/{seal}/{title}。 */
  function vcol(parts, cls) {
  var PMAP = { "。": "p-ju", "，": "p-dou", "、": "p-dun", "；": "p-semi", "：": "p-colon" };
    function chars(str, klass) {
      return Array.from(String(str)).map(function (c) {
        if (c === "　" || c === " ") return "<i class='gap'></i>";
        if (!klass && PMAP[c]) {
          /* 全形標點：用真字（可複製），CSS 只負責把它擺到字格右上 */
          return "<i class='p " + PMAP[c] + "'>" + esc(c) + "</i>";
        }
        if (/[【】〔〕「」『』（）]/.test(c)) {
          return "<i class='br'>" + esc(c) + "</i>";   /* 直排括號：旋轉 90° */
        }
        return "<i" + (klass ? " class='" + klass + "'" : "") + ">" + esc(c) + "</i>";
      }).join("");
    }
    var html = "";
    parts.forEach(function (p) {
      if (p == null || p === "") return;
      if (typeof p === "string") { html += chars(p); return; }
      if (p.gap) html += "<i class='gap'></i>";
      else if (p.seal) html += "<span class='vseal'>" + chars(p.seal) + "</span>";
      else if (p.title) html += chars(p.title, "tt");
      else if (p.t) html += chars(p.t);
    });
    return "<div class='vcol" + (cls ? " " + cls : "") + "'>" + html + "</div>";
  }

  /* 一節＝標題（絕對定位於右欄頂）＋ 若干欄內文；內文一律由同一條線起 */
  function secHtml(kind, title, colParts) {
    return "<div class='lp-sec " + kind + "'>" +
      (title ? "<div class='lp-h'>" + vcol([{ title: title }]) + "</div>" : "") +
      "<div class='vc'>" + colParts.map(function (c) { return vcol(c); }).join("") + "</div>" +
    "</div>";
  }

  function paperHtml(L) {
    var n = parseInt(L && L.n, 10) || 1;
    var hasPlaque = !!(L && L.temple && L.temple.poem);
    var P = hasPlaque ? plaqueView(L) : (L || {});
    var grade = (L && L.grade) ? String(L.grade) : "";
    var gz = (L && L.gz) ? String(L.gz) : "";
    var story = (P && P.story) || "";

    var head =
      "<svg class='lp-roof' viewBox='0 0 100 42' preserveAspectRatio='none' aria-hidden='true'>" +
        "<path d='M0,42 L18,1 L82,1 L100,42' fill='none' stroke='#a22d22' stroke-width='1' vector-effect='non-scaling-stroke'/>" +
      "</svg>" +
      "<div class='lp-title'>" +
        Array.from(NAME).map(function (c) { return "<span>" + esc(c) + "</span>"; }).join("") +
      "</div>";

    var body = "";
    if (hasPlaque) {
      /* 右一欄：籤號 · 干支 · 等第印 ·【古人】· 典故名 */
      var idParts = [{ t: "第" + cnNum(n) + "簽" }];
      if (gz) idParts.push({ gap: 1 }, { t: gz });
      if (grade) idParts.push({ gap: 1 }, { seal: grade });
      if (story) idParts.push({ gap: 1 }, { title: "【古人】" }, { gap: 1 }, { t: story });
      body += "<div class='lp-sec lp-id'><div class='vc'>" + vcol(idParts) + "</div></div>";

      /* 籤詩：兩欄，每欄兩句七言 */
      var pl = arr(P.poem).map(function (x) { return String(x).replace(/[，。、；：]$/, ""); });
      if (pl.length >= 4) {
        body += "<div class='lp-sec lp-poem'><div class='vc'>" +
          vcol([{ t: pl[0] }, { gap: 1 }, { t: pl[1] }]) +
          vcol([{ t: pl[2] }, { gap: 1 }, { t: pl[3] }]) +
        "</div></div>";
      }

      /* 聖意：兩欄，每欄四句 */
      var sy = arr(P.shengyi);
      if (sy.length) {
        var half = Math.ceil(sy.length / 2), c1 = [], c2 = [];
        sy.slice(0, half).forEach(function (t, i) {
          if (i) { c1.push({ gap: 1 }, { gap: 1 }); }
          c1.push({ t: t });
        });
        sy.slice(half).forEach(function (t, i) {
          if (i) { c2.push({ gap: 1 }, { gap: 1 }); }
          c2.push({ t: t });
        });
        body += secHtml("lp-sy", "【聖　意】", [c1, c2]);
      }

      /* 碧仙註：兩欄，每欄兩句 */
      var bx = arr(P.bixian).map(function (x) { return String(x).replace(/[，。、；：]$/, ""); });
      if (bx.length) {
        var b1 = [], b2 = [];
        bx.slice(0, 2).forEach(function (t, i) { if (i) b1.push({ gap: 1 }); b1.push({ t: t }); });
        bx.slice(2, 4).forEach(function (t, i) { if (i) b2.push({ gap: 1 }); b2.push({ t: t }); });
        body += secHtml("lp-bx", "【碧仙註】", b2.length ? [b1, b2] : [b1]);
      }

      /* 解曰：三欄，按字數平均分欄（保留標點） */
      var jy = String(P.jieyue || "").replace(/\s+/g, "");
      if (jy) {
        var ch = Array.from(jy);
        /* 每欄最多約 24 字；字多就加欄（2–5 欄），確保唔會長到出框 */
        var cols = Math.min(5, Math.max(2, Math.ceil(ch.length / 24)));
        var per = Math.ceil(ch.length / cols), parts = [];
        for (var i = 0; i < cols; i++) {
          var seg = ch.slice(i * per, (i + 1) * per);
          if (seg.length) parts.push([{ t: seg.join("") }]);
        }
        body += secHtml("lp-jy", "【解　曰】", parts);
      }
    }

    var frame = hasPlaque
      ? "<div class='lp-body'>" + body + "</div>"
      : "<div class='lp-empty'>此籤尚未取得廟方籤紙實物對照，暫不提供「原籤紙」內容。<br>請看「坊間通行本」分頁；如與籤紙有異，以籤紙為準。</div>";

    /* 解曰小註（標點從何而來）放框內底部，細字，不佔欄位 */
    var jnote = hasPlaque ? jieyueNote(P) : "";

    /* 廟名落款已移除：避免讀者誤以為係廟方官方出品。
       免責句接在標點小註之後，同一行續寫，不另起一行。 */
    var footTxt = (jnote || "").replace(/^<p class='lv-note'>/, "").replace(/<\/p>$/, "");
    /* 拉丁語系句末要加空格，中文直接接（不隔行、不加空格） */
    footTxt += (/[.!?]$/.test(footTxt) ? " " : "") + esc(T("paperDisclaimer", "本站整理，非廟方官方出版。"));
    return "<div class='lot-paper'>" +
      "<div class='lp-main'>" + head + "<div class='lp-frame'>" + frame + "</div>" +
        "<div class='lp-foot'><p class='lv-note'>" + footTxt + "</p></div>" + "</div>" +
    "</div>";
  }

  /* 逐字差異段（LCS）：回傳 [[籤紙段, 坊間段], …]；細字校記靠它定位到字 */
  function segDiff(a, b) {
    var n = a.length, m = b.length, i, j;
    if (!n || !m) return [[a, b]];
    var dp = [];
    for (i = 0; i <= n; i++) dp.push(new Uint16Array(m + 1));
    for (i = n - 1; i >= 0; i--) {
      for (j = m - 1; j >= 0; j--) {
        dp[i][j] = a.charAt(i) === b.charAt(j) ? dp[i + 1][j + 1] + 1
          : Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
    var segs = [], si = 0, sj = 0;
    i = 0; j = 0;
    while (i < n && j < m) {
      if (a.charAt(i) === b.charAt(j)) {
        if (i > si || j > sj) segs.push([a.slice(si, i), b.slice(sj, j)]);
        i++; j++; si = i; sj = j;
      } else if (dp[i + 1][j] >= dp[i][j + 1]) i++;
      else j++;
    }
    if (si < n || sj < m) segs.push([a.slice(si, n), b.slice(sj, m)]);
    return segs;
  }

  /* 異文分級（用戶拍板 2026-11）：
     C 內容級 = 有整句／整首差異，需原文並列，計入「版本異文」統計
     B 單字級 = 一至四字之差（多屬轉錄異寫），只入「逐字校記」，不計數
     A 形近／正俗字 = 折疊後相同，完全不記                                        */
  var FIELDS = [["籤詩", "poem"], ["聖意", "shengyi"], ["碧仙註", "bixian"], ["解曰", "jieyue"]];
  var CONTENT_MIN = 5;   /* 差異段達 5 字即視為內容級 */

  function fieldDiffs(L) {
    if (!L || !L.temple || !L.temple.poem) return [];
    var T = L.temple, B = lib(L), out = [];
    FIELDS.forEach(function (f) {
      var rawT = T[f[1]], rawB = B[f[1]];
      if (!rawT || !rawB) return;
      var a = vfold(rawT), b = vfold(rawB);
      if (a === b) return;
      var segs = segDiff(a, b);
      if (!segs.length) return;
      var big = segs.some(function (x) { return Math.max(x[0].length, x[1].length) >= CONTENT_MIN; });
      out.push({ field: f[0], a: a, b: b, segs: segs, big: big });
    });
    return out;
  }
  function level(L) {
    var d = fieldDiffs(L);
    if (d.some(function (x) { return x.big; })) return "C";
    return d.length ? "B" : "";
  }

  /* 異文對照：只列內容級差異，籤紙與坊間本原文並列，不代善信取捨 */
  function variantHtml(L) {
    var d = fieldDiffs(L).filter(function (x) { return x.big; });
    if (!d.length) return "";
    var rows = d.map(function (x) {
      return "<div class='lot-var-row'><h5>" + esc(x.field) + "</h5>" +
        "<p><b>籤紙</b>　" + esc(x.a) + "</p>" +
        "<p><b>坊間本</b>　" + esc(x.b) + "</p></div>";
    }).join("");
    return "<details class='lot-var'><summary>" + esc(T("variantSum", "異文對照 · 籤紙／坊間本原文（點開並列）")) + "</summary>" +
      rows +
      "<p class='lv-note'>" + esc(T("variantNote", "兩版原文並列，本站不代取捨；問事以籤紙為準，文義可兩讀。")) + "</p></details>";
  }

  /* 逐字校記：單字級差異（含內容級籤的其他小差），細字收起，不計入異文 */
  function collationHtml(L) {
    var d = fieldDiffs(L);
    if (!d.length) return "";
    var rows = "";
    d.forEach(function (x) {
      x.segs.forEach(function (sg) {
        var a = sg[0] || "（無）", b = sg[1] || "（無）";
        rows += "<div class='lot-gloss-row'><b>" + esc(x.field) + "</b><span>籤紙「" + esc(a) +
          "」· 坊間「" + esc(b) + "」" + (Math.max(sg[0].length, sg[1].length) >= CONTENT_MIN ? " · 見上方並列" : "") + "</span></div>";
      });
    });
    var n = d.length;
    return "<details class='lot-var lot-collation'><summary>" +
      esc(T("collationSum", "逐字校記 · {n} 欄有字差（不計作異文）", { n: n })) + "</summary>" +
      "<div class='lot-gloss'>" + rows + "</div>" +
      "<p class='lv-note'>" + esc(T("collationNote", "只記字形與轉錄差異，不作版本判定；「版本異文」僅指內容級差異。籤紙為正本。")) + "</p></details>";
  }

  function isAmb(l) { return level(l) === "C"; }

  /* L.reading = { summary, explanation, action }（本站原創，非籤紙原文） */
  function reading(L) {
    var r = L && L.reading, out = { summary: "", explanation: [], action: "" };
    if (!r || typeof r !== "object") return out;
    if (r.summary) out.summary = String(r.summary);
    out.explanation = multi(r.explanation);
    out.action = Array.isArray(r.action) ? multi(r.action).join(" ") : (r.action ? String(r.action) : "");
    return out;
  }

  var NOTICE = "<div class='lot-notice'><b>請留意</b><p>籤文屬傳統民俗文化，不是醫療診斷、投資建議或法律意見。" +
    "身體不適請及早求醫；錢財、官司等決定請諮詢相關專業人士，切勿因籤文延誤診治或作重大決定。</p></div>";

  /* 白話導讀正文：兩頁逐字相同。3D 與全文頁都直接輸出這段 HTML。 */
  function readingHtml(L, lang) {
    CUR = lang || (window.I18N && window.I18N.lang) || "zh-Hant";
    var n = parseInt(L && L.n, 10) || 1;
    var P = (L && L.temple) ? plaqueView(L) : (L || {});
    var TR = (L && L.l10n && lang && L.l10n[lang]) || null;   /* 譯本；缺者回退中文 */
    var rd = TR ? { summary: TR.summary || "", explanation: multi(TR.explanation), action: TR.action || "" } : reading(L);
    /* 有譯本但未譯典故時，寧願唔出，都唔好中英夾雜 */
    var tale = TR
      ? (TR.tale ? { tale: TR.tale, moral: TR.moral || "", taleFor: "" } : null)
      : (window.LOT_STORIES || {})[n];
    var taleName = (tale && tale.taleFor) ? tale.taleFor : (P.story || "");
    var plaqueName = (L && L.temple && L.temple.ancient) || P.story || "";
    var h = "";
    /* 外語版未翻譯者：出「準備中」卡，唔好把中文導讀當譯文倒出嚟 */
    if (!isZh() && !TR) {
      return "<div class='lot-pending'><h3 class='lot-read-h'>" + esc(T("trPendingH", "此籤的譯文仍在準備中")) + "</h3>" +
        "<p>" + esc(T("trPendingP", "原文請看「原籤紙」分頁。")) + "</p>" +
        "<details class='lot-zh-src'><summary>" + esc(T("trPendingShow", "看中文導讀（未翻譯）")) + "</summary>" +
        readingHtml(L, "zh-Hant") + "</details></div>";
    }
    /* 籤詩譯意（只譯意，不譯成格律詩；原文仍在「原籤紙」分頁） */
    if (TR && TR.poem) {
      var gh = (window.I18N && window.I18N.t("poemGlossHead")) || "籤詩譯意（非原文）";
      h += "<div class='lot-poemgloss'><h4>" + esc(gh) + "</h4><p>" + esc(TR.poem) + "</p></div>";
    }
    if (rd.summary) h += "<h3 class='lot-read-h'>" + esc(rd.summary) + "</h3>";
    if (tale && tale.tale) {
      var taleTitle = (TR && TR.name) ? TR.name : taleName;   /* 外語用譯名，中文用籤紙古人 */
      h += "<div class='lot-tale'><h4>" + esc(T("taleHead", "典故")) + " · " + esc(taleTitle) + "</h4><p>" + esc(tale.tale) + "</p>";
      if (tale.taleFor && plaqueName && tale.taleFor !== plaqueName) {
        h += "<p class='lv-note'>此段說坊間通行本「" + esc(tale.taleFor) + "」的故事；籤紙古人作「" + esc(plaqueName) + "」。</p>";
      }
      h += "</div>";
    }
    if (rd.explanation.length) {
      h += rd.explanation.map(function (t) { return "<p>" + esc(t) + "</p>"; }).join("");
    }
    if (tale && tale.moral) h += "<div class='lot-moral'><b>" + esc(T("moralHead", "寓意")) + "</b><p>" + esc(tale.moral) + "</p></div>";
    if (rd.action) h += "<div class='lot-do'><b>" + esc(T("actionHead", "今日一個小行動")) + "</b><p>" + esc(rd.action) + "</p></div>";
    if (!rd.summary && !rd.explanation.length) {
      h = "<h3 class='lot-read-h'>" + esc(T("readFallbackH", "籤意怎樣讀？")) + "</h3><p>" +
        esc(T("readFallbackP", "此籤暫未附本站原創導讀，以下先按傳統聖意逐項列出白話提示，方便與原籤紙對照。")) + "</p>" + h;
    }
    h += glossHtml(P, L);
    if (TR && TR.notice) h += "<div class='lot-notice'><b>" + esc(T("noticeHead", "請留意")) + "</b><p>" + esc(TR.notice) + "</p></div>";
    else h += NOTICE;
    return h;
  }

  return {
    NAME: NAME,
    VFOLD: VFOLD,
    esc: esc, strip: strip, vfold: vfold, arr: arr, multi: multi,
    joinClauses: joinClauses, hasPunct: hasPunct, poemCols: poemCols,
    plaqueView: plaqueView, jieyueNote: jieyueNote,
    sectionsHtml: sectionsHtml, paperHtml: paperHtml, cnNum: cnNum,
    syGloss: syGloss, glossHtml: glossHtml,
    variantHtml: variantHtml, collationHtml: collationHtml,
    level: level, fieldDiffs: fieldDiffs, isAmb: isAmb,
    lib: lib, reading: reading, readingHtml: readingHtml
  };
})();
