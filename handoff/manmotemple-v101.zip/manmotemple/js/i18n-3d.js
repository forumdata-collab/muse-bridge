/* 3D 場景翻譯層（DOM + Canvas）
 * - DOM：文字節點／屬性／<title> 按字典替換，MutationObserver 追動態節點
 * - Canvas：patch fillText / strokeText / measureText，令貼圖與 HUD 文字一併翻譯
 * - 入口：?lang=en|ja|th；未收錄字串保持中文
 * - 需先載入 locales/ui3d.js（window.UI3D）；見 index.html 的 head 掛載
 */
(function () {
  var m = String(location.search).match(/[?&]lang=(en|ja|th)\b/);
  var lang = m ? m[1] : "";
  if (!lang) return;

  var DICT = (window.UI3D && window.UI3D[lang]) || {};
  var HTML_LANG = { en: "en", ja: "ja", th: "th" };

  /* 帶數字的樣式字串 */
  var RULES = {
    en: [
      [/^第\s*(\d+)\s*[籤签]$/, "Lot $1"],
      [/^參拜指引\s*(\d+)\s*\/\s*(\d+)$/, "Guide $1/$2"],
      [/^一百籤\s*·\s*第\s*(\d+)\s*籤$/, "100 lots · lot $1"]
    ],
    ja: [
      [/^第\s*(\d+)\s*[籤签]$/, "第$1籤"],
      [/^參拜指引\s*(\d+)\s*\/\s*(\d+)$/, "参拝ガイド $1/$2"],
      [/^一百籤\s*·\s*第\s*(\d+)\s*籤$/, "百籤 · 第$1籤"]
    ],
    th: [
      [/^第\s*(\d+)\s*[籤签]$/, "ใบที่ $1"],
      [/^參拜指引\s*(\d+)\s*\/\s*(\d+)$/, "คำแนะนำ $1/$2"],
      [/^一百籤\s*·\s*第\s*(\d+)\s*籤$/, "100 ใบ · ใบที่ $1"]
    ]
  };

  var CACHE = Object.create(null);
  function lookup(s) {
    if (!s) return null;
    var key = String(s).trim();
    if (!key || key.length < 2 || !/[\u3400-\u9fff]/.test(key)) return null;   /* 單字不翻：多為對聯／印章的一部分 */
    var c = CACHE[key];
    if (c !== undefined) return c;
    var hit = Object.prototype.hasOwnProperty.call(DICT, key) ? DICT[key] : null;
    if (!hit) {
      var R = window.RITUAL_I18N && window.RITUAL_I18N[lang];
      if (R && Object.prototype.hasOwnProperty.call(R, key) && key.indexOf("{") < 0) hit = R[key];
    }
    if (!hit) {
      var rs = RULES[lang] || [];
      for (var i = 0; i < rs.length; i++) {
        if (rs[i][0].test(key)) { hit = key.replace(rs[i][0], rs[i][1]); break; }
      }
    }
    CACHE[key] = hit;
    return hit;
  }

  /* ---------- Canvas ---------- */
  /* 未啟用：見下方呼叫處的說明。保留以備日後只翻 HUD 時使用。 */
  function patchCanvas() {
    var P = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
    if (!P || P.__t3d) return;
    P.__t3d = 1;
    var ft = P.fillText, st = P.strokeText, mt = P.measureText;
    function tr(v) { var h = lookup(v); return h == null ? v : h; }
    /* 譯文字通常比中文長：先量原本寬度，超出就縮字級遷就，避免壓到下一行 */
    function fit(ctx, orig, trans) {
      if (orig === trans) return null;
      var w0 = mt.call(ctx, orig).width, w1 = mt.call(ctx, trans).width;
      if (!w0 || w1 <= w0 * 1.02) return null;
      var m = String(ctx.font).match(/([\d.]+)px/);
      if (!m) return null;
      var size = parseFloat(m[1]), scaled = Math.max(size * 0.72, size * (w0 / w1));
      if (scaled >= size - 0.5) return null;
      return { font: String(ctx.font).replace(/([\d.]+)px/, scaled.toFixed(1) + "px"), save: String(ctx.font) };
    }
    function draw(fn, ctx, orig, x, y, w) {
      var trans = tr(orig);
      var f = fit(ctx, String(orig), String(trans));
      if (!f) return w == null ? fn.call(ctx, trans, x, y) : fn.call(ctx, trans, x, y, w);
      ctx.font = f.font;
      try { return w == null ? fn.call(ctx, trans, x, y) : fn.call(ctx, trans, x, y, w); }
      finally { ctx.font = f.save; }
    }
    P.fillText = function (t, x, y, w) { return draw(ft, this, t, x, y, w); };
    P.strokeText = function (t, x, y, w) { return draw(st, this, t, x, y, w); };
    P.measureText = function (t) { return mt.call(this, tr(t)); };
  }

  /* textContent / innerText 寫入時即時翻譯（app 會不停重設 caption，靠 observer 會滯後） */
  function hookTextProps() {
    ["textContent", "innerText"].forEach(function (prop) {
      var d = Object.getOwnPropertyDescriptor(Node.prototype, prop);
      if (!d || !d.set || d.set.__t3d) return;
      var set = d.set;
      var wrapped = function (v) {
        if (typeof v === "string") { var h = lookup(v); if (h) v = h; }
        return set.call(this, v);
      };
      wrapped.__t3d = 1;
      Object.defineProperty(Node.prototype, prop, { get: d.get, set: wrapped, configurable: true, enumerable: d.enumerable });
    });
  }

  /* ---------- DOM ---------- */
  var ATTRS = ["placeholder", "title", "aria-label", "alt", "data-tip"];
  function trText(node) {
    var raw = node.nodeValue;
    if (!raw) return;
    /* 黃紙底的原籤文（.lot-paper）永不翻譯 */
    var host = node.parentElement;
    if (host && host.closest && host.closest(".lot-paper")) return;
    var t = raw.trim();
    /* 單字節點若屬合成標籤（圖示＋文字），唔翻，免得變成「拝参拝」 */
    var pe = node.parentElement;
    if (pe && /(^|\s)(stamp|icon|glyph|ico)(\s|$)/.test(pe.className || "")) return;  /* 印章字係裝飾 */
    if (t.length === 1 && pe && pe.childNodes.length > 1) return;
    var hit = lookup(t);
    if (hit && hit !== t) node.nodeValue = raw.replace(t, hit);
  }
  function trAttrs(el) {
    if (!el.getAttribute) return;
    for (var i = 0; i < ATTRS.length; i++) {
      var v = el.getAttribute(ATTRS[i]);
      if (!v) continue;
      var hit = lookup(v);
      if (hit) el.setAttribute(ATTRS[i], hit);
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) return trText(root);
    if (root.nodeType !== 1 && root.nodeType !== 11) return;
    trAttrs(root);
    var tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, null), n;
    while ((n = tw.nextNode())) {
      if (n.nodeType === 3) trText(n); else trAttrs(n);
    }
  }

  function boot() {
    document.documentElement.lang = HTML_LANG[lang];
    walk(document.body);
    var dt = (document.title || "").trim(), dh = lookup(dt);
    if (dh) document.title = dh;
    /* 每種語言自我 canonical，配合 head 的 hreflang */
    var can = document.querySelector('link[rel="canonical"]');
    if (can) {
      var u = new URL(can.getAttribute("href"), location.href);
      u.search = "?lang=" + lang;
      can.setAttribute("href", u.toString());
    }
    var md = document.querySelector('meta[name="description"]');
    if (md) { var dv = (md.getAttribute("content") || "").trim(), d2 = lookup(dv); if (d2) md.setAttribute("content", d2); }

    var q = [], pending = false;
    new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var mu = muts[i];
        if (mu.type === "characterData") q.push(mu.target);
        else for (var j = 0; j < mu.addedNodes.length; j++) q.push(mu.addedNodes[j]);
      }
      if (pending || !q.length) return;
      pending = true;
      requestAnimationFrame(function () {
        var list = q; q = []; pending = false;
        for (var k = 0; k < list.length; k++) walk(list[k]);
      });
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  /* 場景貼圖（對聯、匾額、紅布、燈籠）一律保留繁中原文 —— 屬廟宇實物，唔翻譯。
     Canvas 文字因此唔接管；只翻 DOM 介面（按鈕、步驟、toast、熱點標籤）。 */
  hookTextProps();
  /* 盡早掛 observer（documentElement），否則 body 出現前寫入的文字會漏翻 */
  if (document.readyState === "loading") boot(); else boot();
})();
