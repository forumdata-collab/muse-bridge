/* 文武廟 · 殿前聖物：文昌筆 · 關帝刀
   參拜後可上前摸聖物，沾智慧與運氣。
   細節：雕漆雲龍筆桿、多層筆鋒、筆斗、端硯、卷軸、鑄銅吞口龍首、階鉤刀背、
   削角刀尖、陰刻蟠龍、魚鱗紋銅桿、紅纓 */
(function () {
  "use strict";
  var T = window.THREE, MM = window.MM, U = MM._;
  var scene, box, cyl, mesh, mat, gold, rnd;
  var brush, blade, glowB, glowK, animB = 0, animK = 0;
  var X = {};                                   /* 聖物專用程序化貼圖 */

  function init() {
    scene = U.scene; box = U.box; cyl = U.cyl; mesh = U.mesh;
    mat = U.mat; gold = U.gold; rnd = U.rnd;
    buildTextures();
    buildBrush();
    buildBlade();
    U.addStation("brush", "文昌筆 · 摸聖物", 3.2, -4.4, Math.PI, 2.0);
    U.addStation("blade", "關帝刀 · 摸聖物", -3.2, -4.4, Math.PI, 2.0);
  }

  function pedestal(x, z, ry) {
    var g = new T.Group(); g.position.set(x, 0, z); g.rotation.y = ry || 0; g.userData.dynamic = true; scene.add(g);
    var carvedM = new T.MeshStandardMaterial({ map: U.TEX.carved, roughness: .55, metalness: .15 });
    box(1.05, .14, .8, mat("#3f0d08"), 0, .07, 0, g);
    box(1.12, .05, .86, gold(), 0, .16, 0, g);
    box(.9, .1, .68, carvedM, 0, .24, 0, g);
    (U.obstacles = U.obstacles || []).push({ x: x, z: z, r: .85 });
    return g;
  }

  /* ---------------- 小工具 ---------------- */
  function lathe(pts, seg, m, x, y, z, p) {
    var v = [], i;
    for (i = 0; i < pts.length; i++) v.push(new T.Vector2(pts[i][0], pts[i][1]));
    return mesh(new T.LatheGeometry(v, seg || 22), m, x, y, z, p);
  }
  function band(r, tube, m, y, p, seg) {
    var o = mesh(new T.TorusGeometry(r, tube, 7, seg || 26), m, 0, y, 0, p);
    o.rotation.x = Math.PI / 2;
    return o;
  }
  /* 一束絲線：geometry 已把底端移到原點、沿 +Y，dir 為絲線方向 */
  function strandBundle(parent, n, geo, m, base, spread, len, dirFn) {
    var im = new T.InstancedMesh(geo, m, n);
    var d = new T.Object3D(), up = new T.Vector3(0, 1, 0), dir = new T.Vector3();
    for (var i = 0; i < n; i++) {
      var a = i / n * Math.PI * 2 + (i % 2 ? .16 : 0);
      var rr = spread * (.42 + .58 * ((i * 7) % 11) / 11);
      dirFn(dir, a, rr, i);
      d.position.set(base[0] + Math.cos(a) * rr, base[1], base[2] + Math.sin(a) * rr);
      d.quaternion.setFromUnitVectors(up, dir);
      d.scale.set(1, len(i), 1);
      d.updateMatrix(); im.setMatrixAt(i, d.matrix);
    }
    im.instanceMatrix.needsUpdate = true; im.frustumCulled = false;
    parent.add(im); return im;
  }

  /* ---------------- 貼圖 ---------------- */
  function drawCloud(x, cx, cy, s, col) {
    x.strokeStyle = col; x.lineWidth = Math.max(2, s * .1); x.lineCap = "round";
    x.beginPath(); x.arc(cx, cy, s, Math.PI * .12, Math.PI * 1.62); x.stroke();
    x.beginPath(); x.arc(cx + s * .66, cy - s * .06, s * .58, Math.PI * .95, Math.PI * 2.15); x.stroke();
    x.beginPath();
    x.moveTo(cx - s * 1.35, cy + s * .52);
    x.quadraticCurveTo(cx, cy + s * 1.02, cx + s * 1.4, cy + s * .38);
    x.stroke();
  }
  function drawDragon(x, cx, cy, s, col) {
    x.save(); x.translate(cx, cy); x.strokeStyle = col; x.fillStyle = col; x.lineCap = "round"; x.lineJoin = "round";
    /* 龍身：粗壯 S 形 */
    x.lineWidth = s * .15;
    x.beginPath(); x.moveTo(-s * 1.02, s * .48);
    x.bezierCurveTo(-s * .38, s * .6, -s * .58, -s * .14, -s * .16, -s * .3);
    x.bezierCurveTo(s * .26, -s * .46, s * .3, s * .1, s * .66, 0);
    x.stroke();
    /* 頭 */
    x.beginPath(); x.ellipse(s * .8, -s * .02, s * .3, s * .19, -.2, 0, 6.284); x.fill();
    /* 吻 + 下頜 */
    x.beginPath(); x.moveTo(s * 1.02, -s * .09); x.lineTo(s * 1.2, -s * .02); x.lineTo(s * 1.0, s * .08); x.closePath(); x.fill();
    /* 角 */
    x.lineWidth = s * .075;
    x.beginPath(); x.moveTo(s * .7, -s * .14); x.quadraticCurveTo(s * .62, -s * .44, s * .86, -s * .5); x.stroke();
    x.beginPath(); x.moveTo(s * .56, -s * .14); x.quadraticCurveTo(s * .46, -s * .4, s * .6, -s * .52); x.stroke();
    /* 鬚 */
    x.lineWidth = s * .04;
    x.beginPath(); x.moveTo(s * 1.04, s * .06); x.quadraticCurveTo(s * 1.28, s * .18, s * 1.2, s * .4); x.stroke();
    x.beginPath(); x.moveTo(s * 1.0, s * .12); x.quadraticCurveTo(s * 1.14, s * .32, s * 1.04, s * .46); x.stroke();
    /* 眼（挖空） */
    x.globalCompositeOperation = "destination-out";
    x.beginPath(); x.arc(s * .86, -s * .04, s * .045, 0, 6.284); x.fill();
    x.globalCompositeOperation = "source-over";
    /* 鱗 */
    x.lineWidth = s * .035;
    for (var i = 0; i < 9; i++) {
      var t = -0.9 + i * 0.17;
      x.beginPath(); x.arc(t * s, Math.sin(t * 3.0) * s * .22 + s * .1, s * .062, Math.PI * .1, Math.PI * 1.15); x.stroke();
    }
    /* 爪 */
    x.lineWidth = s * .05;
    x.beginPath(); x.moveTo(-s * .04, s * .34); x.lineTo(-s * .2, s * .58); x.lineTo(0, s * .52); x.stroke();
    x.beginPath(); x.moveTo(s * .3, s * .3); x.lineTo(s * .22, s * .56); x.lineTo(s * .44, s * .48); x.stroke();
    x.restore();
  }

  /* 陰刻龍紋：細線蟠龍（雙鉤線 + 鱗 + 鬃 + 爪），用於刀身下段 */
  function drawDragonFine(x, cx, cy, s, ink, bw) {
    bw = bw || 1;
    x.save(); x.translate(cx, cy);
    x.strokeStyle = ink; x.fillStyle = ink; x.lineCap = "round"; x.lineJoin = "round";

    function body() {
      x.beginPath();
      x.moveTo(-s * 1.02, s * .32);
      x.bezierCurveTo(-s * .54, s * .54, -s * .90, s * .02, -s * .36, -s * .20);
      x.bezierCurveTo(s * .08, -s * .38, s * .02, s * .16, s * .40, s * .07);
      x.bezierCurveTo(s * .58, s * .01, s * .62, -s * .12, s * .74, -s * .05);
    }
    /* 蟠軀雙鉤線 */
    x.lineWidth = s * .175 * bw; body(); x.stroke();
    x.globalCompositeOperation = "destination-out"; x.lineWidth = s * .108 * bw; body(); x.stroke();
    x.globalCompositeOperation = "source-over";

    /* 體鱗：沿軀幹細弧，填出鱗片層次 */
    function bz(p0, p1, p2, p3, t) {
      var u = 1 - t;
      return [u * u * u * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t * t * t * p3[0],
              u * u * u * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t * t * t * p3[1]];
    }
    var segs = [[[-1.02, .32], [-.54, .54], [-.90, .02], [-.36, -.20]],
                [[-.36, -.20], [.08, -.38], [.02, .16], [.40, .07]],
                [[.40, .07], [.58, .01], [.62, -.12], [.74, -.05]]];
    x.lineWidth = s * .016 * bw;
    for (var gi = 0; gi < 3; gi++) {
      var S = segs[gi];
      for (var k = 1; k <= 6; k++) {
        var tq = k / 7;
        var pp = bz([S[0][0] * s, S[0][1] * s], [S[1][0] * s, S[1][1] * s],
                    [S[2][0] * s, S[2][1] * s], [S[3][0] * s, S[3][1] * s], tq);
        x.beginPath(); x.arc(pp[0], pp[1], s * .034, Math.PI * 1.04, Math.PI * 1.96); x.stroke();
      }
    }

    /* 背鰭：沿身細刺 */
    x.lineWidth = s * .022 * bw;
    for (var i = 0; i < 11; i++) {
      var t = .06 + i * .083;
      var px = -s * 1.0 + t * s * 1.7;
      var py = Math.sin(t * 4.4 - .6) * s * .16 + s * .05;
      x.beginPath(); x.moveTo(px, py - s * .03); x.lineTo(px - s * .03, py - s * .13); x.stroke();
    }

    /* 頭：側視（吻、下頜、腮） */
    x.lineWidth = s * .05 * bw;
    x.beginPath();
    x.moveTo(s * .70, -s * .05);
    x.bezierCurveTo(s * .86, -s * .14, s * 1.0, -s * .10, s * 1.06, -s * .01);
    x.bezierCurveTo(s * 1.10, s * .05, s * 1.06, s * .10, s * .98, s * .10);
    x.stroke();
    x.beginPath();
    x.moveTo(s * .78, s * .08);
    x.lineTo(s * 1.02, s * .03);
    x.lineTo(s * .80, s * .16);
    x.stroke();
    /* 上頜鬚 */
    x.lineWidth = s * .022 * bw;
    x.beginPath(); x.moveTo(s * 1.06, s * .02); x.bezierCurveTo(s * 1.24, s * .10, s * 1.22, s * .30, s * 1.10, s * .42); x.stroke();
    x.beginPath(); x.moveTo(s * 1.0, s * .12); x.bezierCurveTo(s * 1.14, s * .24, s * 1.10, s * .40, s * 1.00, s * .50); x.stroke();
    /* 角 */
    x.lineWidth = s * .034 * bw;
    x.beginPath(); x.moveTo(s * .80, -s * .10); x.bezierCurveTo(s * .74, -s * .34, s * .86, -s * .44, s * 1.0, -s * .44); x.stroke();
    x.beginPath(); x.moveTo(s * .70, -s * .10); x.bezierCurveTo(s * .62, -s * .30, s * .70, -s * .42, s * .82, -s * .46); x.stroke();
    /* 眼 */
    x.globalCompositeOperation = "destination-out";
    x.beginPath(); x.arc(s * .90, -s * .01, s * .036, 0, 6.283); x.fill();
    x.globalCompositeOperation = "source-over";

    /* 爪：兩肢，各三趾 */
    x.lineWidth = s * .028 * bw;
    [[-s * .30, s * .10], [s * .16, s * .04]].forEach(function (p) {
      x.beginPath(); x.moveTo(p[0], p[1]); x.bezierCurveTo(p[0] - s * .06, p[1] + s * .16, p[0] - s * .02, p[1] + s * .26, p[0] + s * .06, p[1] + s * .32); x.stroke();
      for (var k = -1; k < 2; k++) {
        x.beginPath();
        x.moveTo(p[0] + s * .06, p[1] + s * .30);
        x.lineTo(p[0] + s * .06 + k * s * .05, p[1] + s * .42 - Math.abs(k) * s * .03);
        x.stroke();
      }
    });
    x.restore();
  }

  function buildTextures() {
    /* 筆桿：雕漆雲龍 */
    X.handle = U.cvs(512, 1024, function (x, w, h) {
      var lg = x.createLinearGradient(0, 0, w, 0);
      lg.addColorStop(0, "#3a1106"); lg.addColorStop(.3, "#7e3316");
      lg.addColorStop(.58, "#65230c"); lg.addColorStop(1, "#330e05");
      x.fillStyle = lg; x.fillRect(0, 0, w, h);
      x.lineWidth = 1; x.strokeStyle = "rgba(24,7,2,.34)";
      for (var i = 0; i < 130; i++) {
        var x0 = rnd(0, w), y0 = rnd(-60, h);
        x.beginPath(); x.moveTo(x0, y0);
        x.bezierCurveTo(x0 + rnd(-9, 9), y0 + 70, x0 + rnd(-9, 9), y0 + 150, x0 + rnd(-5, 5), y0 + 220);
        x.stroke();
      }
      x.strokeStyle = "rgba(212,168,94,.5)"; x.lineWidth = 3;
      for (var s = 0; s <= 4; s++) { x.beginPath(); x.moveTo(0, s * h / 4); x.lineTo(w, s * h / 4); x.stroke(); }
      drawCloud(x, 86, 128, 44, "rgba(232,192,112,.78)");
      drawCloud(x, 412, 300, 50, "rgba(232,192,112,.7)");
      drawCloud(x, 110, 848, 40, "rgba(232,192,112,.7)");
      drawDragon(x, 250, 640, 116, "rgba(240,206,136,.86)");
      drawDragon(x, 250, 150, 74, "rgba(240,206,136,.5)");
      /* 漆面高光 */
      x.fillStyle = "rgba(255,226,180,.10)"; x.fillRect(w * .17, 0, w * .07, h);
    });
    X.handle.wrapS = X.handle.wrapT = T.RepeatWrapping; X.handle.repeat.set(2, 2);

    /* 金箍：回紋 */
    X.fret = U.cvs(256, 64, function (x, w, h) {
      x.fillStyle = "#b8944a"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "#f2dc9f"; x.lineWidth = 4; x.lineJoin = "miter";
      for (var i = 0; i < 4; i++) {
        var o = i * 64;
        x.beginPath();
        x.moveTo(o + 10, h - 12); x.lineTo(o + 10, 20); x.lineTo(o + 40, 20);
        x.lineTo(o + 40, h - 24); x.lineTo(o + 24, h - 24); x.lineTo(o + 24, 34);
        x.stroke();
      }
      x.strokeStyle = "rgba(92,62,20,.65)"; x.lineWidth = 2;
      x.beginPath(); x.moveTo(0, 4); x.lineTo(w, 4); x.moveTo(0, h - 4); x.lineTo(w, h - 4); x.stroke();
    });
    X.fret.wrapS = X.fret.wrapT = T.RepeatWrapping; X.fret.repeat.set(3, 1);

    /* 握把：銅胎魚鱗／水波疊弧（參考文物之堆疊鱗紋） */
    X.scale = U.cvs(256, 256, function (x, w, h) {
      var lg = x.createLinearGradient(0, 0, w, 0);
      lg.addColorStop(0, "#5d431f"); lg.addColorStop(.30, "#c9a768");
      lg.addColorStop(.55, "#a9853f"); lg.addColorStop(.78, "#d9bc82"); lg.addColorStop(1, "#57401c");
      x.fillStyle = lg; x.fillRect(0, 0, w, h);
      var r = 17, dh = 13, row, col, ox, oy, cx2;
      for (row = -1; row < h / dh + 2; row++) {
        oy = row * dh; ox = (row % 2) ? r : 0;
        for (col = -1; col < w / (r * 2) + 2; col++) {
          cx2 = col * r * 2 + ox;
          /* 暗溝 */
          x.strokeStyle = "rgba(52,32,8,.62)"; x.lineWidth = 2.4;
          x.beginPath(); x.arc(cx2, oy, r, Math.PI, Math.PI * 2); x.stroke();
          /* 受光脊 */
          x.strokeStyle = "rgba(255,232,178,.46)"; x.lineWidth = 1.4;
          x.beginPath(); x.arc(cx2, oy - 1.6, r - 1.6, Math.PI * 1.06, Math.PI * 1.94); x.stroke();
        }
        /* 每列細分隔線 */
        x.strokeStyle = "rgba(48,30,8,.30)"; x.lineWidth = 1;
        x.beginPath(); x.moveTo(0, oy + dh * .5); x.lineTo(w, oy + dh * .5); x.stroke();
      }
    });
    X.scale.wrapS = X.scale.wrapT = T.RepeatWrapping; X.scale.repeat.set(3, 7);

    /* 鑄銅：縱向披鱗刻線 + 凹處積影（護手、龍首用） */
    X.brass = U.cvs(256, 256, function (x, w, h) {
      var lg = x.createLinearGradient(0, 0, w, h);
      lg.addColorStop(0, "#8a6a30"); lg.addColorStop(.42, "#d6b878");
      lg.addColorStop(.7, "#b08d4c"); lg.addColorStop(1, "#755726");
      x.fillStyle = lg; x.fillRect(0, 0, w, h);
      var i, px;
      for (i = 0; i < 230; i++) {
        px = Math.random() * w;
        x.strokeStyle = Math.random() > .5 ? "rgba(255,238,196,.15)" : "rgba(56,36,10,.20)";
        x.lineWidth = .6 + Math.random() * 1.5;
        x.beginPath(); x.moveTo(px, 0); x.lineTo(px + rnd(-7, 7), h); x.stroke();
      }
      for (i = 0; i < 110; i++) {
        x.fillStyle = "rgba(44,26,6," + rnd(.08, .28).toFixed(2) + ")";
        x.beginPath();
        x.ellipse(Math.random() * w, Math.random() * h, rnd(1, 4.2), rnd(1, 2.8), rnd(0, 3), 0, 6.283);
        x.fill();
      }
      /* 銅綠薄斑 */
      for (i = 0; i < 26; i++) {
        x.fillStyle = "rgba(86,112,86," + rnd(.04, .10).toFixed(2) + ")";
        x.beginPath(); x.arc(Math.random() * w, Math.random() * h, rnd(4, 14), 0, 6.283); x.fill();
      }
    });

    /* 刀身：冷灰銀、斑駁水磨光（非鏡面鉻） */
    X.mottle = U.cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#7d8892"; x.fillRect(0, 0, w, h);
      var i, cx2, cy2, rr, g2;
      for (i = 0; i < 110; i++) {
        cx2 = Math.random() * w; cy2 = Math.random() * h; rr = rnd(18, 96);
        g2 = x.createRadialGradient(cx2, cy2, 0, cx2, cy2, rr);
        if (Math.random() > .45) {
          g2.addColorStop(0, "rgba(38,48,56,.34)"); g2.addColorStop(1, "rgba(38,48,56,0)");
        } else {
          g2.addColorStop(0, "rgba(206,218,226,.30)"); g2.addColorStop(1, "rgba(206,218,226,0)");
        }
        x.fillStyle = g2; x.beginPath(); x.arc(cx2, cy2, rr, 0, 6.283); x.fill();
      }
      /* 沿刃身的水磨細痕 */
      for (i = 0; i < 300; i++) {
        var y0 = Math.random() * h;
        x.strokeStyle = "rgba(" + (Math.random() > .5 ? "214,224,230," : "56,66,74,") + rnd(.04, .12).toFixed(2) + ")";
        x.lineWidth = rnd(.5, 1.8);
        x.beginPath(); x.moveTo(0, y0); x.lineTo(w, y0 + rnd(-4, 4)); x.stroke();
      }
    });
    X.mottle.wrapS = X.mottle.wrapT = T.RepeatWrapping; X.mottle.repeat.set(2.4, .76);

    /* 刀身陰刻：飛龍（沿刀身中軸垂直貫通，龍首在上段、軀幹盤旋而下），深褐細線 */
    X.engrave = U.cvs(448, 1400, function (x, w, h) {
      x.clearRect(0, 0, w, h);
      var ink = "rgba(16,12,9,.98)";
      var ink2 = "rgba(30,23,17,.88)";
      var ink3 = "rgba(48,36,26,.46)";
      /* 雲氣（先落底，龍壓其上） */
      drawCloud(x, 86, 1176, 52, ink3);
      drawCloud(x, 332, 1082, 44, ink3);
      drawCloud(x, 104, 300, 42, "rgba(58,44,32,.28)");
      drawCloud(x, 352, 392, 38, "rgba(58,44,32,.24)");
      /* 飛龍：整幅轉 90°，龍首朝上，沿刀身中軸盤旋而下 */
      x.save(); x.translate(w / 2, 815); x.rotate(-Math.PI / 2); x.scale(1, .80);
      drawDragonFine(x, 0, 0, 365, ink, 1.35);
      x.restore();
      /* 火珠：龍首之前（上方） */
      var px = w / 2, py = 258;
      x.strokeStyle = ink2; x.lineWidth = 4;
      x.beginPath(); x.arc(px, py, 15, 0, 6.283); x.stroke();
      x.beginPath(); x.arc(px, py, 8, 0, 6.283); x.stroke();
      for (var f = 0; f < 7; f++) {
        var a = f / 7 * 6.283;
        x.beginPath();
        x.moveTo(px + Math.cos(a) * 19, py + Math.sin(a) * 19);
        x.quadraticCurveTo(px + Math.cos(a) * 31, py + Math.sin(a) * 31,
                           px + Math.cos(a + .34) * 42, py + Math.sin(a + .34) * 42);
        x.stroke();
      }
      /* 龍尾小雲帶（下端收勢） */
      drawCloud(x, 214, 1244, 34, ink3);
    });
    X.engrave.wrapS = X.engrave.wrapT = T.ClampToEdgeWrapping;

    /* 宣紙（卷軸） */
    X.paper = U.cvs(256, 512, function (x, w, h) {
      x.fillStyle = "#e3d7bc"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "rgba(150,120,80,.25)"; x.lineWidth = 1;
      for (var i = 0; i < 7; i++) { x.beginPath(); x.moveTo(i * w / 7 + 10, 0); x.lineTo(i * w / 7 + 10, h); x.stroke(); }
      x.strokeStyle = "rgba(30,22,16,.72)"; x.lineWidth = 7; x.lineCap = "round";
      for (var b = 0; b < 4; b++) {
        var cx = 30 + b * 60, cy = 80 + (b % 2) * 40;
        x.beginPath();
        x.moveTo(cx, cy); x.quadraticCurveTo(cx + 26, cy + 30, cx + 4, cy + 74);
        x.moveTo(cx + 20, cy + 8); x.quadraticCurveTo(cx + 44, cy + 34, cx + 16, cy + 60);
        x.stroke();
      }
    });
  }

  /* 同一材質的靜態部件合併，壓低 draw call（聖物整體仍可動） */
  function mergeStatic(root) {
    var buckets = {}, inv = new T.Matrix4();
    root.updateMatrixWorld(true);
    root.traverse(function (o) {
      if (!o.isMesh || o.isInstancedMesh) return;
      var m = o.material;
      if (!m || Array.isArray(m) || m.transparent || m.alphaTest > 0) return;
      (buckets[m.uuid] = buckets[m.uuid] || { m: m, list: [] }).list.push(o);
    });
    inv.copy(root.matrixWorld).invert();
    Object.keys(buckets).forEach(function (k) {
      var b = buckets[k];
      if (b.list.length < 3) return;
      var pos = [], nor = [], uv = [], total = 0, hasN = true, hasUV = true, mm = new T.Matrix4(), i;
      b.list.forEach(function (o) {
        var g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
        mm.copy(inv).multiply(o.matrixWorld);
        g.applyMatrix4(mm);
        var p = g.attributes.position, n = g.attributes.normal, u = g.attributes.uv;
        for (i = 0; i < p.count; i++) {
          pos.push(p.getX(i), p.getY(i), p.getZ(i));
          if (n) nor.push(n.getX(i), n.getY(i), n.getZ(i)); else hasN = false;
          if (u && hasUV) uv.push(u.getX(i), u.getY(i)); else hasUV = false;
        }
        total += p.count;
        g.dispose();
      });
      var out = new T.BufferGeometry();
      out.setAttribute("position", new T.Float32BufferAttribute(pos, 3));
      if (hasN && nor.length === total * 3) out.setAttribute("normal", new T.Float32BufferAttribute(nor, 3));
      if (hasUV && uv.length === total * 2) out.setAttribute("uv", new T.Float32BufferAttribute(uv, 2));
      out.computeBoundingSphere();
      var m2 = new T.Mesh(out, b.m);
      m2.castShadow = b.list[0].castShadow; m2.receiveShadow = b.list[0].receiveShadow;
      root.add(m2);
      b.list.forEach(function (o) { if (o.parent) o.parent.remove(o); });
    });
  }

  /* ---------------- 文昌筆 ---------------- */
  function buildBrush() {
    var g = pedestal(3.6, -5.4, -.55);
    brush = new T.Group(); brush.position.set(0, 0, 0); g.add(brush);

    var darkM = mat("#4a1709", { roughness: .62, metalness: .1 });
    var goldM = gold();
    var fretM = new T.MeshStandardMaterial({ map: X.fret, metalness: .86, roughness: .34 });

    /* ---- 筆架：雕花底座 + 車木立柱 + 托 ---- */
    box(.74, .05, .2, darkM, 0, .305, 0, brush);
    box(.78, .012, .22, goldM, 0, .327, 0, brush);
    [-1, 1].forEach(function (s) {
      lathe([[.052, 0], [.048, .022], [.033, .045], [.041, .095], [.029, .16],
             [.038, .205], [.025, .245], [.032, .278], [.018, .3]], 14, fretM, s * .3, .33, 0, brush);
      mesh(new T.SphereGeometry(.046, 12, 10), goldM, s * .3, .652, 0, brush);
      mesh(new T.SphereGeometry(.024, 10, 8), goldM, s * .3, .692, 0, brush);
    });
    /* V 形筆架托：兩臂承筆 */
    [-1, 1].forEach(function (s) {
      var arm = cyl(.023, .027, .36, goldM, s * .15, .567, 0, brush, 10);
      arm.rotation.z = -s * 1.006;
      mesh(new T.SphereGeometry(.032, 10, 8), goldM, s * .30, .663, 0, brush);
    });
    cyl(.03, .036, .1, fretM, 0, .36, 0, brush, 12);

    /* ---- 端硯 ---- */
    var stoneM = mat("#2b2c2f", { roughness: .58, metalness: .12 });
    var inkM = mat("#0a0b0c", { roughness: .1, metalness: .35 });
    var inkStone = new T.Group(); inkStone.position.set(-.3, .315, .26); inkStone.rotation.y = .42; brush.add(inkStone);
    box(.26, .05, .18, stoneM, 0, 0, 0, inkStone);
    box(.24, .012, .16, mat("#141518", { roughness: .35, metalness: .18 }), 0, .026, 0, inkStone);
    band(.052, .004, mat("#38393d", { roughness: .62, metalness: .2 }), .032, inkStone, 18);
    cyl(.05, .05, .012, inkM, -.045, .031, 0, inkStone, 18);
    box(.055, .012, .014, mat("#1b1512", { roughness: .45 }), .07, .034, .01, inkStone);   /* 墨條 */

    /* ---- 卷軸：紙卷 + 金軸頭 + 紅帶 ---- */
    var paperM = new T.MeshStandardMaterial({ map: X.paper, roughness: .92, metalness: .02 });
    var scroll = new T.Group(); scroll.position.set(.28, .32, .27); scroll.rotation.set(0, -.46, Math.PI / 2); brush.add(scroll);
    cyl(.03, .03, .34, paperM, 0, 0, 0, scroll, 14);
    [-.18, .18].forEach(function (y) { cyl(.036, .036, .022, goldM, 0, y, 0, scroll, 14); });
    band(.033, .006, mat("#8e1c10", { roughness: .9 }), .06, scroll, 16);

    /* ---- 筆身：近乎直立（僅斜 10°），筆頭朝上略偏右 ---- */
    var pen = new T.Group(); pen.position.set(0, .49, 0); pen.rotation.z = -.175; brush.add(pen);
    var handleM = new T.MeshStandardMaterial({
      map: X.handle, bumpMap: X.handle, bumpScale: .004, roughness: .4, metalness: .14
    });
    cyl(.054, .062, 1.4, handleM, 0, .7, 0, pen, 18);
    /* 上下端收口 */
    lathe([[.062, 0], [.066, .02], [.062, .05]], 16, darkM, 0, 0, 0, pen);
    lathe([[.056, 0], [.06, .02], [.054, .05]], 16, darkM, 0, 1.38, 0, pen);

    /* 四道金箍（回紋環 + 凸環，富雕工） */
    [.28, .62, .96, 1.24].forEach(function (y) {
      cyl(.066, .066, .05, fretM, 0, y, 0, pen, 18);
      band(.068, .009, goldM, y - .028, pen, 20);
      band(.068, .009, goldM, y + .028, pen, 20);
    });

    /* 筆斗（金）：承接筆鋒 */
    lathe([[.055, 0], [.076, .022], [.078, .05], [.062, .09], [.05, .12]], 20, fretM, 0, 1.44, 0, pen);
    band(.078, .008, goldM, 1.46, pen, 22);

    /* 筆肚／筆鋒：車削毛束本體 + 兩層散毛 */
    var bristleM = mat("#241c16", { roughness: .97 });
    lathe([[.052, 0], [.086, .04], [.104, .10], [.10, .17], [.076, .24], [.046, .31], [.02, .375], [.004, .43]],
      20, bristleM, 0, 1.47, 0, pen);
    var bGeoOut = new T.CylinderGeometry(.0022, .0075, 1, 4, 1); bGeoOut.translate(0, .5, 0);
    strandBundle(pen, 20, bGeoOut, mat("#33281c", { roughness: .98 }), [0, 1.5, 0], .078,
      function (i) { return .2 + (i % 4) * .016; },
      function (d, a, rr) { d.set(-Math.cos(a) * rr * .55, .5, -Math.sin(a) * rr * .55).normalize(); });
    strandBundle(pen, 24, bGeoOut, mat("#171210", { roughness: .99 }), [0, 1.66, 0], .055,
      function (i) { return .24 + (i % 5) * .014; },
      function (d, a, rr) { d.set(-Math.cos(a) * rr * .8, .38, -Math.sin(a) * rr * .8).normalize(); });
    /* 毛尖 */
    var tipC = mesh(new T.ConeGeometry(.022, .16, 10), mat("#0b0908", { roughness: .99 }), 0, 1.9, 0, pen);

    /* 筆尾玉托（嵌於筆桿末端，不凸出筆架） */
    cyl(.042, .042, .022, mat("#2d6b58", { metalness: .5, roughness: .24 }), 0, .011, 0, pen, 14);
    band(.056, .006, goldM, .032, pen, 16);

    /* 紅繩：環繞筆身 + 垂穗 */
    band(.07, .012, mat("#8e1c10", { roughness: .92 }), 1.3, pen, 20);
    var knot = new T.Group(); knot.position.set(.07, 1.26, 0); pen.add(knot);
    mesh(new T.SphereGeometry(.032, 12, 10), mat("#98220f", { roughness: .92 }), 0, 0, 0, knot);
    cyl(.024, .014, .05, mat("#7a170c", { roughness: .93 }), 0, -.035, 0, knot, 10);
    var tGeo = new T.CylinderGeometry(.006, .012, 1, 4, 1); tGeo.translate(0, .5, 0);
    strandBundle(knot, 14, tGeo, mat("#8e1c10", { roughness: .95 }), [0, -.045, 0], .022,
      function (i) { return .2 + (i % 4) * .022; },
      function (d, a, rr) { d.set(Math.cos(a) * rr * 1.6, -1, Math.sin(a) * rr * 1.6).normalize(); });
    /* 繩頭小金珠 */
    mesh(new T.SphereGeometry(.014, 8, 8), goldM, 0, .012, 0, knot);

    /* 互動光暈 */
    var gl = new T.Sprite(new T.SpriteMaterial({ map: U.TEX.glow, color: 0xffd27a, transparent: true, opacity: .35, blending: T.AdditiveBlending, depthWrite: false }));
    gl.scale.setScalar(1.6); gl.position.set(0, 1.3, 0); brush.add(gl); glowB = gl;
    mergeStatic(brush);
    U.brush = brush;
  }

  /* ---------------- 關帝刀（青龍偃月刀 · 博物館藏品形制） ---------------- */
  function buildBlade() {
    /* 擺位：刀背向神龕、刃口朝外（向庭院一方）—— 廟中兵器刃不向神；
       刀面朝走道，讓陰刻飛龍正對參拜者 */
    var g = pedestal(-3.6, -5.4, -2.27);
    blade = new T.Group(); blade.position.set(0, .28, 0); g.add(blade);

    var goldM = gold();
    /* 鑄銅（暖古銅，顆粒與刻線見貼圖） */
    var brassM = new T.MeshStandardMaterial({
      map: X.brass, bumpMap: X.brass, bumpScale: .004,
      metalness: .74, roughness: .4, envMapIntensity: .9,
      emissive: new T.Color("#4a3413"), emissiveIntensity: .5
    });
    /* 桿身魚鱗疊弧銅飾 */
    var haftM = new T.MeshStandardMaterial({
      map: X.scale, bumpMap: X.scale, bumpScale: .0035,
      metalness: .68, roughness: .46, envMapIntensity: .85,
      emissive: new T.Color("#3b2a12"), emissiveIntensity: .42
    });

    /* ---- 刀座 ---- */
    box(.34, .1, .34, mat("#3f0d08"), 0, .05, 0, blade);
    box(.4, .04, .4, goldM, 0, .11, 0, blade);
    box(.3, .03, .3, mat("#2a2b2e", { roughness: .6, metalness: .15 }), 0, .135, 0, blade);

    /* ---- 刀桿：灰鋼長柄（實測為金屬灰，非深漆黑）；中段銅雕鱗紋握把 + 細環分隔 ---- */
    var poleMat = new T.MeshStandardMaterial({
      color: new T.Color("#8b939b"), metalness: .88, roughness: .34, envMapIntensity: 1.0
    });
    cyl(.036, .044, 1.62, poleMat, 0, .93, 0, blade, 32);
    cyl(.054, .058, .86, haftM, 0, .79, 0, blade, 26);
    [.36, .575, .79, 1.005, 1.22].forEach(function (y) {
      band(.057, .006, goldM, y, blade, 30);
    });

    /* ---- 鐏：菱形截面銅配重（四面收尖，朝下，貼住刀座） ---- */
    var zun = mesh(new T.ConeGeometry(.052, .19, 4), brassM, 0, .095, 0, blade);
    zun.rotation.z = Math.PI; zun.rotation.y = Math.PI / 4;
    band(.044, .007, goldM, .196, blade, 24);

    /* ---- 護手：階梯錢紋銅盤 ---- */
    lathe([[.03, 0], [.05, .008], [.126, .014], [.132, .03], [.112, .042],
           [.117, .054], [.092, .066], [.072, .084], [.06, .106]], 30, brassM, 0, 1.76, 0, blade);
    band(.134, .007, goldM, 1.772, blade, 32);
    band(.098, .005, goldM, 1.826, blade, 28);

    /* ---- 吞口：龍軀橫環 + 龍首（高浮雕鑄銅） ---- */
    var bodyR = mesh(new T.TorusGeometry(.06, .017, 8, 26), brassM, 0, 1.852, 0, blade);
    bodyR.rotation.x = Math.PI / 2;

    var hd = new T.Group(); hd.position.set(0, 1.898, 0); hd.scale.setScalar(1.02); blade.add(hd);
    var hs = new T.Shape();
    hs.moveTo(-.094, .004);
    hs.bezierCurveTo(-.110, .050, -.098, .088, -.044, .102);
    hs.bezierCurveTo(.006, .114, .060, .100, .090, .076);
    hs.bezierCurveTo(.112, .060, .126, .044, .130, .028);
    hs.lineTo(.104, .022);
    hs.lineTo(.128, .004);
    hs.lineTo(.082, .008);
    hs.lineTo(.066, -.020);
    hs.lineTo(.104, -.048);
    hs.bezierCurveTo(.062, -.070, .018, -.066, -.018, -.048);
    hs.bezierCurveTo(-.052, -.032, -.078, -.012, -.094, .004);
    var hgeo = new T.ExtrudeGeometry(hs, {
      depth: .086, bevelEnabled: true, bevelSize: .009, bevelThickness: .009,
      bevelSegments: 3, curveSegments: 24
    });
    hgeo.translate(0, 0, -.043);
    mesh(hgeo, brassM, 0, 0, 0, hd);

    [-1, 1].forEach(function (s) {
      /* 眼 */
      mesh(new T.SphereGeometry(.013, 10, 8), mat("#6d1a0c", { roughness: .3, metalness: .25 }), .058, .058, s * .046, hd);
      /* 雙角（向後上收） */
      var h1 = mesh(new T.CylinderGeometry(.004, .014, .11, 8), brassM, -.048, .146, s * .030, hd);
      h1.rotation.set(s * .30, 0, .95);
      var h2 = mesh(new T.CylinderGeometry(.003, .009, .072, 7), brassM, -.004, .128, s * .036, hd);
      h2.rotation.set(s * .40, 0, .52);
      /* 龍鬚 */
      var wh = mesh(new T.CylinderGeometry(.0035, .0065, .12, 6), brassM, .108, .022, s * .036, hd);
      wh.rotation.set(s * .55, 0, -1.15);
      /* 獠牙 */
      mesh(new T.ConeGeometry(.006, .026, 6), mat("#e9dcc0", { roughness: .45 }), .114, .004, s * .026, hd);
      /* 腮鬃：向外斜張的片狀 */
      var mn = mesh(new T.ConeGeometry(.020, .075, 6), brassM, -.052, .010, s * .042, hd);
      mn.rotation.set(s * .55, 0, -1.75);
    });
    /* 口內（暗影，襯出張口） */
    mesh(new T.BoxGeometry(.062, .026, .05), mat("#2a1206", { roughness: .8 }), .092, -.020, 0, hd);
    /* 下頜獠牙 */
    [-1, 1].forEach(function (s) {
      var f = mesh(new T.ConeGeometry(.005, .020, 6), mat("#e9dcc0", { roughness: .45 }), .086, -.040, s * .020, hd);
      f.rotation.x = Math.PI;
    });
    /* 額脊 */
    var crest = mesh(new T.ConeGeometry(.013, .048, 7), brassM, .012, .096, 0, hd);
    crest.rotation.z = .38;
    /* 鬃鬣：自龍首後方垂落的刻鱗片 */
    for (var mi = 0; mi < 5; mi++) {
      var mf = mesh(new T.ConeGeometry(.019 - mi * .002, .052, 5), brassM,
        -.086 - mi * .004, .052 - mi * .028, 0, hd);
      mf.scale.set(1, 1, 2.4);
      mf.rotation.z = -1.28 + mi * .06;
    }

    /* ---- 刀身：依 Blender 實測 17 點輪廓（刀刃真實外形，含刀背月牙倒鉤） ----
       原始座標以公尺計：X＝刀刃橫向、Z＝沿刀身（1.25 → 2.00 m，全長 0.75 m）。
       換算：0.75 m 刀高 → 1.31 場景單位（S = 1.31 / 0.75），並把刀根中心歸零。
       原圖以 X 負向為刃口；本場景慣例為 +X 向刃口（刃口朝外、刀背向神龕），故 X 取負號鏡射。 */
    var S = 1.31 / 0.75;                        /* m → 場景單位 */
    var ROOT_CX = (-0.042 + 0.025) / 2;         /* 刀根中心（原始 X），歸零用 */

    /* 刃口側（原圖左側，刀根 → 刀尖，7 點） */
    var EDGE_M = [[-.042, 1.25], [-.050, 1.40], [-.058, 1.55], [-.068, 1.72],
                  [-.062, 1.88], [-.025, 1.96], [.095, 2.00]];
    /* 刀背側（原圖右側，刀尖 → 刀根，10 點）
       1.90, 1.82, 1.76（鉤口上緣）, 1.71, 1.68（鉤底）, 1.66, 1.69（倒鉤尖 barb）,
       1.56, 1.40, 1.25 */
    var SPINE_M = [[.065, 1.90], [.058, 1.82], [.062, 1.76], [.028, 1.71],
                   [.015, 1.68], [.032, 1.66], [.072, 1.69], [.048, 1.56],
                   [.035, 1.40], [.025, 1.25]];

    function bl(p) { return [-(p[0] - ROOT_CX) * S, (p[1] - 1.25) * S]; }
    /* Catmull-Rom（張力 .5）→ 三次貝茲：曲線逐點穿過每個控制點，端點夾持不越界 */
    function smoothPath(sh, pts, t) {
      t = (t === undefined) ? .5 : t;
      var n = pts.length, i, p0, p1, p2, p3, c1x, c1y, c2x, c2y;
      for (i = 0; i < n - 1; i++) {
        p0 = pts[i > 0 ? i - 1 : 0]; p1 = pts[i]; p2 = pts[i + 1];
        p3 = pts[i + 2 < n ? i + 2 : n - 1];
        c1x = p1[0] + (p2[0] - p0[0]) * t / 3; c1y = p1[1] + (p2[1] - p0[1]) * t / 3;
        c2x = p2[0] - (p3[0] - p1[0]) * t / 3; c2y = p2[1] - (p3[1] - p1[1]) * t / 3;
        sh.bezierCurveTo(c1x, c1y, c2x, c2y, p2[0], p2[1]);
      }
    }
    var A = EDGE_M.map(bl), B = SPINE_M.map(bl);

    var sh = new T.Shape();
    sh.moveTo(A[0][0], A[0][1]);
    smoothPath(sh, A);                          /* 刃口：刀根 → 刀尖，逐點穿過 7 控制點 */
    sh.lineTo(B[0][0], B[0][1]);                /* 刀尖斜邊 → 刀背起點 */
    smoothPath(sh, [B[0], B[1], B[2]]);         /* 刀背：刀尖下折至鉤口上緣 */
    sh.lineTo(B[3][0], B[3][1]);                /* 鉤口以下用直線，保持倒鉤銳角不被平滑吃掉 */
    sh.lineTo(B[4][0], B[4][1]);                /* 鉤底（最深處） */
    sh.lineTo(B[5][0], B[5][1]);
    sh.lineTo(B[6][0], B[6][1]);                /* 倒鉤尖 barb */
    smoothPath(sh, [B[6], B[7], B[8], B[9]]);   /* 刀背下段：回刀根 */
    sh.closePath();

    /* 刀身厚 1.4 cm（實測）→ 0.014 × S ≈ 0.0245 場景單位，
       以 depth + 雙面倒角分攤，倒角同時做出刃口中脊的拋光斜面 */
    var geo = new T.ExtrudeGeometry(sh, {
      depth: .0172, bevelEnabled: true, bevelSize: .004, bevelThickness: .0036,
      bevelSegments: 3, curveSegments: 44
    });
    geo.computeBoundingBox();
    var zb = geo.boundingBox, zMid = (zb.min.z + zb.max.z) / 2;
    var zHalf = (zb.max.z - zb.min.z) / 2;          /* 含倒角的刀身半厚 */
    geo.translate(0, 0, -zMid);

    /* 刀身本體：冷灰銀、斑駁水磨（非鏡面鉻） */
    var steelM = new T.MeshStandardMaterial({
      map: X.mottle,
      color: new T.Color("#8e9aa5"), metalness: .68, roughness: .44,
      emissive: new T.Color("#26323c"), emissiveIntensity: .55, envMapIntensity: .9
    });
    /* 刃口／刀背倒角：拋光冷光 */
    var edgeM = new T.MeshStandardMaterial({
      color: new T.Color("#ccd7e0"), metalness: .8, roughness: .24,
      emissive: new T.Color("#4f5d69"), emissiveIntensity: .38, envMapIntensity: 1.1
    });
    mesh(geo, [steelM, edgeM], .02, 1.9, 0, blade);

    /* ---- 刀身陰刻飛龍（雙面）：依刀形內縮裁切，避免刻線越出刀緣 ---- */
    var faceGeo = new T.ShapeGeometry(sh, 34);
    faceGeo.computeBoundingBox();
    var bb = faceGeo.boundingBox;
    var cx0 = (bb.min.x + bb.max.x) / 2, cy0 = (bb.min.y + bb.max.y) / 2;
    faceGeo.translate(-cx0, -cy0, 0);
    faceGeo.scale(.88, .93, 1);
    faceGeo.translate(cx0, cy0, 0);
    var pAttr = faceGeo.attributes.position, uAttr = faceGeo.attributes.uv, ui;
    for (ui = 0; ui < pAttr.count; ui++) uAttr.setXY(ui, pAttr.getX(ui), pAttr.getY(ui));
    faceGeo.computeBoundingBox();
    bb = faceGeo.boundingBox;
    var fw = bb.max.x - bb.min.x, fh = bb.max.y - bb.min.y;
    var ew = fw, eh = fh;
    var ex = bb.min.x, ey = bb.min.y;
    X.engrave.repeat.set(1 / ew, 1 / eh);
    X.engrave.offset.set(-ex / ew, -ey / eh);
    var engM = new T.MeshStandardMaterial({
      map: X.engrave, bumpMap: X.engrave, bumpScale: -.006,
      transparent: true, alphaTest: .16, opacity: .97,
      color: 0xffffff, metalness: .3, roughness: .58, side: T.DoubleSide,
      emissive: new T.Color("#160c04"), emissiveIntensity: .3,
      depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4
    });
    [-1, 1].forEach(function (s) {
      mesh(faceGeo, engM, .02, 1.9, s * (zHalf + .0012), blade);
    });

    /* ---- 月牙倒鉤已併入刀背輪廓（SPINE_M 的 1.66–1.76 m 段，倒鉤尖於 1.69 m），不再另建 ---- */

    /* ---- 紅纓：三層長穗，角度錯落 ---- */
    var knot = mesh(new T.SphereGeometry(.05, 14, 12), mat("#8e1c10", { roughness: .92 }), 0, 1.70, 0, blade);
    knot.scale.set(1, 1.25, 1);
    cyl(.062, .042, .06, goldM, 0, 1.66, 0, blade, 14);
    var tGeo = new T.CylinderGeometry(.009, .017, 1, 4, 1); tGeo.translate(0, .5, 0);
    var tasselM = new T.MeshStandardMaterial({ color: new T.Color("#98220f"), roughness: .95, side: T.DoubleSide });
    strandBundle(blade, 26, tGeo, tasselM, [0, 1.68, 0], .045,
      function (i) { return .46 + (i % 5) * .06; },
      function (d, a, rr) {
        d.set(Math.cos(a) * (.16 + rr * 2.2) + Math.sin(a * 3.1) * .1, -1,
              Math.sin(a) * (.16 + rr * 2.2) + Math.cos(a * 2.3) * .1).normalize();
      });
    var tGeo2 = new T.CylinderGeometry(.007, .012, 1, 4, 1); tGeo2.translate(0, .5, 0);
    strandBundle(blade, 12, tGeo2, mat("#6e150b", { roughness: .96 }), [0, 1.66, 0], .022,
      function (i) { return .34 + (i % 3) * .05; },
      function (d, a, rr) { d.set(Math.cos(a) * .1, -1, Math.sin(a) * .1).normalize(); });

    /* 光暈 */
    var gl = new T.Sprite(new T.SpriteMaterial({ map: U.TEX.glow, color: 0xffcf8a, transparent: true, opacity: .3, blending: T.AdditiveBlending, depthWrite: false }));
    gl.scale.setScalar(2.0); gl.position.set(.12, 2.72, 0); blade.add(gl); glowK = gl;
    mergeStatic(blade);
    U.blade = blade;
  }

  /* ---------------- 觸摸動畫 ---------------- */
  MM.touchRelic = function (kind) {
    if (kind === "brush") { animB = 1.6; }
    else { animK = 1.6; }
  };
  U.onFrameRelics = function (dt, t) {
    if (animB > 0) {
      animB = Math.max(0, animB - dt);
      var k = Math.sin((1.6 - animB) / 1.6 * Math.PI);
      brush.position.y = k * .05;
      brush.rotation.y = k * .22;
      glowB.material.opacity = .35 + k * .55;
      glowB.scale.setScalar(1.6 + k * .9);
    }
    if (animK > 0) {
      animK = Math.max(0, animK - dt);
      var k2 = Math.sin((1.6 - animK) / 1.6 * Math.PI);
      blade.position.y = .28 + k2 * .05;
      blade.rotation.y = -k2 * .18;
      glowK.material.opacity = .3 + k2 * .55;
      glowK.scale.setScalar(1.8 + k2 * .9);
    }
  };

  MM.buildRelics = init;
})();
