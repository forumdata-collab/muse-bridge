/* 文武廟 · 節慶模式 + 攝太歲
   - 節慶：平常 / 農曆新年 / 文昌誕 / 秋祭（示範切換，唔會自動判錯農曆）
   - 太歲：以出生年地支計值／沖／刑／害／破 */
(function () {
  "use strict";
  var T = window.THREE, MM = window.MM, U = MM._;
  var scene, box, plane, mesh, mat, gold, rnd, textTexture, cyl;
  var mode = "none", group = null, petals = null, banner = null;
  var petalGeo, petalArr = [];

  var ZODIAC = ["鼠", "牛", "虎", "兔", "龍", "蛇", "馬", "羊", "猴", "雞", "狗", "豬"];
  var GAN = ["甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"];
  var ZHI = ["子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"];
  var SELF_XING = [4, 6, 9, 11];
  var XING = [[0, 3], [2, 5], [2, 8], [5, 8], [1, 10], [7, 10]];
  var HAI = [[0, 7], [1, 6], [2, 5], [3, 4], [8, 11], [9, 10]];
  var PO = [[0, 9], [1, 4], [2, 11], [3, 6], [5, 8], [7, 10]];

  function pairIn(list, a, b) {
    return list.some(function (p) { return (p[0] === a && p[1] === b) || (p[0] === b && p[1] === a); });
  }
  MM.zodiacOf = function (year) { return ((year - 4) % 12 + 12) % 12; };
  MM.zodiacName = function (i) { return ZODIAC[i]; };
  MM.yearGanzhi = function (y) { return GAN[((y - 4) % 10 + 10) % 10] + ZHI[((y - 4) % 12 + 12) % 12]; };

  MM.checkTaiSui = function (birthYear, nowYear) {
    nowYear = nowYear || new Date().getFullYear();
    var P = MM.zodiacOf(birthYear), Y = MM.zodiacOf(nowYear);
    var hits = [];
    if (P === Y) hits.push("值太歲");
    if (P === (Y + 6) % 12) hits.push("沖太歲");
    if ((P === Y && SELF_XING.indexOf(P) >= 0) || pairIn(XING, P, Y)) hits.push("刑太歲");
    if (pairIn(HAI, P, Y)) hits.push("害太歲");
    if (pairIn(PO, P, Y)) hits.push("破太歲");
    return {
      birth: { year: birthYear, zhi: ZHI[P], zodiac: ZODIAC[P] },
      now: { year: nowYear, ganzhi: MM.yearGanzhi(nowYear), zhi: ZHI[Y], zodiac: ZODIAC[Y] },
      hits: hits
    };
  };

  /* ---------------- 節慶視覺 ---------------- */
  function clearGroup() {
    if (group) { scene.remove(group); group = null; }
    if (petals) { scene.remove(petals); petals = null; petalArr = []; }
  }

  function bannerPlane(text) {
    var m = new T.MeshBasicMaterial({ map: textTexture(text, { size: 90, color: "#ffe6b0", bg: "rgba(90,16,10,.92)", pad: 18 }), transparent: true });
    var p = plane(3.0, .95, m, 0, 4.4, 12.1, null);
    p.rotation.y = Math.PI;
    return p;
  }

  function buildNewYear(g) {
    /* 桃花瓣（飄落粒子） */
    petalGeo = petalGeo || new T.BufferGeometry();
    var n = 260, pos = new Float32Array(n * 3), sp = new Float32Array(n * 3);
    for (var i = 0; i < n; i++) {
      pos[i * 3] = rnd(-9, 9); pos[i * 3 + 1] = rnd(0, 9); pos[i * 3 + 2] = rnd(-11, 12);
      sp[i * 3] = rnd(-.08, .08); sp[i * 3 + 1] = rnd(-.35, -.12); sp[i * 3 + 2] = rnd(-.08, .08);
    }
    petalGeo.setAttribute("position", new T.BufferAttribute(pos, 3));
    var m = new T.PointsMaterial({ map: U.TEX.dust, color: 0xffb3c6, size: .12, transparent: true, opacity: .9, depthWrite: false });
    petals = new T.Points(petalGeo, m); petals.frustumCulled = false; scene.add(petals);
    petalArr = sp;
    /* 額外紅燈籠 */
    [[-6.2, 8.6], [6.2, 8.6], [-6.2, 3.0], [6.2, 3.0]].forEach(function (p) {
      g.add(U.makeLantern(p[0], 5.0, p[1], 1.05));
    });
  }

  function buildWenchang(g) {
    /* 開筆禮供品：蔥（聰明）、芹（勤力）、蒜（算）、桂花（貴） */
    var items = [
      { x: -1.5, col: "#2f7d32", h: .5, label: "蔥" },
      { x: -.5, col: "#4e8f3a", h: .55, label: "芹" },
      { x: .5, col: "#d8cfa8", h: .35, label: "蒜" },
      { x: 1.5, col: "#c9a24e", h: .3, label: "桂" }
    ];
    items.forEach(function (it) {
      var p = new T.Group(); p.position.set(it.x, 1.16, -9.5); g.add(p);
      cyl(.09, .11, it.h, new T.MeshStandardMaterial({ color: new T.Color(it.col), roughness: .85 }), 0, it.h / 2, 0, p, 8);
      for (var i = 0; i < 4; i++) {
        var leaf = box(.02, .16, .09, new T.MeshStandardMaterial({ color: new T.Color(it.col), roughness: .9 }), rnd(-.05, .05), it.h + rnd(-.02, .06), rnd(-.05, .05), p);
        leaf.rotation.z = rnd(-.5, .5);
      }
    });
    /* 紅桌布 */
    box(4.4, .02, .95, new T.MeshStandardMaterial({ color: new T.Color("#9c1f14"), roughness: .9 }), 0, 1.17, -9.5, g);
  }

  function buildAutumn(g) {
    /* 秋祭：紅地毯 + 香爐前供桌 + 燒豬（簡化） */
    var rug = plane(6.0, 10.0, new T.MeshStandardMaterial({ color: new T.Color("#6d1109"), roughness: .95 }), 0, .012, -2.0, g);
    rug.rotation.x = -Math.PI / 2;
    var pig = new T.Group(); pig.position.set(0, .95, -7.4); g.add(pig);
    var skin = new T.MeshStandardMaterial({ color: new T.Color("#b5652f"), roughness: .55, metalness: .25 });
    mesh(new T.SphereGeometry(.42, 18, 14), skin, 0, .1, 0, pig).scale.set(1.5, .72, .9);
    [[-.45, .07, 0], [.45, .07, 0]].forEach(function (p) {
      mesh(new T.SphereGeometry(.09, 8, 6), skin, p[0], p[1], p[2], pig);
    });
    box(1.1, .08, .7, mat("#5a1a10"), 0, -.02, 0, pig);
  }

  MM.setFestival = function (m) {
    if (!scene) return;
    mode = m || "none";
    clearGroup();
    if (mode === "none") return;
    group = new T.Group(); scene.add(group);
    if (mode === "newyear") { buildNewYear(group); banner = bannerPlane("花開富貴 · 新年進步"); }
    else if (mode === "wenchang") { buildWenchang(group); banner = bannerPlane("文昌誕 · 開筆禮"); }
    else if (mode === "autumn") { buildAutumn(group); banner = bannerPlane("秋祭 · 感念神恩"); }
    if (banner) group.add(banner);
    MM.festivalMode = mode;
  };

  function init() {
    scene = U.scene; box = U.box; plane = U.plane; mesh = U.mesh; cyl = U.cyl;
    mat = U.mat; gold = U.gold; rnd = U.rnd; textTexture = U.textTexture;
    U.onFrameFestival = function (dt, t) {
      /* v97：節慶橫額輕擺 — 橫額掛喺度都會隨氣流輕輕搖，唔係一塊死板 */
      if (banner) banner.rotation.z = Math.sin(t * .8) * .012;
      if (!petals || !petalArr) return;
      var p = petalGeo.attributes.position.array;
      for (var i = 0; i < petalArr.length / 3; i++) {
        p[i * 3] += petalArr[i * 3] * dt * 10 + Math.sin(t + i) * .002;
        p[i * 3 + 1] += petalArr[i * 3 + 1] * dt * 10;
        p[i * 3 + 2] += petalArr[i * 3 + 2] * dt * 10;
        if (p[i * 3 + 1] < .1) { p[i * 3 + 1] = 8.8; p[i * 3] = rnd(-9, 9); p[i * 3 + 2] = rnd(-11, 12); }
      }
      petalGeo.attributes.position.needsUpdate = true;
    };
    MM.buildFestival = function () { };
  }
  MM._initFestival = init;
})();
