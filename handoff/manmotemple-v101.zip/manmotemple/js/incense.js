/* 文武廟 · 上香子系統（單一真相）
   ─ 香爐註冊表：位置、爐口高度、上前位置、煙霧系統，全部集中在這裡
   ─ 儀式狀態機：到位 → 行禮 → 插香 → 下一爐；可取消、防重入（token 機制）
   ─ 只負責「拜神邏輯 + 香枝視覺」，字幕／toast／轉場由 app 傳入的 UI 介面處理

   儀式流程（廟祝視角）：
   · 三炷（殿內）：香案取香、點燃（不插香）→ 正殿主爐行禮後插 3 炷
   · 三炷（廟前）：天公爐 1 炷（行禮後插香；入殿後可再向二帝上香）
   · 一炷心香：最近香爐 1 炷，行禮、插香，人不移動
*/
(function () {
  "use strict";
  var MM = window.MM, T = window.THREE, U = MM._;

  /* ---------- 常數 ---------- */
  var TIMING = { bow: 1600, noBow: 650, afterOffer: 1000 };  // 行禮停留 / 無禮插香 / 爐與爐之間
  var TRAVEL_DIST = 2.2;   // 距爐超過此距離（米）→ 先淡入淡出移動（避免穿模）
  var COURT_Z = 9;         // player.z 大於此值視為廟前天公爐區
  var SMOKE_PER_STICK = .02, SMOKE_MAX = .3;               // 每炷香煙霧轉濃幅度 / 上限
  var MAX_VISIBLE = 30;        // 每爐最多 30 枝動態香（維持手機 draw calls 上限）
  var BURN_MS = 8 * 60 * 1000;    // 一炷香燃燒時間（8 分鐘）
  var STORE_KEY = "manmo.sticks.v1";
  var burning = [];               // 運行中的香：{c, mesh, tip, glow, h, t0, dur}
  var seq = {};                    // 每爐最後編號；只從現存香推算，避免重開後撞位

  /* ---------- 香爐註冊表 ---------- */
  /* 每個爐：{ id, name, group, ashY, approach:{x,z}, total, smoke? } */
  var censers = [];
  var token = 0;           // 每次啟動遞增，舊流程的待執行 callback 全部作廢
  var busy = false;
  var routineTimer = null;
  var phase = "idle";
  var feedbackHooks = [];
  var ui = {               // app 以 configure() 覆寫
    caption: function () {}, toast: function () {}, bow: function () {},
    travel: function (x, z, cb) { cb && cb(); }, save: function () {}
  };

  function register(c) {
    if (!c || !c.group) return;
    censers.push({
      id: c.id, name: c.name, group: c.group,
      ashY: c.ashY == null ? .6 : c.ashY,
      approach: c.approach || { x: 0, z: 0 },
      smoke: c.smoke || null,          // 該爐煙霧系統（U.makeSmoke 回傳值）；缺省 fallback 到 U.censerSmoke
      total: 0
    });
  }

  function byId(id) {
    for (var i = 0; i < censers.length; i++) if (censers[i].id === id) return censers[i];
    return null;
  }

  function nearest() {
    var px = U.player ? U.player.x : 0, pz = U.player ? U.player.z : 0;
    var best = null, bd = Infinity;
    for (var i = 0; i < censers.length; i++) {
      var c = censers[i];
      /* 補香按香爐實際位置，不能按後移的鞠躬站位選爐。 */
      var pos = c.group.getWorldPosition(new T.Vector3());
      var d = Math.hypot(px - pos.x, pz - pos.z);
      if (d < bd) { bd = d; best = c; }
    }
    return { censer: best, dist: bd };
  }

  /* ---------- 香枝視覺 ---------- */
  /* 一枝香 = 香腳 + 火頭 + 光暈（3 個 draw call）。
     geometry / material 全爐共用（unit cylinder 以 scale.y 拉長），不用每枝香 new。 */
  var RES = null;
  function res() {
    if (RES) return RES;
    RES = {
      stickGeo: new T.CylinderGeometry(.010, .012, 1, 5),
      stickMat: U.mat("#8b5a2b"),
      tipGeo: new T.SphereGeometry(.017, 6, 5),
      tipMat: new T.MeshBasicMaterial({ color: 0xff9a4d }),
      glowMat: new T.SpriteMaterial({ map: U.TEX.glow, color: 0xff8a3d, transparent: true, opacity: .5, blending: T.AdditiveBlending, depthWrite: false })
    };
    return RES;
  }

  function buildStick(o, animate, delay) {
    var R = res();
    /* 新香集中於朝向參拜者的前半圈，不埋在原有香叢背後。 */
    var a = o.i * 2.399, r = .04 + (o.i % 7) * .034;
    var x = Math.cos(a) * r * .8, z = .15 + Math.sin(a) * r * .5;
    var base = o.c.ashY, start = animate ? .035 : o.h;
    var st = new T.Mesh(R.stickGeo, R.stickMat);
    st.scale.y = start;
    st.position.set(x, base + start / 2, z);
    st.rotation.set(U.rnd(-.06, .06), 0, U.rnd(-.06, .06));
    o.c.group.add(st);
    var tip = new T.Mesh(R.tipGeo, R.tipMat);
    tip.position.set(x, base + start + .012, z);
    o.c.group.add(tip);
    var gl = new T.Sprite(R.glowMat);
    gl.scale.setScalar(animate ? .3 : .2);
    gl.position.set(x, base + start + .02, z); o.c.group.add(gl);
    o.mesh = st; o.tip = tip; o.glow = gl; o.x = x; o.z = z;
    if (animate) { o.appearAt = (window.performance && performance.now) ? performance.now() + (delay || 0) : Date.now() + (delay || 0); o.appearMs = 520; }
    else o.appearAt = 0;
  }

  function animateInsertion(o) {
    var raf = window.requestAnimationFrame || function (fn) { return setTimeout(function () { fn(Date.now()); }, 16); };
    var start = o.appearAt, span = o.appearMs || 520;
    function frame(now) {
      if (burning.indexOf(o) < 0) return;
      var elapsed = (now || Date.now()) - start;
      var p = Math.max(0, Math.min(1, elapsed / span)), eased = 1 - Math.pow(1 - p, 3);
      var h = .035 + (o.h - .035) * eased;
      o.mesh.scale.y = h; o.mesh.position.y = o.c.ashY + h / 2;
      o.tip.position.y = o.c.ashY + h + .012; o.glow.position.y = o.c.ashY + h + .02;
      o.glow.scale.setScalar(.3 - .1 * eased);
      if (elapsed < span) raf(frame);
      else { o.appearAt = 0; o.mesh.scale.y = o.h; }
    }
    raf(frame);
  }

  function stick(c, i, delay) {
    var h = .52 + (i % 5) * .045 + U.rnd(0, .04);
    var o = { c: c, i: i, h: h, t0: Date.now(), dur: BURN_MS };
    buildStick(o, true, delay);
    burning.push(o);
    animateInsertion(o);
    persist();
    return o;
  }

  function addedCount(c) {
    return burning.reduce(function (n, o) { return n + (o.c === c ? 1 : 0); }, 0);
  }
  function trimOldest(c) {
    for (var k = 0; k < burning.length; k++) {
      var o = burning[k];
      if (o.c !== c) continue;
      c.group.remove(o.mesh); c.group.remove(o.tip); c.group.remove(o.glow);
      burning.splice(k, 1);
      return;
    }
  }
  function capVisible(c) {
    while (addedCount(c) > MAX_VISIBLE) trimOldest(c);
  }

  function syncSmoke(c) {
    var sm = c && (c.smoke || U.censerSmoke);
    try {
      if (!sm || !sm.points) return;
      var mat = sm.points.material;
      if (mat.userData.incenseBase == null) mat.userData.incenseBase = mat.opacity;
      mat.userData.incenseAdded = Math.min(SMOKE_MAX, SMOKE_PER_STICK * (Number(c.total) || 0));
      mat.opacity = Math.min(SMOKE_MAX, mat.userData.incenseBase + mat.userData.incenseAdded);
    } catch (e) {}
  }

  function emitFeedback() {
    var state = { busy: busy, phase: phase };
    feedbackHooks.slice().forEach(function (fn) { try { fn(state); } catch (e) {} });
  }

  function cancelRoutineTimer() {
    if (routineTimer) clearTimeout(routineTimer);
    routineTimer = null;
  }

  function later(fn, delay, my) {
    cancelRoutineTimer();
    routineTimer = setTimeout(function () {
      routineTimer = null;
      if (my === token && busy) fn();
    }, delay);
  }

  /* 每 8 秒按時間把香縮短；回訪即按時間差重算。 */
  function tick(now) {
    now = now || Date.now();
    for (var k = burning.length - 1; k >= 0; k--) {
      var o = burning[k];
      var p = (now - o.t0) / o.dur;
      if (p < 0) p = 0;
      if (p >= 1) {
        try { o.c.group.remove(o.mesh); o.c.group.remove(o.tip); o.c.group.remove(o.glow); } catch (e) {}
        burning.splice(k, 1);
        continue;
      }
      var left = o.h * (1 - p);
      if (left < .02) left = .02;
      var inserted = o.appearAt ? Math.max(0, Math.min(1, ((window.performance && performance.now ? performance.now() : now) - o.appearAt) / (o.appearMs || 520))) : 1;
      var visible = left * (1 - Math.pow(1 - inserted, 3));
      o.mesh.scale.y = Math.max(.025, visible);
      o.mesh.position.y = o.c.ashY + Math.max(.025, visible) / 2;
      o.tip.position.y = o.c.ashY + Math.max(.025, visible) + .012;
      o.glow.position.y = o.c.ashY + Math.max(.025, visible) + .02;
      o.glow.material.opacity = .5 * (1 - p * .7) * (.35 + .65 * inserted);
    }
    persist();
  }

  function persist() {
    try {
      var arr = burning.map(function (o) { return { c: o.c.id, i: o.i, h: +o.h.toFixed(3), t0: o.t0, dur: o.dur }; });
      localStorage.setItem(STORE_KEY, JSON.stringify(arr.slice(-180)));
    } catch (e) {}
  }

  /* 開站時把上次未燒完的香接返（按時間差縮短） */
  function restore() {
    var arr = [];
    try { arr = JSON.parse(localStorage.getItem(STORE_KEY) || "[]"); } catch (e) { arr = []; }
    var now = Date.now();
    arr.forEach(function (r) {
      var c = byId(r.c); if (!c) return;
      var o = { c: c, i: r.i, h: r.h, t0: r.t0, dur: r.dur || BURN_MS };
      buildStick(o, false);
      burning.push(o);
      c.total = Math.max(c.total, +r.i || 0);
      seq[c.id] = Math.max(seq[c.id] || 0, +r.i || 0);
      capVisible(c);
    });
    censers.forEach(syncSmoke);
    tick(now);
  }

  function offer(id, n) {
    var c = byId(id);
    n = Math.floor(Number(n));
    if (!c || !(n > 0)) return 0;
    n = Math.min(n, MAX_VISIBLE);
    var added = 0;
    for (var k = 0; k < n; k++) {
      seq[c.id] = (seq[c.id] || 0) + 1;
      stick(c, seq[c.id], k * 150);
      c.total++;
      added++;
    }
    capVisible(c);
    syncSmoke(c);
    persist();
    return added;
  }

  /* ---------- 儀式程序 ---------- */
  /* buildSteps(mode)：把「上甚麼香」純粹化成步驟表；狀態機只負責「怎樣行禮」 */
  function buildSteps(mode) {
    if (mode === "one") {
      var n = nearest();
      if (!n.censer) return null;
      return [{ censer: n.censer.id, n: 1, bow: true,
                cap: "一炷心香 —— " + n.censer.name + "，心誠則靈。" }];
    }
    if (mode === "court") return [
      { censer: "heaven", n: 1, bow: true, cap: "先到天公爐前，合十行禮。" }
    ];
    return [
      { censer: "front", n: 0, bow: false, cap: "到香案前取三炷清香，就爐點燃。" },
      { censer: "main",  n: 3, bow: true,  cap: "到枱前中央，面向文武二帝舉香祈願，三鞠躬後插三炷清香。" }
    ];
  }

  /* 第一身持香：鏡頭局部座標，帶位低持、行禮舉高；不冒充廟方指定手勢。 */
  var held = null;
  function showHeld(n, raised) {
    if (!held) {
      held = new T.Group(); held.name = 'ritual-held-incense';
      U.camera.add(held); U.scene.add(U.camera);
      var stem = new T.MeshBasicMaterial({ color: 0x9b6437 });
      var ember = new T.MeshBasicMaterial({ color: 0xffa24d });
      for (var j = 0; j < 3; j++) {
        var branch = new T.Group();
        var stick = new T.Mesh(new T.CylinderGeometry(.003, .003, .36, 5), stem);
        stick.position.y = .15; branch.add(stick);
        var tip = new T.Mesh(new T.SphereGeometry(.005, 6, 4), ember);
        tip.position.y = .332; branch.add(tip); branch.position.x = (j - 1) * .019;
        held.add(branch);
      }
      var skin = new T.MeshBasicMaterial({ color: 0xb98a68 });
      [-1, 1].forEach(function (side) {
        var hand = new T.Mesh(new T.BoxGeometry(.034, .092, .026), skin);
        hand.position.set(side * .025, -.055, .018);
        hand.rotation.z = side * .12; held.add(hand);
        for (var finger = 0; finger < 4; finger++) {
          var digit = new T.Mesh(new T.SphereGeometry(.008, 8, 6), skin);
          digit.scale.set(.8, 3.2 - finger * .2, .8);
          digit.position.set(side * (.008 + finger * .01), .009 - finger * .004, .018);
          held.add(digit);
        }
      });
    }
    held.visible = n > 0;
    for (var k = 0; k < 3; k++) held.children[k].visible = k < n;
    held.position.set(0, raised ? -.12 : -.37, -.65);
  }

  function run(mode) {
    if (busy) return false;
    var steps = buildSteps(mode);
    if (!steps || steps.some(function (s) { return !byId(s.censer); })) return false;
    busy = true;
    phase = "preparing";
    var my = ++token, i = 0, lastCenser = null, lastAdded = 0;
    var alive = function () { return my === token; };
    ui.toast(mode === "one" ? "誠心上香 · 正準備前往香爐" : "參拜開始 · 請隨心默念所求");
    emitFeedback();

    /* 單一爐次序：caption → （需要時）移動 → 行禮 → 停頓 → 插香 → 下一爐或完成 */
    function step() {
      if (!alive()) return;
      var s = steps[i];
      var c = byId(s.censer);
      if (!c) { finish(); return; }
      ui.caption(s.cap);
      var proceed = function () {
        if (!alive()) return;
        if (s.bow) {
          U.player.yaw = Math.PI; U.player.pitch = -.03;
          showHeld(s.n, true);
        }
        if (s.n > 0) {
          phase = "bowing";
          ui.toast("合十默念心願 · 香火將入「" + c.name + "」");
          emitFeedback();
        }
        function insertOffering() {
          if (!alive()) return;
          if (s.n === 0) showHeld(3, false);
          var added = offer(s.censer, s.n);
          if (added > 0) {
            showHeld(0, false);
            lastCenser = c; lastAdded += added;
            phase = "settling";
            ui.toast("香枝已落爐 · " + added + " 炷 → " + c.name);
            if (ui.insert) ui.insert(added, c);
            ui.save(); emitFeedback();
          }
          i++;
          if (i < steps.length) later(step, TIMING.afterOffer, my);
          else later(finish, 1500, my);
        }
        if (s.bow) {
          var bowCount = mode === "hall" ? 3 : 1, bowIndex = 0;
          function bowNext() {
            if (!alive()) return;
            ui.caption((mode === "hall" ? "面向文武二帝" : "誠心行禮") + " · 第 " + (++bowIndex) + " 鞠躬／" + bowCount);
            ui.bow();
            later(bowIndex < bowCount ? bowNext : insertOffering, TIMING.bow, my);
          }
          later(bowNext, 700, my);
        } else later(insertOffering, TIMING.noBow, my);
      };
      var px = U.player ? U.player.x : 0, pz = U.player ? U.player.z : 0;
      var d = Math.hypot(px - c.approach.x, pz - c.approach.z);
      var mustWalk = mode === "one" ? nearest().dist > TRAVEL_DIST : (d > TRAVEL_DIST ||
        (s.censer === "main" && d > .08) ||
        (s.censer === "front" && d > .08) ||
        (s.censer === "heaven" && d > .08));
      if (mustWalk) {
        phase = "traveling"; emitFeedback();
        ui.travel(c.approach.x, c.approach.z, proceed);
      } else proceed();
    }

    /* 完成結語按模式分清：三炷 / 天公 / 心香（舊版一炷會錯報「三炷已上」） */
    function finish() {
      if (!alive()) return;
      cancelRoutineTimer();
      showHeld(0, false);
      busy = false; phase = "idle";
      ui.toast(lastAdded
        ? lastAdded + " 炷已安奉 · " + (lastCenser ? lastCenser.name : "香爐") +
          (mode === "court" ? " · 入殿後可再向文武二帝上香" : " · 香火漸濃")
        : mode === "one" ? "一炷心香已上 · 心誠則靈"
        : mode === "court" ? "天公爐清香已上 · 入殿後可再向文武二帝上香"
        : "三炷清香已上");
      emitFeedback();
      if (ui.done) ui.done(mode);
    }

    step();
    return true;
  }

  function cancel() {
    token++; cancelRoutineTimer(); busy = false; phase = "idle";
    if (held) held.visible = false;
    ui.caption(""); emitFeedback();
  }

  /* 背景 tick：分頁隱藏時暫停，返嚟即按時間重算 */
  var tickTimer = null;
  function startTicker() {
    if (tickTimer) return;
    tickTimer = setInterval(function () { if (!document.hidden) tick(); }, 8000);
    document.addEventListener("visibilitychange", function () { if (!document.hidden) tick(); });
  }
  MM.Incense_ready = true;

  function location_is_court() {
    return !!(U.player && U.player.z > COURT_Z);
  }

  /* ---------- 公開 API（保持不變：app.js / world.js / tests 依賴） ---------- */
  MM.Incense = {
    register: register, censers: censers, byId: byId, nearest: nearest,
    offer: offer, stick: stick,
    three: function () { return run(location_is_court() ? "court" : "hall"); },
    one: function () { return run("one"); },
    cancel: cancel,
    restore: restore,
    tick: tick,
    setBurnMs: function (ms) { BURN_MS = ms; },
    burning: burning,
    isBusy: function () { return busy; },
    phase: function () { return phase; },
    onState: function (fn) { if (typeof fn === "function") { feedbackHooks.push(fn); fn({ busy: busy, phase: phase }); } },
    configure: function (hooks) { for (var k in hooks) if (hooks.hasOwnProperty(k)) ui[k] = hooks[k]; }
  };
  startTicker();
})();
