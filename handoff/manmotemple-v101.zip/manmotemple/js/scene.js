/* 文武廟 · 雲端參拜 — 場景核心
   兩進三開間 · 天井 · 花崗石柱 · 塔香 · 神龕 · 光明燈 · 祈福牌
   three.js r128, 全程序化建模，除照片外零外部資源 */
(function () {
  "use strict";
  var T = window.THREE;
  var MM = window.MM = window.MM || {};
  var U = MM._ = {};                 // shared helpers for world.js / app.js
  var scene, camera, renderer, clock;
  var QUAL = "high", running = false, t0 = 0;

  /* ---------------- helpers ---------------- */
  var matCache = {};
  function mat(color, o) {
    o = o || {};
    var key = color + JSON.stringify(o);
    if (matCache[key]) return matCache[key];
    var m = new T.MeshStandardMaterial(Object.assign({ color: new T.Color(color), roughness: .78, metalness: 0 }, o));
    matCache[key] = m; return m;
  }
  function gold() { return mat("#c9a24e", { metalness: .84, roughness: .33 }); }
  function mesh(g, m, x, y, z, parent) {
    var o = new T.Mesh(g, m); o.position.set(x || 0, y || 0, z || 0); (parent || scene).add(o); return o;
  }
  function box(w, h, d, m, x, y, z, p) { return mesh(new T.BoxGeometry(w, h, d), m, x, y, z, p); }
  function cyl(rt, rb, h, m, x, y, z, p, seg) { return mesh(new T.CylinderGeometry(rt, rb, h, seg || 20), m, x, y, z, p); }
  function plane(w, h, m, x, y, z, p) { return mesh(new T.PlaneGeometry(w, h), m, x, y, z, p); }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function srand() { return Math.random() * 2 - 1; }

  var SERIF = '"Noto Serif TC","Songti TC","Source Han Serif TC","PingFang HK",serif';
  var SANS = '"Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif';

  function cvs(w, h, draw) {
    var c = document.createElement("canvas"); c.width = w; c.height = h;
    var x = c.getContext("2d"); draw(x, w, h);
    var t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; t.anisotropy = 8;
    return t;
  }
  function speckle(x, w, h, n, a) {
    for (var i = 0; i < n; i++) {
      x.fillStyle = "rgba(" + (Math.random() > .5 ? "255,240,215," : "18,9,5,") + (Math.random() * a).toFixed(3) + ")";
      x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2.2, 1 + Math.random() * 2.2);
    }
  }

  /* ---------------- textures ---------------- */
  var TEX = U.TEX = {};
  function buildTextures() {
    /* v100：地下重鋪 — 舊版只畫咗 1024 畫布嘅左上 512×512（4×4 格），其餘四分之三
       係黑色，現場睇落係深淺大格交錯；家下畫滿成張，4×4 格、每格約 0.8 米石面。
       置中：offset 設 (0.125, 0.125)，令中軸線行磚心（磚格正中），唔踩磚縫，
       成條由門口到神壇嘅中軸都對正磚心。 */
    TEX.floor = cvs(1024, 1024, function (x, w, h) {
      var s = 256, i, j, k;
      for (i = 0; i < 4; i++) for (j = 0; j < 4; j++) {
        var v = 61 + Math.random() * 9;   /* 格加大後收窄色差，免得大格拼花太搶眼 */
        x.fillStyle = "rgb(" + (v + 12) + "," + (v + 7) + "," + (v + 1) + ")";
        x.fillRect(i * s, j * s, s, s);
      }
      speckle(x, w, h, 5200, .16);
      x.strokeStyle = "rgba(20,12,7,.78)"; x.lineWidth = 3;
      for (k = 0; k <= 4; k++) {
        x.beginPath(); x.moveTo(k * s, 0); x.lineTo(k * s, h); x.stroke();
        x.beginPath(); x.moveTo(0, k * s); x.lineTo(w, k * s); x.stroke();
      }
      x.strokeStyle = "rgba(255,238,210,.07)"; x.lineWidth = 1;
      for (k = 0; k <= 4; k++) { x.beginPath(); x.moveTo(k * s + 3, 0); x.lineTo(k * s + 3, h); x.stroke(); }
    });
    TEX.floor.wrapS = TEX.floor.wrapT = T.RepeatWrapping; TEX.floor.repeat.set(4, 5);        /* v100.1：格加大 — 22/4/4=1.38m × 26/5/4=1.30m 大石面，較大氣 */
    TEX.floor.offset.set(0.125, 0.125);   /* v100：地下置中 — 殿中心對正磚格正中 */

    TEX.granite = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#8d8678"; x.fillRect(0, 0, w, h); speckle(x, w, h, 3000, .3);
      for (var i = 0; i < 12; i++) { x.fillStyle = "rgba(40,36,30,.13)"; x.fillRect(0, Math.random() * h, w, 1); }
    });
    TEX.granite.wrapS = TEX.granite.wrapT = T.RepeatWrapping; TEX.granite.repeat.set(2, 3);

    TEX.lacquer = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#8d1f14"; x.fillRect(0, 0, w, h);
      for (var i = 0; i < 40; i++) {
        x.strokeStyle = "rgba(" + (Math.random() > .5 ? "60,10,6," : "255,140,90,") + (Math.random() * .05).toFixed(3) + ")";
        x.lineWidth = 1 + Math.random() * 6; x.beginPath();
        x.moveTo(Math.random() * w, 0); x.bezierCurveTo(Math.random() * w, h * .4, Math.random() * w, h * .7, Math.random() * w, h); x.stroke();
      }
      speckle(x, w, h, 500, .12);
    });
    TEX.lacquer.wrapS = TEX.lacquer.wrapT = T.RepeatWrapping; TEX.lacquer.repeat.set(2, 2);

    TEX.wood = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#552214"; x.fillRect(0, 0, w, h);
      for (var i = 0; i < 90; i++) {
        x.strokeStyle = "rgba(" + (Math.random() > .5 ? "38,14,8," : "146,92,56,") + (Math.random() * .3).toFixed(2) + ")";
        x.lineWidth = 1 + Math.random() * 3; x.beginPath();
        var y0 = Math.random() * h;
        x.moveTo(0, y0); x.bezierCurveTo(w * .3, y0 + rnd(-8, 8), w * .7, y0 + rnd(-8, 8), w, y0 + rnd(-6, 6)); x.stroke();
      }
    });
    TEX.wood.wrapS = TEX.wood.wrapT = T.RepeatWrapping; TEX.wood.repeat.set(1, 3);

    TEX.carved = cvs(1024, 1024, function (x, w, h) {
      x.fillStyle = "#7c1a11"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "#d9ad5f"; x.lineWidth = 6; x.strokeRect(14, 14, w - 28, h - 28);
      x.lineWidth = 2; x.strokeRect(30, 30, w - 60, h - 60);
      x.lineWidth = 3.2;
      var pts = [[128, 128], [384, 128], [128, 384], [384, 384], [256, 256]];
      for (var p = 0; p < pts.length; p++) {
        var cx = pts[p][0], cy = pts[p][1];
        for (var i = 0; i < 4; i++) {
          x.beginPath(); x.arc(cx, cy, 22 + i * 15, Math.PI * (0.15 + i * .2), Math.PI * (1.35 + i * .2)); x.stroke();
        }
        x.beginPath(); x.moveTo(cx - 46, cy + 46); x.quadraticCurveTo(cx, cy + 30, cx + 46, cy + 46); x.stroke();
      }
      x.lineWidth = 1.4; x.strokeStyle = "rgba(255,220,160,.32)";
      for (var g = 0; g < 26; g++) { x.beginPath(); x.arc(rnd(40, 470), rnd(40, 470), rnd(4, 16), 0, 6.28); x.stroke(); }
    });

    TEX.lattice = cvs(512, 768, function (x, w, h) {
      x.fillStyle = "#260e08"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "#c3974a"; x.lineWidth = 5;
      for (var i = 0; i <= 6; i++) { x.beginPath(); x.moveTo(i * w / 6, 0); x.lineTo(i * w / 6, h); x.stroke(); }
      for (i = 0; i <= 9; i++) { x.beginPath(); x.moveTo(0, i * h / 9); x.lineTo(w, i * h / 9); x.stroke(); }
      x.lineWidth = 2.2; x.strokeStyle = "rgba(214,170,96,.7)";
      for (var a = 0; a < 6; a++) for (var b = 0; b < 9; b++) x.strokeRect(a * w / 6 + 7, b * h / 9 + 7, w / 6 - 14, h / 9 - 14);
    });

    TEX.roof = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#2f2a26"; x.fillRect(0, 0, w, h);
      for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++) {
        var cx = c * 32 + (r % 2 ? 16 : 0), cy = r * 32;
        x.fillStyle = "rgb(" + Math.round(58 + Math.random() * 16) + "," + Math.round(52 + Math.random() * 14) + "," + Math.round(46 + Math.random() * 12) + ")";
        x.beginPath(); x.arc(cx, cy + 24, 20, Math.PI, 0); x.fill();
        x.strokeStyle = "rgba(0,0,0,.5)"; x.lineWidth = 2; x.stroke();
      }
    });
    TEX.roof.wrapS = TEX.roof.wrapT = T.RepeatWrapping; TEX.roof.repeat.set(6, 3);

    TEX.jade = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#2c4438"; x.fillRect(0, 0, w, h);
      for (var r = 0; r < 8; r++) for (var c = 0; c < 10; c++) {
        var cx = c * 26 + (r % 2 ? 13 : 0), cy = r * 26;
        x.fillStyle = "rgb(" + Math.round(56 + Math.random() * 22) + "," + Math.round(84 + Math.random() * 22) + "," + Math.round(68 + Math.random() * 18) + ")";
        x.beginPath(); x.arc(cx, cy + 20, 16, Math.PI, 0); x.fill();
        x.strokeStyle = "rgba(0,0,0,.35)"; x.lineWidth = 1.5; x.stroke();
      }
    });
    TEX.jade.wrapS = TEX.jade.wrapT = T.RepeatWrapping; TEX.jade.repeat.set(4, 2);

    TEX.brocadeRed = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#6d1109"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "rgba(232,190,110,.6)"; x.lineWidth = 2;
      for (var i = 0; i < 9; i++) for (var j = 0; j < 9; j++) {
        var cx = i * 28 + 14, cy = j * 28 + 14;
        x.beginPath(); x.arc(cx, cy, 7, 0, 6.28); x.stroke();
        x.beginPath(); x.moveTo(cx - 10, cy); x.lineTo(cx, cy - 10); x.lineTo(cx + 10, cy); x.lineTo(cx, cy + 10); x.closePath(); x.stroke();
      }
    });
    TEX.brocadeRed.wrapS = TEX.brocadeRed.wrapT = T.RepeatWrapping; TEX.brocadeRed.repeat.set(2, 2);

    TEX.brocade = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#123a2c"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "rgba(226,190,110,.5)"; x.lineWidth = 2;
      for (var i = 0; i < 9; i++) for (var j = 0; j < 9; j++) {
        var cx = i * 28 + 14, cy = j * 28 + 14;
        x.beginPath(); x.arc(cx, cy, 7, 0, 6.28); x.stroke();
        x.beginPath(); x.moveTo(cx - 10, cy); x.lineTo(cx, cy - 10); x.lineTo(cx + 10, cy); x.lineTo(cx, cy + 10); x.closePath(); x.stroke();
      }
    });
    TEX.brocade.wrapS = TEX.brocade.wrapT = T.RepeatWrapping; TEX.brocade.repeat.set(2, 2);

    TEX.smoke = cvs(64, 64, function (x) {
      var g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, "rgba(255,246,228,.8)"); g.addColorStop(.35, "rgba(236,216,188,.36)"); g.addColorStop(1, "rgba(222,202,172,0)");
      x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    });
    TEX.glow = cvs(64, 64, function (x) {
      var g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, "rgba(255,230,170,1)"); g.addColorStop(.24, "rgba(255,190,90,.6)"); g.addColorStop(1, "rgba(255,150,40,0)");
      x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    });
    TEX.flame = cvs(64, 96, function (x) {
      var g = x.createRadialGradient(32, 62, 2, 32, 58, 34);
      g.addColorStop(0, "rgba(255,250,225,1)"); g.addColorStop(.3, "rgba(255,208,116,.9)");
      g.addColorStop(.65, "rgba(255,140,40,.42)"); g.addColorStop(1, "rgba(255,90,10,0)");
      x.fillStyle = g; x.beginPath(); x.ellipse(32, 60, 19, 34, 0, 0, 6.28); x.fill();
    });
    TEX.dust = cvs(32, 32, function (x) {
      var g = x.createRadialGradient(16, 16, 0, 16, 16, 16);
      g.addColorStop(0, "rgba(255,238,200,.9)"); g.addColorStop(1, "rgba(255,238,200,0)");
      x.fillStyle = g; x.fillRect(0, 0, 32, 32);
    });

    /* ---- v95：鎏金 / 瓷器 / 果皮 / 竹紋 — 程序化貼圖（零外部資源） ---- */
    /* 鎏金：拉絲 + 錘揲凹點 + 暗處銅綠舊化，bump 共用同一張 */
    TEX.gold = cvs(512, 512, function (x, w, h) {
      var lg = x.createLinearGradient(0, 0, w, h);
      lg.addColorStop(0, "#d9b25e"); lg.addColorStop(.35, "#c39a3e"); lg.addColorStop(.62, "#e6c87e"); lg.addColorStop(1, "#b8892f");
      x.fillStyle = lg; x.fillRect(0, 0, w, h);
      var i;
      for (i = 0; i < 260; i++) { /* 拉絲 */
        x.strokeStyle = "rgba(" + (Math.random() > .5 ? "255,236,180," : "110,74,16,") + (Math.random() * .12).toFixed(3) + ")";
        x.lineWidth = .6 + Math.random() * 1.4;
        var y0 = Math.random() * h; x.beginPath(); x.moveTo(0, y0); x.lineTo(w, y0 + rnd(-6, 6)); x.stroke();
      }
      for (i = 0; i < 340; i++) { /* 錘揲凹點：亮邊 + 暗心 */
        var cx = Math.random() * w, cy = Math.random() * h, r = 3 + Math.random() * 9;
        var g2 = x.createRadialGradient(cx, cy, 0, cx, cy, r);
        g2.addColorStop(0, "rgba(90,58,10,.28)"); g2.addColorStop(.7, "rgba(255,238,190,.10)"); g2.addColorStop(1, "rgba(255,238,190,0)");
        x.fillStyle = g2; x.beginPath(); x.arc(cx, cy, r, 0, 6.28); x.fill();
      }
      for (i = 0; i < 90; i++) { /* 舊化暗斑（只在邊角感位置） */
        x.fillStyle = "rgba(74,48,8," + (Math.random() * .14).toFixed(3) + ")";
        x.beginPath(); x.ellipse(Math.random() * w, Math.random() * h, rnd(2, 9), rnd(1, 4), rnd(0, 3), 0, 6.28); x.fill();
      }
      speckle(x, w, h, 420, .08);
    });
    TEX.gold.wrapS = TEX.gold.wrapT = T.RepeatWrapping; TEX.gold.repeat.set(2, 2);
    /* ---- v98：金鹿專用做舊金箔 — 真鹿唔係均勻亮金，係深銅底 + 不規則金箔貼片，
       身同臀部尤其舊（大片深銅見底），面、頸、腿、鹿角金多啲但一樣有斑駁。
       全廟共用嘅 TEX.gold 唔郁，只係鹿身用呢張。bump 共用同一張，貼片邊有微微浮起。 */
    TEX.deerGold = cvs(512, 512, function (x, w, h) {
      /* v98.1：貼片密度提升到約 95% — 抖動網格鋪滿金箔（每格略大於格距，互相疊邊），
         只留約 5% 深銅底做接縫同零星缺箔。用固定種子 PRNG，覆蓋率可重複量度。 */
      var s = 0x9e3779b9;
      function r2() { s = (s * 1664525 + 1013904223) & 0xffffffff; return (s >>> 8) / 16777216; }
      var bg = x.createLinearGradient(0, 0, w, h);
      bg.addColorStop(0, "#3a2a16"); bg.addColorStop(.5, "#2e2113"); bg.addColorStop(1, "#41301a");
      x.fillStyle = bg; x.fillRect(0, 0, w, h);
      var i;
      for (i = 0; i < 14; i++) { /* 深銅舊化（只喺缺箔/接縫位見到） */
        var cx = r2() * w, cy = r2() * h, r = 30 + r2() * 90;
        var g2 = x.createRadialGradient(cx, cy, 0, cx, cy, r);
        g2.addColorStop(0, "rgba(24,16,8,.55)"); g2.addColorStop(1, "rgba(24,16,8,0)");
        x.fillStyle = g2; x.beginPath(); x.arc(cx, cy, r, 0, 6.28); x.fill();
      }
      var shades = ["#d9b25e", "#c9a24e", "#e6c87e", "#b8892f", "#e8c268", "#cfa54e"];
      var N = 18, cs = w / N;
      for (var gy = 0; gy < N; gy++) for (var gx = 0; gx < N; gx++) {
        var pw = cs * (1.10 + r2() * .16), ph = cs * (1.10 + r2() * .16);
        var px = gx * cs + cs / 2 + (r2() - .5) * 5, py = gy * cs + cs / 2 + (r2() - .5) * 5;
        var pa = (r2() - .5) * .16;
        x.save(); x.translate(px, py); x.rotate(pa);
        x.fillStyle = shades[Math.floor(r2() * shades.length)];
        x.globalAlpha = .94 + r2() * .06;
        x.fillRect(-pw / 2, -ph / 2, pw, ph);
        x.globalAlpha = 1; x.strokeStyle = "rgba(40,26,8,.30)"; x.lineWidth = 1;
        x.strokeRect(-pw / 2, -ph / 2, pw, ph);
        x.restore();
      }
      /* 缺箔：零星撕走幾小塊見銅底（保留約 5% 破舊感） */
      for (i = 0; i < 17; i++) {
        x.save(); x.globalAlpha = .95;
        x.fillStyle = ["#2e2113", "#3a2a16"][i % 2];
        x.beginPath(); x.ellipse(r2() * w, r2() * h, 9 + r2() * 17, 7 + r2() * 13, r2() * 3, 0, 6.28); x.fill();
        x.restore();
      }
      for (i = 0; i < 90; i++) { /* 磨損刮痕（淡，唔再壓過金箔） */
        x.strokeStyle = "rgba(20,14,6," + (r2() * .18).toFixed(3) + ")";
        x.lineWidth = .7 + r2();
        var y0 = r2() * h; x.beginPath(); x.moveTo(r2() * w, y0);
        x.lineTo(r2() * w, y0 + (r2() - .5) * 28); x.stroke();
      }
      speckle(x, w, h, 300, .08);
    });
    TEX.deerGold.wrapS = TEX.deerGold.wrapT = T.RepeatWrapping; TEX.deerGold.repeat.set(2, 2);
    /* ---- v98：回紋邊帶 — 金鹿台座石材邊帶用，單行回紋，橫向重複 ---- */
    TEX.fret = cvs(512, 128, function (x, w, h) {
      x.fillStyle = "#6b6258"; x.fillRect(0, 0, w, h);
      for (var i = 0; i < 260; i++) {
        x.fillStyle = "rgba(30,26,20," + (Math.random() * .12).toFixed(3) + ")";
        x.beginPath(); x.ellipse(Math.random() * w, Math.random() * h, rnd(2, 8), rnd(1, 4), rnd(0, 3), 0, 6.28); x.fill();
      }
      x.strokeStyle = "#8a8175"; x.lineWidth = 7; x.lineJoin = "miter";
      for (var tx = 0; tx < w; tx += 64) {
        x.beginPath();
        x.moveTo(tx + 4, 104); x.lineTo(tx + 4, 32); x.lineTo(tx + 44, 32);
        x.lineTo(tx + 44, 76); x.lineTo(tx + 18, 76); x.lineTo(tx + 18, 52); x.lineTo(tx + 34, 52);
        x.stroke();
      }
      x.strokeStyle = "rgba(30,26,20,.5)"; x.lineWidth = 2;
      x.strokeRect(1, 8, w - 2, h - 16);
    });
    TEX.fret.wrapS = TEX.fret.wrapT = T.RepeatWrapping; TEX.fret.repeat.set(3, 1);
    /* 青花瓷：白底 + 藍花邊 + 細冰裂紋 */
    TEX.porcelain = cvs(512, 512, function (x, w, h) {
      x.fillStyle = "#f4efe4"; x.fillRect(0, 0, w, h);
      x.strokeStyle = "rgba(42,74,122,.85)"; x.lineWidth = 5;
      x.beginPath(); x.arc(w / 2, h / 2, 196, 0, 6.28); x.stroke();
      x.lineWidth = 2; x.beginPath(); x.arc(w / 2, h / 2, 176, 0, 6.28); x.stroke();
      for (var i = 0; i < 12; i++) {
        var a = i / 12 * Math.PI * 2;
        var px = w / 2 + Math.cos(a) * 186, py = h / 2 + Math.sin(a) * 186;
        x.fillStyle = "rgba(42,74,122,.75)";
        x.beginPath(); x.ellipse(px, py, 13, 7, a, 0, 6.28); x.fill();
      }
      x.strokeStyle = "rgba(120,110,90,.18)"; x.lineWidth = 1;
      for (var j = 0; j < 26; j++) {
        x.beginPath(); var sx = Math.random() * w, sy = Math.random() * h;
        x.moveTo(sx, sy); x.lineTo(sx + rnd(-28, 28), sy + rnd(-28, 28)); x.stroke();
      }
      speckle(x, w, h, 260, .05);
    });
    /* 橙皮：橙底 + 凹點 + 油胞亮點 */
    TEX.orange = cvs(256, 256, function (x, w, h) {
      x.fillStyle = "#e07d1d"; x.fillRect(0, 0, w, h);
      for (var i = 0; i < 900; i++) {
        x.fillStyle = Math.random() > .5 ? "rgba(120,52,6,.28)" : "rgba(255,196,110,.30)";
        x.beginPath(); x.arc(Math.random() * w, Math.random() * h, .8 + Math.random() * 1.6, 0, 6.28); x.fill();
      }
      var g3 = x.createRadialGradient(70, 70, 10, 128, 128, 190);
      g3.addColorStop(0, "rgba(255,220,150,.28)"); g3.addColorStop(1, "rgba(255,220,150,0)");
      x.fillStyle = g3; x.fillRect(0, 0, w, h);
    });
    TEX.orange.wrapS = TEX.orange.wrapT = T.RepeatWrapping;
    /* 竹：縱紋 + 竹節橫線 */
    TEX.bamboo = cvs(256, 512, function (x, w, h) {
      x.fillStyle = "#8a6a30"; x.fillRect(0, 0, w, h);
      for (var i = 0; i < 70; i++) {
        x.strokeStyle = "rgba(" + (Math.random() > .5 ? "60,40,12," : "214,178,110,") + (Math.random() * .22).toFixed(2) + ")";
        x.lineWidth = .8 + Math.random() * 2;
        var x0 = Math.random() * w; x.beginPath(); x.moveTo(x0, 0); x.lineTo(x0 + rnd(-8, 8), h); x.stroke();
      }
      x.fillStyle = "rgba(52,34,10,.55)"; x.fillRect(0, 120, w, 7); x.fillRect(0, 330, w, 7);
      x.fillStyle = "rgba(240,210,150,.28)"; x.fillRect(0, 127, w, 2); x.fillRect(0, 337, w, 2);
    });
    TEX.bamboo.wrapS = TEX.bamboo.wrapT = T.RepeatWrapping;

    /* ---- v95：程序化環境貼圖（CubeTexture，r128 用 envMap）---- */
    /* 六面分別是：右牆燈光暖光 / 左牆深紅 / 天花暖光 / 地面暗 / 門口日光冷 / 神壇暖光。
       金屬沒有 envMap 會發死黑，有咗之後金鹿、銅爐、金器先有真實反光層次。 */
    (function buildEnv() {
      function face(base, hi, spot) {
        var c = document.createElement("canvas"); c.width = 128; c.height = 128;
        var x = c.getContext("2d");
        var g = x.createLinearGradient(0, 0, 128, 128);
        g.addColorStop(0, hi); g.addColorStop(1, base); x.fillStyle = g; x.fillRect(0, 0, 128, 128);
        if (spot) {
          var rg = x.createRadialGradient(64, 64, 4, 64, 64, 62);
          rg.addColorStop(0, spot); rg.addColorStop(1, "rgba(255,255,255,0)");
          x.fillStyle = rg; x.fillRect(0, 0, 128, 128);
        }
        return c;
      }
      var faces = [
        face("#7a3a12", "#ffb46a", "rgba(255,190,110,.9)"),  /* +X 右 */
        face("#3a0d06", "#8e1c14", "rgba(200,80,40,.35)"),   /* -X 左 */
        face("#8a5a20", "#ffd9a0", "rgba(255,220,160,.95)"), /* +Y 天花 */
        face("#120a06", "#2a1a10", null),                    /* -Y 地 */
        face("#5a6a7a", "#b8cfe0", "rgba(220,235,245,.8)"),  /* +Z 門口 */
        face("#6d1a12", "#ff9a4a", "rgba(255,170,90,.9)")    /* -Z 神壇 */
      ];
      var env = new T.CubeTexture(faces); env.needsUpdate = true;
      U.ENV = env;
    })();
  }

  function textTexture(text, opt) {
    opt = opt || {};
    var fs = opt.size || 96, pad = opt.pad || 24, vertical = !!opt.vertical;
    var c = document.createElement("canvas"), x, w, h;
    if (vertical) {
      w = fs + pad * 2; h = (fs + pad * .35) * text.length + pad * 2;
      c.width = w; c.height = h; x = c.getContext("2d");
      if (opt.bg) { x.fillStyle = opt.bg; x.fillRect(0, 0, w, h); }
      x.font = "700 " + fs + "px " + (opt.font || SERIF);
      x.textAlign = "center"; x.textBaseline = "middle"; x.fillStyle = opt.color || "#e8bd6e";
      if (opt.glow) { x.shadowColor = opt.color || "#e8bd6e"; x.shadowBlur = 20; }
      for (var i = 0; i < text.length; i++) x.fillText(text[i], w / 2, pad + fs * .56 + i * (fs + pad * .35));
    } else {
      x = c.getContext("2d");
      x.font = "700 " + fs + "px " + (opt.font || SERIF);
      w = Math.ceil(x.measureText(text).width) + pad * 2; h = fs + pad * 2;
      c.width = w; c.height = h; x = c.getContext("2d");
      if (opt.bg) { x.fillStyle = opt.bg; x.fillRect(0, 0, w, h); }
      x.font = "700 " + fs + "px " + (opt.font || SERIF);
      x.textAlign = "center"; x.textBaseline = "middle"; x.fillStyle = opt.color || "#e8bd6e";
      if (opt.glow) { x.shadowColor = opt.color || "#e8bd6e"; x.shadowBlur = 16; }
      x.fillText(text, w / 2, h / 2 + fs * .04);
    }
    var t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; t.anisotropy = 8; return t;
  }

  /* ---------------- dimensions ---------------- */
  var HX = 11, HZ = 13, HH = 9.6, REAR = -8.0, PZ = 0.34;
  U.HX = HX; U.HZ = HZ; U.HH = HH; U.REAR = REAR; U.PZ = PZ;

  /* ---------------- stations ---------------- */
  var stations = U.stations = {};
  var flameLights = [];
  function addStation(id, label, x, z, face, r) {
    stations[id] = { id: id, label: label, x: x, z: z, face: face, r: r || 2.6 };
  }

  /* ---------------- smoke / particles ---------------- */
  var smokeSystems = [];
  function makeSmoke(n, opts) {
    opts = opts || {};
    var geo = new T.BufferGeometry();
    var pos = new Float32Array(n * 3), seed = new Float32Array(n * 4);
    for (var i = 0; i < n; i++) {
      seed[i * 4] = Math.random(); seed[i * 4 + 1] = rnd(0.4, 1.2);
      seed[i * 4 + 2] = rnd(0, 6.28); seed[i * 4 + 3] = rnd(0, 1);
    }
    geo.setAttribute("position", new T.BufferAttribute(pos, 3));
    var m = new T.PointsMaterial({
      size: opts.size || .34, map: TEX.smoke, transparent: true, opacity: opts.opacity || .22,
      depthWrite: false, blending: T.AdditiveBlending, color: new T.Color(opts.color || "#d9c3a4"),
      sizeAttenuation: true
    });
    var p = new T.Points(geo, m);
    p.frustumCulled = false; scene.add(p);
    var sys = { points: p, geo: geo, n: n, seed: seed, base: opts.base || new T.Vector3(),
      rise: opts.rise || 1.6, spread: opts.spread || .5, speed: opts.speed || .25, phase: Math.random() * 10, init: false };
    smokeSystems.push(sys); return sys;
  }

  /* ---------------- architecture ---------------- */
  var lanterns = [], coilGroups = [], beams = [];
  function buildShell() {
    /* ---- floor & platform ---- */
    var fl = plane(HX * 2, HZ * 2, new T.MeshStandardMaterial({ map: TEX.floor, bumpMap: TEX.floor, bumpScale: .03, roughness: .42, metalness: .02 }), 0, 0, 0);
    fl.rotation.x = -Math.PI / 2; fl.receiveShadow = true;
    var rear = box(HX * 2, PZ, 5.0, mat("#6b5a45", { map: TEX.granite, roughness: .8 }), 0, PZ / 2, (REAR - 13) / 2);
    /* 神壇石階：三級闊面石階，由殿中央拾級而上才到文武二帝像 */
    for (var s = 0; s < 3; s++) {
      var sw = 9.4 - s * .5, sz = REAR + .22 + s * .44;
      box(sw, .11, .44, mat("#7d7261", { map: TEX.granite, roughness: .85 }), 0, PZ - .055 - s * .11, sz);
      box(sw, .012, .05, gold(), 0, PZ - s * .11, sz + .24);
    }

    /* ---- walls ---- */
    var wallMat = new T.MeshStandardMaterial({ map: TEX.lacquer, bumpMap: TEX.lacquer, bumpScale: .015, roughness: .72, metalness: .04 });
    var plaster = mat("#d8c9ae", { roughness: .95 });
    /* back wall */
    box(HX * 2, HH, .4, wallMat, 0, HH / 2, -HZ);
    /* side walls: piers + lattice window band */
    [-1, 1].forEach(function (side) {
      var x = side * HX;
      box(.4, HH, HZ * 2, wallMat, x, HH / 2, 0);
      /* granite base course */
      box(.5, .9, HZ * 2, mat("#8a8274", { map: TEX.granite, roughness: .9 }), x + side * .03, .45, 0);
      /* lattice windows */
      for (var zi = -10.6; zi <= 10.4; zi += 3.4) {
        if (side > 0 && zi > -5.6 && zi < 0.8) continue; /* 光明燈牆位置留空，唔放格扇窗 */
        var win = plane(2.4, 2.5, new T.MeshStandardMaterial({ map: TEX.lattice, roughness: .8, transparent: true }), x - side * .21, 3.0, zi);
        win.rotation.y = -side * Math.PI / 2;
        box(.14, .16, 2.7, gold(), x - side * .16, 4.3, zi);
        box(.14, .16, 2.7, gold(), x - side * .16, 1.72, zi);
      }
    });
    /* ---- 金線腰帶 + 壁板 ---- */
    [-1, 1].forEach(function (side) {
      var xx = side * (HX - .24);
      box(.1, .16, HZ * 2 - .6, gold(), xx, 4.62, 0);
      if (side < 0) box(.1, .1, HZ * 2 - .6, mat("#7a1a11"), xx, 1.58, 0); /* 右牆留空：光明燈牆前不可有腰線 */
      for (var zi = -9.2; zi <= 10; zi += 3.4) {
        if (side > 0 && zi > -5.6 && zi < 0.8) continue; /* 光明燈牆位置留空，唔放格扇窗 */
        var pn = plane(2.7, 2.2, new T.MeshStandardMaterial({ map: TEX.carved, roughness: .62, metalness: .1 }), xx - side * .04, 6.6, zi);
        pn.rotation.y = -side * Math.PI / 2;
        box(.16, 2.4, .16, gold(), xx - side * .05, 6.6, zi - 1.42);
        box(.16, 2.4, .16, gold(), xx - side * .05, 6.6, zi + 1.42);
      }
    });

    /* front wall with door opening */
    box(7.6, HH, .4, wallMat, -7.2, HH / 2, HZ);
    box(7.6, HH, .4, wallMat, 7.2, HH / 2, HZ);
    box(6.2, HH - 4.8, .4, wallMat, 0, 4.8 + (HH - 4.8) / 2, HZ);
    /* door frame, granite */
    box(.55, 4.9, .62, mat("#8f8677", { map: TEX.granite, roughness: .88 }), -3.3, 2.45, HZ);
    box(.55, 4.9, .62, mat("#8f8677", { map: TEX.granite, roughness: .88 }), 3.3, 2.45, HZ);
    box(7.2, .5, .66, gold(), 0, 4.95, HZ);
    /* 擋中 screen */
    var scr = box(3.2, 2.3, .16, new T.MeshStandardMaterial({ map: TEX.carved, roughness: .55, metalness: .18 }), 0, 1.28, HZ - 2.4);
    box(3.5, .18, .3, gold(), 0, 2.37, HZ - 2.4);
    box(3.5, .18, .3, gold(), 0, .12, HZ - 2.4);

    /* ---- ceiling: coffered 藻井 over 天井 + flat ceilings ---- */
    var ceilMat = mat("#251009", { roughness: .92 });
    box(HX * 2, .3, 6.6, ceilMat, 0, HH, -9.7);
    box(HX * 2, .3, 6.2, ceilMat, 0, HH, 9.9);
    /* raised coffer over the light well */
    box(12.8, .26, 8.6, ceilMat, 0, HH + 1.15, 2.4);
    for (var i = 0; i < 4; i++) {
      box(12.9, .2, .22, gold(), 0, HH + .95, -1.7 + i * 2.4);
      box(.22, .2, 8.7, gold(), -5 + i * 3.33, HH + .95, 2.4);
    }
    /* 藻井：中央圓形天花 */
    var wellG = new T.Group(); wellG.position.set(0, HH + 1.1, 2.4); scene.add(wellG);
    var cpanel = new T.Mesh(new T.CircleGeometry(2.6, 40), new T.MeshStandardMaterial({ map: TEX.carved, roughness: .7, metalness: .12, side: T.DoubleSide }));
    cpanel.rotation.x = Math.PI / 2; wellG.add(cpanel);
    for (var ring = 1; ring <= 3; ring++) {
      var rr = new T.Mesh(new T.TorusGeometry(ring * .72, .05, 8, 40), gold());
      rr.rotation.x = Math.PI / 2; rr.position.y = -.02; wellG.add(rr);
    }
    var wl = new T.PointLight(0xffc27a, .55, 12, 2); wl.position.set(0, HH + .2, 2.4); scene.add(wl);
    var bigLantern = makeLantern(0, 7.9, 2.4, 1.45); lanterns.push(bigLantern);

    /* beams */
    var beamMat = new T.MeshStandardMaterial({ map: TEX.wood, roughness: .8 });
    [-7.5, -3.4, 4.2, 8.6, 12.2].forEach(function (z) {
      box(HX * 2, .52, .38, beamMat, 0, HH - .5, z);
      box(HX * 2, .12, .46, mat("#8e1c14"), 0, HH - .78, z);
    });
    [-9.4, -6.4, -4.6, 4.6, 6.4, 9.4].forEach(function (x) { box(.28, .32, HZ * 2, beamMat, x, HH - .95, 0); });

    /* ---- 天井 granite columns (from the covered courtyard) ---- */
    var colMat = new T.MeshStandardMaterial({ map: TEX.granite, bumpMap: TEX.granite, bumpScale: .04, roughness: .85 });
    [[-6.4, 4.4], [6.4, 4.4], [-6.4, -1.4], [6.4, -1.4]].forEach(function (p) {
      box(.86, .42, .86, colMat, p[0], .21, p[1]);
      cyl(.27, .31, HH - .55, colMat, p[0], .45 + (HH - .55) / 2, p[1], null, 16);
      box(.76, .18, .76, colMat, p[0], HH - .1, p[1]);
    });
    /* ---- red columns with gold couplets near the altar ---- */
    var redCol = new T.MeshStandardMaterial({ map: TEX.lacquer, roughness: .45, metalness: .12 });
    [[-5.4, -6.2], [5.4, -6.2], [-8.6, -7.6], [8.6, -7.6]].forEach(function (p) {
      box(1.05, .4, 1.05, colMat, p[0], .2, p[1]);
      cyl(.42, .47, HH - .6, redCol, p[0], .4 + (HH - .6) / 2, p[1], null, 18);
      box(1.0, .22, 1.0, gold(), p[0], .52, p[1]);
    });
    var cp1 = textTexture("文德昭明光日月", { size: 54, vertical: true, color: "#f0c97e" });
    var cp2 = textTexture("武威赫濯壯山河", { size: 54, vertical: true, color: "#f0c97e" });
    [-1, 1].forEach(function (side, i) {
      /* 參拜者面向神壇：左武帝聯、右文帝聯。 */
      var m = new T.MeshBasicMaterial({ map: i ? cp1 : cp2, transparent: true });
      var pl = plane(.66, 3.6, m, side * 5.4, 3.3, -6.2 + .48);
      pl.rotation.y = 0;
    });

    /* ---- green tiled roof over the entrance bay (seen from courtyard) ---- */
    buildRoof(13.6, 6.4, 2.2, 0, HH + .5, HZ + 1.4, 0);
    buildRoof(9.4, 4.2, 1.4, 0, HH + 2.2, HZ - .6, 0);
    /* 重檐：入口下層屋檐（從廟埕望上去最搶眼） */
    var jade = new T.MeshStandardMaterial({ map: TEX.jade, roughness: .55, metalness: .18 });
    var eave = box(14.2, .26, 3.0, jade, 0, 6.55, 13.9);
    eave.rotation.x = -.26;
    box(14.4, .16, .34, mat("#20302a"), 0, 6.86, 12.45);
    [-1, 1].forEach(function (sd) {
      var up = box(1.9, .2, 2.4, jade, sd * 7.0, 7.0, 13.9); up.rotation.z = sd * .5; up.rotation.x = -.2;
      box(.5, .22, .5, mat("#c9a24e", { metalness: .7, roughness: .4 }), sd * 7.0, 7.35, 14.2);
    });
    /* 脊上陶塑剪影 */
    for (var oi = -2; oi <= 2; oi++) {
      box(.34, .5, .2, mat("#2c4a3c", { roughness: .6 }), oi * 1.6, 7.0, 12.5);
    }

    /* 夜空星點 */
    var sg = new T.BufferGeometry(), sp2 = new Float32Array(1200);
    for (var si = 0; si < 400; si++) {
      var th = Math.random() * Math.PI * 2, ph = Math.random() * .55 + .05, R = 100;
      sp2[si * 3] = Math.cos(th) * Math.cos(ph) * R;
      sp2[si * 3 + 1] = Math.sin(ph) * R + 4;
      sp2[si * 3 + 2] = Math.sin(th) * Math.cos(ph) * R;
    }
    sg.setAttribute("position", new T.BufferAttribute(sp2, 3));
    var stars = new T.Points(sg, new T.PointsMaterial({ color: 0xffe9c8, size: .55, sizeAttenuation: true, transparent: true, opacity: .75, depthWrite: false, fog: false }));
    stars.frustumCulled = false; scene.add(stars);

    buildGodRays();

    /* ---- 匾額 ---- */
    /* 帝德同沾（光緒十九年，1893）— 入口內側，面向殿內 */
    plaque("帝德同沾", 3.5, 1.25, 0, 6.0, HZ - .52, Math.PI, -0.26);
    /* 花崗石門框刻年份 */
    var yr = new T.Mesh(new T.PlaneGeometry(.62, .3), new T.MeshBasicMaterial({ map: textTexture("道光廿七年", { size: 44, color: "#3a352c" }), transparent: true }));
    yr.position.set(-2.55, 3.75, HZ + .32); scene.add(yr);
    plaque("文武廟", 5.4, 1.7, 0, 5.72, HZ + .46, 0, 0.26);
    plaque("文昭武烈", 3.6, 1.2, 0, 7.55, -HZ + .32, 0, 0.16);
    /* v100：拆咗「神恩浩蕩」匾（後牆最左端，用戶要求移除）。 */

    /* ---- 石鼓 at the door ---- */
    [-1, 1].forEach(function (s) {
      var g = new T.Group(); g.position.set(s * 3.9, 0, HZ + .8); scene.add(g);
      box(.8, .5, .8, colMat, 0, .25, 0, g);
      mesh(new T.SphereGeometry(.62, 18, 14), colMat, 0, .95, 0, g).scale.set(1, 1.05, .55);
      cyl(.2, .2, .5, colMat, 0, 1.5, 0, g);
      mesh(new T.SphereGeometry(.26, 12, 10), colMat, 0, 1.75, 0, g);
    });

    /* ---- crockery: 香爐 in courtyard, lanterns ---- */
    buildCourtyard();
  }

  function buildGodRays() {
    var m = new T.MeshBasicMaterial({ color: 0xffd9a0, transparent: true, opacity: .02, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide });
    [-2.7, -1.7, 1.7, 2.7].forEach(function (x) {
      var p = plane(1.0, 10, m, x, 5.0, 8.2, null);
      p.rotation.x = .14; p.rotation.y = rnd(-.06, .06);
    });
  }

  function plaque(text, w, h, x, y, z, rotY, tilt) {
    var g = new T.Group(); g.position.set(x, y, z); g.rotation.y = rotY || 0; scene.add(g);
    if (tilt) g.rotateX(tilt);
    box(w + .3, h + .3, .16, gold(), 0, 0, 0, g);
    box(w, h, .2, mat("#4a0d09"), 0, 0, .02, g);
    var t = textTexture(text, { size: 120, color: "#f4cd79", glow: true, pad: 18 });
    var p = plane(w - .2, h - .2, new T.MeshBasicMaterial({ map: t, transparent: true }), 0, 0, .14, g);
    var gl = new T.Sprite(new T.SpriteMaterial({ map: TEX.glow, color: 0xffc884, transparent: true, opacity: .18, blending: T.AdditiveBlending, depthWrite: false }));
    gl.scale.set(w * 1.15, h * 1.5, 1); gl.position.z = .1; g.add(gl);
  }

  function buildRoof(w, d, h, x, y, z, rotY) {
    var g = new T.Group(); g.position.set(x, y, z); g.rotation.y = rotY || 0; scene.add(g);
    var roofMat = new T.MeshStandardMaterial({ map: TEX.jade, roughness: .62, metalness: .12 });
    var slope = Math.hypot(w / 2, h) + .5, ang = Math.atan2(h, w / 2);
    [-1, 1].forEach(function (s) {
      var r = box(slope, .18, d, roofMat, s * w / 4, h / 2, 0, g);
      r.rotation.z = -s * ang;
    });
    box(.5, .3, d + .4, mat("#20302a"), 0, h + .1, 0, g);
    /* upturned eave ends */
    [-1, 1].forEach(function (s) {
      var e = box(1.2, .16, d + .5, roofMat, s * (w / 2 - .1), h * .06 + .06, 0, g);
      e.rotation.z = s * .42;
    });
  }

  /* ---------------- courtyard (廟前) ---------------- */
  function buildCourtyard() {
    var ground = box(46, .3, 34, mat("#5b5347", { map: TEX.granite, roughness: .95 }), 0, -.16, 20);
    ground.receiveShadow = true;
    /* boundary wall + gate */
    var wallMat = mat("#d9cbb1", { roughness: .95 });
    [-1, 1].forEach(function (s) {
      box(18, 3.2, .5, wallMat, s * 14.2, 1.6, 24.5);
      box(18.4, .3, .9, mat("#2c4438"), s * 14.2, 3.3, 24.5);
    });
    /* 天公爐 */
    var g = new T.Group(); g.position.set(0, 0, 16.6); g.scale.setScalar(.85); scene.add(g);
    box(2.2, .35, 2.2, mat("#6f6759", { map: TEX.granite }), 0, .18, 0, g);
    cyl(.5, .62, 1.15, mat("#5d4a2f", { metalness: .7, roughness: .42 }), 0, .95, 0, g, 22);
    cyl(.62, .58, .18, gold(), 0, 1.6, 0, g, 22);
    for (var i = 0; i < 3; i++) cyl(.07, .09, .6, mat("#4a3a22", { metalness: .7 }), Math.cos(i * 2.1) * .4, .3, Math.sin(i * 2.1) * .4, g, 8);
    /* incense sticks */
    for (var k = 0; k < 7; k++) {
      var st = cyl(.012, .012, .5, mat("#8b5a2b"), rnd(-.22, .22), 1.75, rnd(-.22, .22), g, 5);
      mesh(new T.SphereGeometry(.018, 5, 4), new T.MeshBasicMaterial({ color: 0xff8a3d }), rnd(-.22, .22), 2.0, rnd(-.22, .22), g);
    }
    /* lanterns at the gate */
    lanterns.push(makeLantern(-4.6, 4.6, 13.9, 1.0));
    lanterns.push(makeLantern(4.6, 4.6, 13.9, 1.0));
    lanterns.push(makeLantern(-4.6, 4.6, 20.4, .9));
    lanterns.push(makeLantern(4.6, 4.6, 20.4, .9));
    lanterns.push(makeLantern(-5.2, 5.4, 0.2, .95));
    lanterns.push(makeLantern(5.2, 5.4, 0.2, .95));
  }

  function makeLantern(x, y, z, k) {
    var g = new T.Group(); g.position.set(x, y, z); scene.add(g);
    var bodyMat = new T.MeshStandardMaterial({ color: new T.Color("#a8231a"), roughness: .55, emissive: new T.Color("#7a1008"), emissiveIntensity: .55 });
    var b = mesh(new T.SphereGeometry(.34, 16, 12), bodyMat, 0, 0, 0, g); b.scale.set(1, 1.18, 1);
    cyl(.14, .16, .1, gold(), 0, .4, 0, g, 10);
    cyl(.14, .16, .1, gold(), 0, -.4, 0, g, 10);
    var tas = cyl(.03, .12, .55, mat("#b8331f", { emissive: "#5a0d05", emissiveIntensity: .4 }), 0, -.72, 0, g, 8);
    var spr = new T.Sprite(new T.SpriteMaterial({ map: TEX.glow, color: 0xffb46a, transparent: true, opacity: .45, blending: T.AdditiveBlending, depthWrite: false }));
    spr.scale.setScalar(2.2 * k); g.add(spr);
    g.scale.setScalar(k); g.userData.baseY = y; g.userData.ph = Math.random() * 6.28;
    return g;
  }

  /* ---------------- 塔香 (spiral incense coils) ---------------- */
  class CoilCurve extends T.Curve {
    constructor(R, H, turns) { super(); this.R = R; this.H = H; this.turns = turns; }
    getPoint(t) {
      /* 塔香正立：上尖下闊（似塔），t=0 在頂、t=1 在底 */
      var r = this.R * (.28 + t * .72), a = this.turns * Math.PI * 2 * t;
      return new T.Vector3(Math.cos(a) * r, -t * this.H, Math.sin(a) * r);
    }
  }

  function buildCoils() {
    var geo = new T.TubeGeometry(new CoilCurve(.78, 1.95, 9), 180, .05, 6, false);
    var matIn = new T.MeshStandardMaterial({ color: new T.Color("#96702f"), roughness: .96, metalness: 0, emissive: new T.Color("#3a1c05"), emissiveIntensity: .22 });
    var spots = [[-5.6, 2.0], [-1.9, 1.2], [1.9, 1.4], [5.6, 2.1], [-4.2, 4.6], [0.2, 5.2], [4.2, 4.9], [-7.4, 7.2], [7.2, 7.4], [0, 8.4], [-8.6, 3.4], [8.6, 3.6], [-3.2, 7.0], [3.2, 7.2], [-2.4, 3.1], [2.4, 3.3], [-6.6, 5.6], [6.6, 5.8]];
    spots.forEach(function (p, i) {
      var gy = 6.1 - (i % 3) * .34;
      var g = new T.Group(); g.position.set(p[0], gy, p[1]); scene.add(g);
      var c = mesh(geo, matIn, 0, 0, 0, g); c.scale.setScalar(.88 + (i % 3) * .14);
      c.rotation.y = i * 1.1;
      /* long hanging wire to the ceiling */
      var wireH = HH - gy;
      cyl(.02, .02, wireH, mat("#2a1c10"), 0, wireH / 2 + .1, 0, g, 6);
      mesh(new T.TorusGeometry(.07, .018, 6, 12), mat("#2a1c10"), 0, wireH + .05, 0, g);
      /* ember at the burning tip */
      var sc = .88 + (i % 3) * .14;
      var tip = new T.Sprite(new T.SpriteMaterial({ map: TEX.glow, color: 0xff8a30, transparent: true, opacity: .95, blending: T.AdditiveBlending, depthWrite: false }));
      tip.scale.setScalar(.85); tip.position.set(.78 * sc * .96, -1.95 * sc + .1, 0); g.add(tip);
      /* 塔香中間垂吊的紅紙：長條、直書吉祥字句 */
      var cord = cyl(.008, .008, .58, mat("#2a1c10"), 0, -.29, 0, g, 5);
      var tag = plane(.24, 1.21, new T.MeshStandardMaterial({ roughness: .9, side: T.DoubleSide }), 0, -1.19, 0, g);
      tag.material.map = textTexture("吉祥如意平安", { size: 58, vertical: true, color: "#f7dda2", bg: "rgba(196,44,26,.96)", pad: 9 });
      tag.material.needsUpdate = true;
      tag.rotation.y = (i % 4) * .78;
      tag.userData.ph = Math.random() * 6.28;
      (U.coilTags = U.coilTags || []).push(tag);
      /* smoke from the ember */
      var sys = makeSmoke(30, { base: new T.Vector3(p[0] + .78 * sc * .96, gy - 1.95 * sc + .18, p[1]), size: .6, opacity: .2, rise: 2.2, spread: .5, speed: .22 });
      coilGroups.push({ g: g, tip: tip, sys: sys, ph: Math.random() * 6.28, tag: tag });
    });
  }

  /* ---------------- dust motes ---------------- */
  function buildDust() {
    var n = QUAL === "low" ? 90 : 220;
    var geo = new T.BufferGeometry(), pos = new Float32Array(n * 3), sp = new Float32Array(n * 3);
    for (var i = 0; i < n; i++) {
      pos[i * 3] = rnd(-HX + .8, HX - .8); pos[i * 3 + 1] = rnd(.4, HH - 1); pos[i * 3 + 2] = rnd(-HZ + .8, 12);
      sp[i * 3] = rnd(-.04, .04); sp[i * 3 + 1] = rnd(.02, .09); sp[i * 3 + 2] = rnd(-.04, .04);
    }
    geo.setAttribute("position", new T.BufferAttribute(pos, 3));
    var m = new T.PointsMaterial({ size: .055, map: TEX.dust, transparent: true, opacity: .55, depthWrite: false, blending: T.AdditiveBlending, color: 0xffe6b8 });
    var p = new T.Points(geo, m); p.frustumCulled = false; scene.add(p);
    U.dust = { points: p, geo: geo, sp: sp, n: n };
  }

  /* ---------------- lights ---------------- */
  function buildLights() {
    scene.fog = new T.FogExp2(0x1a0d09, .015);
    var skyGeo = new T.SphereGeometry(120, 24, 16);
    var skyMat = new T.ShaderMaterial({
      side: T.BackSide, depthWrite: false, fog: false,
      uniforms: { top: { value: new T.Color("#0d0a12") }, mid: { value: new T.Color("#3b2018") }, bot: { value: new T.Color("#0a0504") } },
      vertexShader: "varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }",
      fragmentShader: "varying vec3 vP; uniform vec3 top,mid,bot; void main(){ float h = normalize(vP).y; vec3 c = h>0.12 ? mix(mid,top,smoothstep(0.12,0.75,h)) : mix(bot,mid,smoothstep(-0.25,0.12,h)); gl_FragColor = vec4(c,1.0); }"
    });
    var sky = new T.Mesh(skyGeo, skyMat); sky.frustumCulled = false; scene.add(sky);
    var amb = new T.AmbientLight(0x53301c, .95); scene.add(amb);
    var hemi = new T.HemisphereLight(0x3d2620, 0x0d0604, .7); scene.add(hemi);
    /* altar spot */
    var sp = new T.SpotLight(0xffb877, 1.15, 26, .82, 1, 1.25);
    sp.position.set(0, 8.6, -4.4); sp.target.position.set(0, 1.2, -9.6); scene.add(sp); scene.add(sp.target);
    if (QUAL === "high") {
      sp.castShadow = true; sp.shadow.mapSize.set(2048, 2048); sp.shadow.bias = -.0006; sp.shadow.camera.far = 30;
      renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFSoftShadowMap;
    }
    /* doorway daylight */
    var day = new T.SpotLight(0x9db8cf, .75, 34, .95, .8, 1.1);
    day.position.set(0, 5.6, 20); day.target.position.set(0, 1.6, -2); scene.add(day); scene.add(day.target);
    /* statue accent light */
    var acc = new T.SpotLight(0xffca8a, .55, 12, .55, .9, 1.2);
    acc.position.set(0, 5.4, -6.2); acc.target.position.set(0, 2.6, -11.0);
    scene.add(acc); scene.add(acc.target);

    /* candle lights (flicker) */
    [-1.9, 1.9].forEach(function (x) {
      var p = new T.PointLight(0xff9a4a, .2, 2.6, 2);
      p.position.set(x, 2.05, -9.0); scene.add(p); flameLights.push({ l: p, base: .85, ph: Math.random() * 6.28 });
    });
    /* lamp wall */
    var lp = new T.PointLight(0xffc06a, .5, 8, 2); lp.position.set(9.4, 2.4, -2.2); scene.add(lp); U.lampLight = lp;
    /* v95：神壇補光 — 只照亮供桌一帶，令果品 / 花 / 燭有層次，唔會搶主光 */
    var altarFill = new T.PointLight(0xffd9a0, .38, 6.5, 2); altarFill.position.set(0, 3.4, -7.6); scene.add(altarFill);
    U.lights = { amb: amb, hemi: hemi, spot: sp, day: day };
  }

  /* ---------------- camera / controls ---------------- */
  var player = U.player = { x: 0, y: 1.62, z: 8.4, yaw: 0, pitch: -.05, bob: 0 };
  var vel = { x: 0, z: 0 }, keys = {}, joy = { x: 0, y: 0 }, drag = null, walkTo = null, bowT = 0;
  var limits = { x0: -9.4, x1: 9.4, z0: -8.1, z1: 26.5 };

  function onKey(e, down) {
    var k = e.key.toLowerCase();
    if (["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].indexOf(k) >= 0) {
      keys[k] = down; if (down) walkTo = null; e.preventDefault();
    }
  }

  function initInput() {
    window.addEventListener("keydown", function (e) { onKey(e, true); });
    window.addEventListener("keyup", function (e) { onKey(e, false); });
    var c = renderer.domElement;
    c.addEventListener("pointerdown", function (e) {
      if (e.target !== c) return;
      drag = { x: e.clientX, y: e.clientY, yaw: player.yaw, pitch: player.pitch, id: e.pointerId };
      c.setPointerCapture(e.pointerId);
    });
    c.addEventListener("pointermove", function (e) {
      if (!drag || e.pointerId !== drag.id) return;
      player.yaw = drag.yaw - (e.clientX - drag.x) * .0042;
      player.pitch = Math.max(-.75, Math.min(.62, drag.pitch - (e.clientY - drag.y) * .0035));
    });
    function endDrag(e) { if (drag && e.pointerId === drag.id) drag = null; }
    c.addEventListener("pointerup", endDrag); c.addEventListener("pointercancel", endDrag);
    window.addEventListener("wheel", function (e) {
      if (e.target !== c) return;
      player.pitch = Math.max(-.75, Math.min(.62, player.pitch + e.deltaY * .0008));
    }, { passive: true });
  }

  MM.setJoy = function (x, y) { joy.x = x; joy.y = y; if (x || y) walkTo = null; };
  MM.setCam = function (x, z, yaw, pitch, cb) {
    walkTo = { x: x, z: z, yaw: yaw == null ? player.yaw : yaw, pitch: pitch == null ? player.pitch : pitch, t: 0, cb: cb || null };
  };
  MM.walkTo = function (x, z, yaw, cb) {
    var w = { x: x, z: z, yaw: yaw == null ? player.yaw : yaw, pitch: player.pitch, t: 0, cb: cb || null };
    walkTo = w;
    /* Manual movement elsewhere cancels walkTo; scripted rite walk is reasserted */
    w.scripted = true;
  };
  MM.walkTarget = function () { return walkTo && { x: walkTo.x, z: walkTo.z }; };
  MM.teleport = function (x, z, yaw, pitch) {
    player.x = x; player.z = z; player.yaw = yaw || 0; player.pitch = pitch == null ? -.04 : pitch;
    walkTo = null;
  };
  MM.bow = function () { bowT = 1.25; };

  function updatePlayer(dt) {
    var mx = 0, mz = 0;
    var scriptedWalk = !!(walkTo && walkTo.scripted);
    /* ix = 右(+)/左(-)，iz = 前(+)/後(-)。搖桿向上 dy 為負，故 iz -= joy.y */
    if (keys.w || keys.arrowup) mz += 1;
    if (keys.s || keys.arrowdown) mz -= 1;
    if (keys.a || keys.arrowleft) mx -= 1;
    if (keys.d || keys.arrowright) mx += 1;
    mx += joy.x; mz -= joy.y;
    var len = Math.hypot(mx, mz); if (len > 1) { mx /= len; mz /= len; }
    var speed = scriptedWalk ? 4.2 : 2.7;
    var sin = Math.sin(player.yaw), cos = Math.cos(player.yaw);
    /* 前向量 (sin,cos)；右向量 (-cos,sin) */
    var wx = (sin * mz - cos * mx) * speed, wz = (cos * mz + sin * mx) * speed;

    if (walkTo && walkTo.scripted) { mx = 0; mz = 0; wx = 0; wz = 0; }
    if (walkTo) {
      var dx = walkTo.x - player.x, dz = walkTo.z - player.z, d = Math.hypot(dx, dz);
      if (d < (walkTo.scripted ? .04 : .12)) { var __cb = walkTo.cb; walkTo = null; wx = 0; wz = 0; if (__cb) setTimeout(__cb, 0); } else {
        wx = dx / d * Math.min(speed, d * 3); wz = dz / d * Math.min(speed, d * 3);
        if (walkTo.yaw != null) {
          var dy = ((walkTo.yaw - player.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
          player.yaw += dy * Math.min(1, dt * 3.2);
        }
        if (walkTo.pitch != null) player.pitch += (walkTo.pitch - player.pitch) * Math.min(1, dt * 3);
      }
    }
    if (scriptedWalk) { vel.x = wx; vel.z = wz; }
    else { vel.x += (wx - vel.x) * Math.min(1, dt * 8); vel.z += (wz - vel.z) * Math.min(1, dt * 8); }
    player.x += vel.x * dt; player.z += vel.z * dt;
    /* collisions */
    player.x = Math.max(limits.x0, Math.min(limits.x1, player.x));
    player.z = Math.max(limits.z0, Math.min(limits.z1, player.z));
    [-6.4, 6.4].forEach(function (cx) {
      [4.4, -1.4].forEach(function (cz) {
        var dx = player.x - cx, dz = player.z - cz, d = Math.hypot(dx, dz);
        if (d < .95) { player.x = cx + dx / d * .95; player.z = cz + dz / d * .95; }
      });
    });
    if (U.obstacles) for (var oi = 0; oi < U.obstacles.length; oi++) {
      var ob = U.obstacles[oi], odx = player.x - ob.x, odz = player.z - ob.z, od = Math.hypot(odx, odz);
      if (od < ob.r) {
        var nx = odx / (od || 1), nz = odz / (od || 1);
        player.x = ob.x + nx * ob.r; player.z = ob.z + nz * ob.r;
        /* 殿中央嘅圓柱（金鹿基座）正對面頂住時，側向滑開，避免玩家原地卡死 */
        if (ob.slide && (vel.x * nx + vel.z * nz) < 0 && Math.abs(vel.x * nz - vel.z * nx) < .6) {
          player.x += (player.x >= ob.x ? .04 : -.04);
        }
      }
    }
    var moving = Math.hypot(vel.x, vel.z);
    player.bob += moving * dt * 7.5;
    var bobY = Math.sin(player.bob) * .026 * Math.min(1, moving / 2);
    if (bowT > 0) bowT = Math.max(0, bowT - dt);

    /* 神壇平台：踏上石階時視點隨高度升起（三段石階，平台高 PZ） */
    var stairRun = 1.32, gy = 0;
    if (player.z <= REAR) gy = PZ;
    else if (player.z < REAR + stairRun) gy = PZ * (1 - (player.z - REAR) / stairRun);
    U.groundY = gy;
    var eyeY = 1.62 + bobY + gy + (player.z > 13 ? .02 : 0);
    var pitch = player.pitch;
    var cy = Math.cos(pitch), sy = Math.sin(pitch);
    var fwd = new T.Vector3(Math.sin(player.yaw) * cy, sy, Math.cos(player.yaw) * cy);
    camera.position.set(player.x, eyeY, player.z);
    camera.position.y -= Math.sin(Math.min(1, (1.25 - bowT) / .35) * Math.PI) * .0;
    if (bowT > 0) {
      var k = Math.sin((1.25 - bowT) / 1.25 * Math.PI);
      camera.position.y -= k * .55;
      camera.lookAt(player.x + fwd.x * 3, eyeY - .55 * k + fwd.y * 3, player.z + fwd.z * 3);
    } else {
      camera.lookAt(player.x + fwd.x * 3, eyeY + fwd.y * 3, player.z + fwd.z * 3);
    }
    U.eyeY = eyeY;
  }

  /* ---------------- proximity ---------------- */
  var nearId = null;
  function updateNear() {
    var best = null, bd = 99;
    for (var k in stations) {
      var s = stations[k], d = Math.hypot(player.x - s.x, player.z - s.z);
      if (d < s.r && d < bd) { bd = d; best = s; }
    }
    if ((best && best.id) !== nearId) {
      nearId = best ? best.id : null;
      if (MM.onNear) MM.onNear(best);
    }
  }

  /* ---------------- loop ---------------- */
  function frame() {
    if (!running) return;
    requestAnimationFrame(frame);
    var dt = Math.min(.05, clock.getDelta()), t = clock.elapsedTime;
    updatePlayer(dt);
    updateNear();
    /* lanterns sway */
    for (var i = 0; i < lanterns.length; i++) {
      var l = lanterns[i];
      l.rotation.z = Math.sin(t * .9 + l.userData.ph) * .035;
      l.rotation.x = Math.cos(t * .7 + l.userData.ph) * .025;
    }
    /* candle flicker */
    for (i = 0; i < flameLights.length; i++) {
      var f = flameLights[i];
      f.l.intensity = f.base * (.82 + Math.sin(t * 9 + f.ph) * .09 + Math.sin(t * 23 + f.ph) * .05);
    }
    /* coils: ember + smoke */
    for (i = 0; i < coilGroups.length; i++) {
      var cg = coilGroups[i];
      cg.tip.material.opacity = .55 + Math.sin(t * 2.4 + cg.ph) * .2;
    }
    updateSmoke(dt, t);
    updateDust(dt, t);
    if (U.onFrameDeer) U.onFrameDeer(dt, t);
    if (U.onFrameOfferings) U.onFrameOfferings(dt, t);
    if (U.onFrameRelics) U.onFrameRelics(dt, t);
    if (U.onFrameFestival) U.onFrameFestival(dt, t);
    if (U.onFrame) U.onFrame(dt, t);
    renderer.render(scene, camera);
  }

  function updateSmoke(dt, t) {
    for (var s = 0; s < smokeSystems.length; s++) {
      var sys = smokeSystems[s], pos = sys.geo.attributes.position.array, n = sys.n, seed = sys.seed;
      for (var i = 0; i < n; i++) {
        var life = (t * sys.speed + seed[i * 4 + 3]) % 1;
        var ang = seed[i * 4 + 2] + t * .28;
        var r = sys.spread * life * (0.5 + seed[i * 4] * .9);
        pos[i * 3] = sys.base.x + Math.cos(ang) * r + Math.sin(t * .5 + i) * .08;
        pos[i * 3 + 1] = sys.base.y + life * sys.rise;
        pos[i * 3 + 2] = sys.base.z + Math.sin(ang) * r;
      }
      sys.geo.attributes.position.needsUpdate = true;
      var smokeMat = sys.points.material;
      if (smokeMat.userData.incenseBase == null) smokeMat.userData.incenseBase = smokeMat.opacity;
      smokeMat.opacity = Math.min(.3, smokeMat.userData.incenseBase + (smokeMat.userData.incenseAdded || 0));
    }
    if (U.tickSmoke) U.tickSmoke(dt, t);
  }
  function updateDust(dt, t) {
    if (!U.dust) return;
    var p = U.dust.geo.attributes.position.array, sp = U.dust.sp;
    for (var i = 0; i < U.dust.n; i++) {
      p[i * 3] += sp[i * 3] * dt + Math.sin(t * .3 + i) * .0015;
      p[i * 3 + 1] += sp[i * 3 + 1] * dt;
      p[i * 3 + 2] += sp[i * 3 + 2] * dt;
      if (p[i * 3 + 1] > HH - .4) p[i * 3 + 1] = .3;
      if (Math.abs(p[i * 3]) > HX - .6) sp[i * 3] *= -1;
      if (Math.abs(p[i * 3 + 2]) > HZ - .6) sp[i * 3 + 2] *= -1;
    }
    U.dust.geo.attributes.position.needsUpdate = true;
  }

  /* ---------------- init ---------------- */
  MM.init = function (canvas, opts) {
    opts = opts || {};
    QUAL = opts.quality || "high";
    renderer = new T.WebGLRenderer({ canvas: canvas, antialias: QUAL !== "low", powerPreference: "high-performance", alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, QUAL === "high" ? 2.2 : QUAL === "mid" ? 1.5 : 1));
    renderer.outputEncoding = T.sRGBEncoding;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.02;
    renderer.shadowMap.enabled = false;

    scene = U.scene = new T.Scene(); U.renderer = renderer;
    scene.background = new T.Color("#150a06");
    camera = U.camera = new T.PerspectiveCamera(62, 1, .1, 160);

    buildTextures();
    buildLights();
    buildShell();
    buildCoils();
    buildDust();
    initInput();

    clock = new T.Clock();
    function resize() {
      var w = window.innerWidth, h = window.innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h; camera.updateProjectionMatrix();
    }
    resize(); window.addEventListener("resize", resize);

    player.yaw = Math.PI; player.pitch = .04; player.x = 0; player.z = 7.6;
    running = true; t0 = performance.now();
    frame();
    if (MM.onReady) MM.onReady();
  };

  MM.setQuality = function (q) {
    QUAL = q;
    if (!renderer) return;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, q === "high" ? 2.2 : q === "mid" ? 1.5 : 1));
    var sh = q === "high";
    renderer.shadowMap.enabled = sh;
    if (U.lights && U.lights.spot) U.lights.spot.castShadow = sh;
  };
  MM.pause = function () { running = false; };
  MM.resume = function () { if (!running) { running = true; clock.getDelta(); frame(); } };

  /* shared exports */
  U.T = T; U.mat = mat; U.gold = gold; U.mesh = mesh; U.box = box; U.cyl = cyl; U.plane = plane;
  U.rnd = rnd; U.srand = srand; U.cvs = cvs; U.textTexture = textTexture; U.makeSmoke = makeSmoke;
  U.makeLantern = makeLantern; U.addStation = addStation; U.player = player; U.flameLights = flameLights;
  U.SERIF = SERIF; U.SANS = SANS; U.HZ = HZ; U.HX = HX;
})();
