#!/usr/bin/env python3
"""生成「塵入り和紙」無縫貼圖（assets/washi.jpg）。

參考實物：未漂白（未晒し）手漉和紙，帶樹皮纖維「塵」（chiri）與長纖維紋。
做法全部程序生成，可重現（固定 seed），無第三方素材、無授權問題。

    python3 tools/make-washi.py

輸出 512×512 無縫 tile；兩頁（3D 彈窗與 /fortunestick/）共用同一張。
"""
import random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

S = 512
SEED = 20261109
BASE = (228, 212, 128)      # 實簽紙底：廟方籤紙的偏黃金黃（對照實物取樣）
FIB_DARK = (200, 183, 104)
FIB_LIGHT = (243, 231, 168)
CHIRI = (132, 102, 58)      # 樹皮碎屑
CHIRI_SOFT = (176, 148, 100)

rng = random.Random(SEED)
np.random.seed(SEED)


def wrap_xy(x, y):
    """回傳 9 個貼邊副本座標，令貼圖可無縫平鋪。"""
    pts = [(x, y)]
    if x < 40: pts.append((x + S, y))
    if x > S - 40: pts.append((x - S, y))
    if y < 40: pts.append((x, y + S))
    if y > S - 40: pts.append((x, y - S))
    if x < 40 and y < 40: pts.append((x + S, y + S))
    if x < 40 and y > S - 40: pts.append((x + S, y - S))
    if x > S - 40 and y < 40: pts.append((x - S, y + S))
    if x > S - 40 and y > S - 40: pts.append((x - S, y - S))
    return pts


# ---------- 1. 底：低頻不均勻（手漉厚薄） ----------
low = np.random.normal(0, 1, (16, 16))
low = np.array(Image.fromarray(((low - low.min()) / (np.ptp(low) + 1e-9) * 255).astype("uint8"))
               .resize((S, S), Image.BICUBIC), dtype=np.float32) / 255.0
low = low - low.mean()

canvas = np.zeros((S, S, 3), dtype=np.float32)
for i, c in enumerate(BASE):
    canvas[..., i] = c + low * 7.0          # ±7 級，非常輕微

img = Image.fromarray(np.clip(canvas, 0, 255).astype("uint8"))
d = ImageDraw.Draw(img, "RGBA")

# ---------- 2. 長纖維（楮皮纖維，細、走向一致偏橫） ----------
for _ in range(1500):
    x, y = rng.uniform(0, S), rng.uniform(0, S)
    ang = rng.gauss(0.0, 0.55)              # 略偏橫向
    ln = rng.uniform(5, 26)
    dx, dy = np.cos(ang) * ln, np.sin(ang) * ln
    col = FIB_DARK if rng.random() < 0.55 else FIB_LIGHT
    a = rng.randint(14, 40)
    bend = rng.uniform(-0.35, 0.35)
    for (ox, oy) in wrap_xy(x, y):
        d.line([(ox, oy), (ox + dx * .5, oy + dy * .5 + bend * 3), (ox + dx, oy + dy)],
               fill=col + (a,), width=1)

# ---------- 3. 塵入り：樹皮碎屑（chiri） ----------
def fleck(cx, cy, r, col, a):
    for (ox, oy) in wrap_xy(cx, cy):
        pts = []
        n = rng.randint(4, 7)
        for k in range(n):
            th = 2 * np.pi * k / n + rng.uniform(-0.4, 0.4)
            rr = r * rng.uniform(.55, 1.25)
            pts.append((ox + np.cos(th) * rr, oy + np.sin(th) * rr))
        d.polygon(pts, fill=col + (a,))

for _ in range(260):                        # 細塵
    fleck(rng.uniform(0, S), rng.uniform(0, S), rng.uniform(0.6, 1.5), CHIRI_SOFT, rng.randint(30, 80))
for _ in range(70):                         # 明顯碎屑
    fleck(rng.uniform(0, S), rng.uniform(0, S), rng.uniform(1.2, 2.6), CHIRI, rng.randint(40, 105))
for _ in range(9):                          # 大一點的樹皮
    fleck(rng.uniform(0, S), rng.uniform(0, S), rng.uniform(2.6, 4.2), CHIRI, rng.randint(55, 95))

# ---------- 3b. 漉き込み（抄紙混入裝飾）：金／銀砂子、染色紙屑 ----------
GOLD_A = (203, 158, 52)
GOLD_B = (245, 219, 148)
SILVER = (247, 245, 236)
SCRAPS = [(186, 96, 74), (92, 104, 148), (108, 138, 104)]     # 染色和紙碎屑：絳／藍／綠

def speck(cx, cy, r, col, a):
    """極細碎粒：不規則小點，代替圓點以免太機械。"""
    for (ox, oy) in wrap_xy(cx, cy):
        pts = []
        n = rng.randint(3, 5)
        for k in range(n):
            th = 2 * np.pi * k / n + rng.uniform(-0.5, 0.5)
            rr = r * rng.uniform(.6, 1.3)
            pts.append((ox + np.cos(th) * rr, oy + np.sin(th) * rr))
        d.polygon(pts, fill=col + (a,))

for _ in range(210):                        # 金砂子
    col = GOLD_A if rng.random() < 0.55 else GOLD_B
    r = rng.uniform(0.55, 1.35)
    x, y = rng.uniform(0, S), rng.uniform(0, S)
    speck(x, y, r, col, rng.randint(140, 225))
    if rng.random() < 0.35:                 # 少量高光，做出金屬閃點
        for (ox, oy) in wrap_xy(x, y):
            d.point((ox, oy), fill=(252, 240, 200, 235))
for _ in range(120):                        # 銀砂子（更細、更淡）
    speck(rng.uniform(0, S), rng.uniform(0, S), rng.uniform(0.45, 1.0), SILVER, rng.randint(110, 185))
for _ in range(16):                         # 染色和紙碎屑：短纖維狀
    x, y = rng.uniform(0, S), rng.uniform(0, S)
    ang = rng.uniform(0, np.pi)
    ln = rng.uniform(4, 10)
    col = SCRAPS[rng.randrange(len(SCRAPS))]
    for (ox, oy) in wrap_xy(x, y):
        d.line([(ox, oy), (ox + np.cos(ang) * ln, oy + np.sin(ang) * ln)],
               fill=col + (rng.randint(70, 125),), width=1)

# ---------- 3c. 天然韌皮／稻草纖維（藁、竹漿、未褪色表皮） ----------
STRAW = (206, 184, 118)
BAST = (148, 110, 56)

for _ in range(16):                         # 稻草：較長、偏直、方向散亂
    x, y = rng.uniform(0, S), rng.uniform(0, S)
    ang = rng.uniform(0, np.pi)
    ln = rng.uniform(18, 55)
    w = 1 if rng.random() < 0.75 else 2
    jitter = rng.uniform(-0.06, 0.06)
    for (ox, oy) in wrap_xy(x, y):
        d.line([(ox, oy),
                (ox + np.cos(ang) * ln * .55, oy + np.sin(ang + jitter) * ln * .55),
                (ox + np.cos(ang + jitter) * ln, oy + np.sin(ang + jitter) * ln)],
               fill=STRAW + (rng.randint(45, 85),), width=w)
for _ in range(14):                         # 黃褐表皮組織：短、略彎、色較深
    x, y = rng.uniform(0, S), rng.uniform(0, S)
    ang = rng.uniform(0, np.pi)
    ln = rng.uniform(4, 15)
    for (ox, oy) in wrap_xy(x, y):
        bx = rng.uniform(-2.2, 2.2)
        d.line([(ox, oy), (ox + np.cos(ang) * ln * .5 + bx, oy + np.sin(ang) * ln * .5),
                (ox + np.cos(ang) * ln, oy + np.sin(ang) * ln)],
               fill=BAST + (rng.randint(60, 110),), width=1)

# ---------- 4. 極細紙毛（絨面感） ----------
noise = np.random.normal(0, 2.1, (S, S, 1))
arr = np.clip(np.array(img, dtype=np.float32) + noise, 0, 255).astype("uint8")
img = Image.fromarray(arr)

# 輕微柔化，避免像素噪點太硬
img = img.filter(ImageFilter.GaussianBlur(0.35))

out = "assets/washi.jpg"
img.save(out, quality=90, optimize=True, progressive=True, subsampling=1)
print("wrote", out)
