#!/usr/bin/env python3
"""由中文版全文頁生成 /en/ /ja/ /th/ 三個語言版本（同一份模板，路徑與語言連結改寫）。

    python3 tools/build-locales.py

產出：
    fortunestick/en/index.html
    fortunestick/ja/index.html
    fortunestick/th/index.html

只改 shell（<html lang>、canonical、hreflang、語言切換連結、資源相對路徑），
真正的介面文字由 locales/ui.js + js/i18n.js 於瀏覽器套用；籤紙本身永遠是中文原文。
"""
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "fortunestick", "index.html")
BASE_URL = "https://handcraftstudio.eu.org/manmotemple/fortunestick/"

LANGS = [("zh-Hant", "zh-Hant-HK", ""), ("en", "en", "en/"), ("ja", "ja", "ja/"), ("th", "th", "th/")]


def href_map(lang):
    """由該語言頁面出發，切去各語言的相對路徑。"""
    if lang == "":
        return {"zh-Hant": "./", "en": "en/", "ja": "ja/", "th": "th/"}
    return {"zh-Hant": "../", "en": "./" if lang == "en" else "../en/",
            "ja": "./" if lang == "ja" else "../ja/", "th": "./" if lang == "th" else "../th/"}


def alt_links(lang):
    out = []
    for code, _, path in LANGS:
        out.append('<link rel="alternate" hreflang="%s" href="%s%s">' % (code, BASE_URL, path))
    out.append('<link rel="alternate" hreflang="x-default" href="%s">' % BASE_URL)
    return "\n".join(out)


def build(lang):
    s = open(SRC, encoding="utf-8").read()
    path = "" if lang == "zh-Hant" else lang
    depth = 0 if not path else 1

    if depth:  # /en/index.html → 所有 ../ 資源要多上一層
        s = s.replace('src="../', 'src="../../').replace('href="../', 'href="../../')
        s = s.replace("'../js/lots-l10n.js", "'../../js/lots-l10n.js")
        s = s.replace("'../locales/shengyi.js", "'../../locales/shengyi.js")
        # 「返回 3D 參拜」帶上語言
        s = s.replace('<a class="back" href="../../" data-i18n="back3d">',
                      '<a class="back" href="../../?lang=%s" data-i18n="back3d">' % lang)
        s = re.sub(r'<html lang="[^"]*">', '<html lang="%s">' % dict((c, h) for c, h, _ in LANGS)[lang], s)
        # 語言切換連結
        h = href_map(path)
        s = s.replace('<a href="./" data-l="zh-Hant">', '<a href="%s" data-l="zh-Hant">' % h["zh-Hant"])
        s = s.replace('<a href="en/" data-l="en">', '<a href="%s" data-l="en">' % h["en"])
        s = s.replace('<a href="ja/" data-l="ja">', '<a href="%s" data-l="ja">' % h["ja"])
        s = s.replace('<a href="th/" data-l="th">', '<a href="%s" data-l="th">' % h["th"])
        # 靜態標題與描述（SEO 用，唔靠 JS）
        import json as _json
        _ui = _json.load(open(os.path.join(ROOT, "locales", "ui.json"), encoding="utf-8"))[lang]
        s = re.sub(r"<title>[^<]*</title>", "<title>%s</title>" % _ui["title"], s, count=1)
        s = re.sub(r'(<meta name="description" content=")[^"]*(">)', lambda m: m.group(1) + _ui["desc"] + m.group(2), s, count=1)
        # canonical + hreflang
        s = s.replace('<link rel="canonical" href="%s">' % BASE_URL,
                      '<link rel="canonical" href="%s%s/">\n%s' % (BASE_URL, path, alt_links(lang)))
        out_dir = os.path.join(ROOT, "fortunestick", path)
        os.makedirs(out_dir, exist_ok=True)
        open(os.path.join(out_dir, "index.html"), "w", encoding="utf-8").write(s)
        print("wrote", os.path.join("fortunestick", path, "index.html"))
    else:
        # 中文版也補 hreflang（canonical 已存在）
        if 'hreflang="en"' not in s:
            s = s.replace('<link rel="canonical" href="%s">' % BASE_URL,
                          '<link rel="canonical" href="%s">\n%s' % (BASE_URL, alt_links(lang)))
            open(SRC, "w", encoding="utf-8").write(s)
            print("zh: hreflang added")


for code, _, path in LANGS:
    build(code)
