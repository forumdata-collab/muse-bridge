# manmotemple v99 handoff

- 來源：forumdata-collab/hi-we1co `dd9b107` 的 `manmotemple/`（已上線，CACHE `manmo-v99`）
- 線上：https://handcraftstudio.eu.org/manmotemple/ ／ https://hi.we1co.me/manmotemple/
- 結構：`index.html` 在 `manmotemple/` 一層內（符合 §10）
- 相對 v98 zip 的差異：只有 `js/scene.js` 的 `TEX.deerGold` 生成法（貼片覆蓋率 36%→95.2%）、`sw.js` CACHE→manmo-v99、`index.html` `scene.js?v=20261110d`、`js/app.js` `sw.js?v=36`
- 未改：i18n-3d.js（md5 0f5e17a4…，與線上一致）、incense/ritual/divination 邏輯、ASSETS 清單
