# 文武廟 · 雲端參拜 — 交接說明（給協作編輯者 / Muse AI）

這是一個純靜態網站（HTML + CSS + vanilla JS + three.js），無 build step、無後端。
可直接用任何靜態伺服器預覽，例如：

```bash
cd manmotemple
python3 -m http.server 8080
# 開 http://127.0.0.1:8080/
```

---

## 1. 內容規則（請勿違反）

| 範圍 | 規則 |
|---|---|
| 黃紙上的原籤文（`.lot-paper` 子樹） | **永遠繁體中文**，逐字照錄廟方籤紙，不翻譯、不改字。程式已硬性排除（`js/i18n-3d.js` 的 `trText()` 會跳過 `.lot-paper`）。 |
| 場景貼圖文字（對聯、匾額、紅布、燈籠） | **永遠繁體中文**（屬廟宇實物）。Canvas 翻譯層刻意停用。 |
| 其餘介面（按鈕、步驟、提示、面板標題） | 可翻譯成 en / ja / th。 |
| 「武帝靈簽」四字 | 四語一律保留**繁體中文原名**，不譯作 Oracle / 靈籤 等。 |
| 「聖意」 | 面板與列表標題保留原字「聖意」，不寫 Sacred meaning。 |
| 英文用詞 | 不用 “sacred”。聖筊 = **yes blocks**、笑筊 = laughing blocks、陰筊 = no blocks、立筊 = standing block。 |
| 免責 | 站內須保留「本站整理，非廟方官方出版」與「不保證占卜準確」。 |

---

## 2. 目錄結構

```
manmotemple/
├─ index.html            3D 主站（three.js 場景、HUD、面板）
├─ fortunestick/         武帝靈簽全文頁（中文：index.html；外語：en/ ja/ th/）
├─ sources/              資料來源與考訂方法頁
├─ calendar/ quick/      行事曆、快速參拜
├─ js/
│  ├─ scene.js world.js deer.js relics.js incense.js festival.js  ← 3D 場景與物件
│  ├─ app.js             介面、面板、互動
│  ├─ lot-ritual.js      求籤請示彈窗（搖籤／擲筊／聖笑陰立筊）
│  ├─ lot-view.js        籤文渲染共用模組（籤紙版式、導讀）
│  ├─ lots.js            100 支籤資料（中文原文）
│  ├─ lots-l10n.js       100 支籤 × en/ja/th 譯文（只喺非中文頁載入）
│  ├─ lot-stories.js     典故／寓意
│  ├─ i18n.js            全文頁語言判定與介面字串
│  └─ i18n-3d.js         3D 站翻譯層（DOM 文字／屬性／title；Canvas 已停用）
├─ locales/
│  ├─ ui.json / ui.js    全文頁介面字典（zh-Hant / en / ja / th）
│  ├─ ui3d.js            3D 介面字典（約 557 條，按中文原文查表）
│  └─ ritual.js          求籤彈窗字典（約 95 條）
├─ assets/               和紙紋理、圖片、字體
├─ tools/
│  ├─ build-locales.py   由中文模板生成 fortunestick/en|ja|th
│  ├─ i18n-src/          譯文來源 JSON（可重新產生 ui3d.js / ritual.js）
│  └─ make-washi.py      和紙紋理生成
├─ sw.js                 Service Worker（改版要 bump manmo-vNN）
└─ sitemap.xml robots.txt
```

---

## 3. 多語言架構（重要）

**全文頁**：中文版 `fortunestick/index.html` 是模板，執行

```bash
python3 tools/build-locales.py
```

會生成 `fortunestick/en|ja|th/index.html`，同時寫入 `hreflang`、本地化 `<title>`／description、以及帶語言參數的「返回 3D」連結。
**改中文模板後必須重跑此腳本**，否則外語頁不會同步。

**3D 站**：語言用 query string，不改任何場景程式碼。

```
/manmotemple/            → 繁中（零額外下載）
/manmotemple/?lang=en    → English
/manmotemple/?lang=ja    → 日本語
/manmotemple/?lang=th    → ไทย
```

`js/i18n-3d.js` 在 `app.js` 之前載入（`document.write`，只在非中文時），負責：
1. 翻譯 DOM 文字節點與屬性（placeholder / title / aria-label / alt）
2. 攔 `textContent` / `innerText` setter（app 會不停重設 caption）
3. MutationObserver 追動態插入的節點
4. **不**翻譯 `.lot-paper`（黃紙）與 Canvas 貼圖

**求籤彈窗**：`js/lot-ritual.js` 內 `tr(s, vars)` 在 `innerHTML` / `setStatus` / `setTip` / `acts` 四處替換；帶數字的句子用 `{n}` / `{got}` / `{need}` 模板，**不要**用字串相加。

---

## 4. 部署（Cloudflare Pages）

```bash
export CLOUDFLARE_API_TOKEN=<你的 token>
npx wrangler pages deploy . --project-name=hi-we1co --branch=main
```

- 專案：`hi-we1co`，網域：`hi.we1co.me`（正本）／`handcraftstudio.eu.org`（鏡像）
- **自訂網域更新有 2–5 分鐘延後**；`*.pages.dev/<deployment>` 即時更新，自訂網域稍後才跟上，屬正常現象，不是部署失敗。
- 每次改 HTML/CSS/JS 都要 bump `sw.js` 的 `manmo-vNN`，否則回訪者會見到舊版。

---

## 5. 已知問題

1. 3D 場景某些鏡頭下，浮動熱點標籤（如「仰望匾額」）會與其他熱點重疊——屬標籤定位，未完全解決。
2. 泰文在部分短句會沿用英文詞（如 Lamp），可再校。
3. 日文個別專名保留漢字（如 孟嘗君），屬刻意。

---

## 6. 資料出處

籤文以廟方籤紙實物為正本逐字照錄；坊間通行本（雷雨師一百籤 · 網頁校合本）只作參校。
異文（內容級）4 支：第 10、83、84、97；單字校記 60 支。詳見 `sources/`。

---

## 7. v95 改動（2026-11-10 · 3D 細緻度提升）

**金鹿（`js/deer.js`）**
- 鎏金改用程序化貼圖（拉絲 + 錘揲凹點 + 舊化暗斑）+ bump + 環境反光（`scene.js` 新增 CubeTexture 環境貼圖），唔再係一色死金。
- 頭部：鼻孔、嘴線、下頜肌、下巴、眼瞼、眉脊、額頂金簇；耳加內耳、耳緣、耳尖，兩耳獨立 dynamic，間中輕動。
- 鹿角：Tube 段數 20→32、徑向 6→10，新增眉枝、角基雙環、尖端深色；角組標 `dynamic`，輕擺而家真係郁到（之前會被 `optimizeStatic` 合併走）。
- 身：胸隆、腹底、脇側雲紋陰刻、背脊鬃毛；尾改獨立 dynamic group，可輕擺。
- 腿：蹄分叉兩趾 + 蹄踵絨毛 + 小距；頸加頸筋。
- 靈芝如意、胸前金牌（加「福」字面）、頸圈金珠 9 粒、小鈴加鈴舌；台座加金包角、幼金線、牌面金框；貼金箔加皺摺抖動。
- 全部鹿身 mesh 設 `castShadow`，主光下有落地感。

**供桌祭品（`js/world.js` `buildOfferings`）**
- 果盤：青花瓷盤（程序化青花紋）+ 青葉墊；生果分得清 — 橙（橙皮凹點貼圖 + 莖 + 葉）、蘋果（亮面紅 + 莖葉）、桃（粉紅 + 凹痕 + 尖頂），金字塔排列。
- 花：菊花（花心 + 兩層花瓣 + 莖 + 葉），花瓶改青花瓷車床瓶（闊腹收頸撇口）。
- 燭：黃銅燭台（底座、細頸、滴蠟盤）+ 滴蠟三滴 + 燭芯 + 雙層火焰（`U.candleFlames` + `U.onFrameOfferings` 閃爍）。
- 新增：供桌紅布（錦緞）、三杯清茶（托盤 + 茶湯面）、發糕 ×3、元寶 ×2；主爐香灰堆成小丘、香枝火頭明暗不一、其中兩枝綁紅線；籤筒改竹紋。
- 神壇補光（`scene.js` `buildLights` 加暖 PointLight），供品層次更清楚。

**一併改進**
- `scene.js`：新增 `TEX.gold / porcelain / orange / bamboo` 程序化貼圖、`U.ENV` 環境貼圖、`U.onFrameOfferings` 掛鉤。
- 快取：`sw.js` `manmo-v94` → `manmo-v95`，`app.js` `sw.js?v=31` → `v=32`，`index.html` scene/world/deer `?v=20261109n` → `?v=20261110a`。
- 效能取捨：鹿角、耳、尾標 `dynamic` 令動畫生效，draw call 輕微上升；軀幹、供品仍可被 `optimizeStatic` 合併，整體仍在目標範圍內。
- 驗證：`node --check` 全部改動 JS 通過；本地 `python3 -m http.server` 載入無報錯（見 `CHANGES-v95.md`）。

## 8. v96（2026-11-10，用戶反饋修復）
- 鹿角：樞軸改設喺角基，`onFrameDeer` 輕擺 ±0.01，唔再有 `-0.22` 整體轉角（v95 回歸：標 `dynamic` 後舊轉角生效，角基離頭）。
- 鹿嘴：靈芝垂條改為麥穗（7 對麥粒 + 芒刺，唇瓣夾住穗柄）。
- 鹿台隸書：實心金框改四條邊框條，牌面移到 z=.778 + Canvas 後備字，PNG 載好再換（v95 回歸：金板前面遮住牌面）。
- 善信 / 廟祝：對襟盤扣、腰帶、裙腳邊、袖口邊、布鞋、髮髻金簪、念珠；廟祝加領口金邊、盤扣、胸袋巾。
- 求籤：供桌加香盤（3D）+ 介面第一步「取三炷清香」，取咗先可以搖籤。
- 香案爐：三足由枱面托到爐底，爐身升起，`ashY` .5→.66；木魚同樣升到枱面。
- 快取：`sw.js` manmo-v96、`app.js` sw.js?v=33、index.html scene/world/deer ?v=20261110b、lot-ritual ?v=20261113b。
- 詳見根目錄 `CHANGES-v96.md`；驗證：`node --check` + Node smoke test（真 three.js，9 項全通過）。

## 9. v97（2026-11-10，已交付做 diff，未部署）
- 鹿口麥穗改為「柔和含住」：S 形彎曲穗柄由嘴內彎出，上下唇瓣（金身物料）輕輕合攏托住穗柄，穗頭向前微垂、貼住下唇線。
- 全廟動畫細節提升：菊花花頭輕擺、燭光火苗微傾、庭院街燈光暈呼吸、節慶橫額輕擺。
- 金鹿改為全靜止（用戶糾正：擺設唔會呼吸、唔會郁）：`onFrameDeer` 改為空殼。
- 外語簽文與獨立站一致：3D 廟外語頁載入 `lots-l10n.js` 並掛上 `l.l10n`，加載 `i18n.js` + `locales/ui.js`，補返 `i18n-3d.js` 3 條「一百籤 · 第 N 籤」規則。
- 快取：`sw.js` manmo-v97、`app.js` sw.js?v=34、index.html deer/world/festival ?v=20261110c、app.js ?v=20261111z、i18n-3d.js ?v=5。
- 詳見根目錄 `CHANGES-v97.md`；驗證：`node --check` + Node smoke test（鹿 19 項、世界 9 項、簽文一致性 18 項全通過）；2026-11-10 經 GitHub 交畀 Hermes 做 diff，同日 09:53 HKT 已部署上線。

## 10. v98（2026-11-10，已交付做 diff，未部署）
- 香盤移位：由供桌右邊（x=+.55）移去香案枱面左邊（x=-1.3），正對取香企位 (-1.3, -7.1) — v97 上線後用戶發現道具同取香動畫企位唔對。
- 求籤字幕同步改字：「香盤就喺供桌籤筒旁邊」→「香盤就喺香案左邊」。
- 金鹿按實物相改進：鹿身專用做舊金箔貼圖（深銅底 + 金箔貼片）；靈芝如意改單片扁圓蓋 + 扁長方形尾端 + 兩粒座腳 + 螺旋雕紋；口銜改粗扭紋長柄垂到胸口（用戶確認扭紋柄就係麥穗形象化，15 粒麥粒刪咗）；台座改深灰石材 + 回紋邊，保留「金鹿 • 祿」牌，加「請勿攀爬」小牌；拆頸圈鈴鐺 +「福」牌。
- 快取：`sw.js` manmo-v98、`app.js` sw.js?v=35、index.html world.js ?v=20261110d、lot-ritual.js ?v=20261113c、deer.js ?v=20261110d、scene.js ?v=20261110c。
- 詳見根目錄 `CHANGES-v98.md`；驗證：`node --check` + Node smoke test（鹿 28 項、世界 13 項、簽文一致性 18 項全通過）。
