/* 文武廟 · 介面與互動 */
(function () {
  "use strict";
  var $ = function (s) { return document.querySelector(s); };
  var MM = window.MM, U = window.MM._;
  var A = MM.audio;
  var STORE = "manmo.v1";
  var state = {
    lamps: {}, wishes: [], deer: [], relics: { brush: 0, blade: 0 }, bowed: false, festival: "none", captions: true, taisuiYear: null, lastLotData: null, lotHistory: [], name: "", incense: 0, guide: 0, sound: true,
    volAmb: .55, volSfx: .8, quality: "high", jiaoNeed: 1, wallTokens: {}
  };
  try { var s = JSON.parse(localStorage.getItem(STORE) || "{}"); Object.assign(state, s); } catch (e) { }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>\"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c]; }); }
  function save() { try { localStorage.setItem(STORE, JSON.stringify(state)); } catch (e) { } }

  var booted = false, sheetOpen = false, installEvt = null;
  window.addEventListener("load", function () {
    setTimeout(function () {
      try { if (state.seat && state.seat.on && MM.setSeat) MM.setSeat(true, false); } catch (e) { }
      /* 深層連結：?lot=11 直接開啟該籤（分享用，不計求籤） */
      try {
        var m = /[?&]lot=(\d{1,3})/.exec(location.search);
        if (m) {
          var want = parseInt(m[1], 10);
          var hit = (window.LOTS || []).filter(function (x) { return +x.n === want; })[0];
          if (hit) setTimeout(function () { showLot(hit, { preview: true }); }, 260);
        }
      } catch (e) { }
    }, 1200);
  });
  window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); installEvt = e; });

  /* ---------------- loader ---------------- */
  var pct = 0;
  function progress(v, hint) {
    pct = Math.max(pct, v);
    $("#ldBar").style.width = pct + "%";
    if (hint) $("#ldHint").textContent = hint;
  }
  var tick = setInterval(function () {
    if (pct < 88) progress(pct + Math.random() * 9, pct < 40 ? "正在燃點香塔" : pct < 70 ? "正在鋪設花崗石地" : "正在恭迎文武二帝");
  }, 260);

  /* ---------------- toast / caption ---------------- */
  var toastT;
  function toast(msg, ms) {
    var el = $("#toast"); el.textContent = msg; el.classList.add("show");
    clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove("show"); }, ms || 2600);
  }
  var capT;
  function caption(msg, ms) {
    if (state.captions === false) return;
    var el = $("#caption"); el.textContent = msg; el.classList.add("show");
    clearTimeout(capT); capT = setTimeout(function () { el.classList.remove("show"); }, ms || 3200);
  }

  /* ---------------- sheet ---------------- */
  function sheet(title, sub, html, onMount) {
    $("#sheetTitle").textContent = title;
    $("#sheetSub").textContent = sub || "";
    $("#sheetBody").innerHTML = html;
    $("#sheet").classList.add("open");
    sheetOpen = true;
    if (onMount) onMount($("#sheetBody"));
  }
  function closeSheet() { $("#sheet").classList.remove("open"); sheetOpen = false; }
  $("#sheetClose").onclick = closeSheet;
  $("#sheet").addEventListener("click", function (e) {
    var t = e.target.closest("[data-act]");
    if (!t) return;
    var a = t.getAttribute("data-act");
    if (a === "close") closeSheet();
  });

  /* ---------------- guide ---------------- */
  var GUIDE = [
    { t: "入廟三拜", d: "沿中軸走過金鹿，在立地大香爐前站定，合十向文武二帝行三鞠躬。", go: "altar" },
    { t: "鳴鐘擊鼓", d: "神鐘與神鼓並列於殿右（面向神壇的右手邊）；本頁可試鳴鐘鼓，象徵以鐘鼓聲通報神明。", go: "bell" },
    { t: "上三炷香", d: "先到香案請三炷清香（香案在神壇平台上），舉香齊眉默念所求，再回正殿主爐上香。", go: "incense" },
    { t: "求籤問事", d: "跪稟姓名、生辰與所問，搖籤筒求一支籤。", go: "lot" },
    { t: "擲筊請示", d: "一對筊杯擲地，一平一凸為聖筊，神明應允。", go: "jiao" },
    { t: "點燈 · 登科及第", d: "可點一盞光明燈，或為學子奉上「登科及第」心願，再到金鹿貼金箔。", go: "lamps" }
  ];
  function renderGuide() {
    var last = GUIDE.length - 1;
    state.guide = Math.max(0, Math.min(last, state.guide | 0));
    $("#guideStep").textContent = "參拜指引 " + (state.guide + 1) + "/" + GUIDE.length;
    $("#guideText").textContent = GUIDE[state.guide].d;
  }
  function advanceGuide(i) {
    var n = Math.min(GUIDE.length - 1, i + 1);
    if (state.guide < n) { state.guide = n; save(); renderGuide(); }
  }
  $("#guideBtn").onclick = function () {
    var h = "<p class='small muted'>以下為本站建議的參拜次序（文化導覽，非廟方規定）；每一步都可按「前往」由場景帶你到位置。</p><div class='steps'>";
    for (var i = 0; i < GUIDE.length; i++) h += "<i class='" + (i <= state.guide ? "on" : "") + "'></i>";
    h += "</div>";
    GUIDE.forEach(function (g, i) {
      h += "<div class='gstep " + (i < state.guide ? "done" : "") + "'><div class='n'>" + (i + 1) + "</div><div><b>" + g.t + "</b><p>" + g.d + "</p></div><button class='btn ghost small' data-go='" + g.go + "'>前往</button></div>";
    });
    h += "<div class='rule'></div><button class='btn ghost small block' data-browse='1'>瀏覽一百籤（不計求籤）</button>";
    h += "<p class='small muted' style='margin-top:10px'>廟內請保持安靜，香火區注意安全。本頁為文化體驗，非廟方官方網站。</p>";
    sheet("參拜指引", "SIX STEPS", h, function (body) {
      body.addEventListener("click", function (e) {
        var b = e.target.closest("[data-go]"); if (!b) return;
        closeSheet(); runStation(b.getAttribute("data-go"));
      });
      body.addEventListener("click", function (e) {
        if (!e.target.closest("[data-browse]")) return;
        closeSheet(); setTimeout(function () { if (MM.showLotPreview) MM.showLotPreview(1); }, 200);
      });
    });
  };
  $("#guideGo").onclick = function () { closeSheet(); runStation(GUIDE[Math.min(state.guide, GUIDE.length - 1)].go); };

  /* ---------------- intro ---------------- */
  var INTRO = [
    ["文武廟", "上環荷李活道 124–126 號"],
    ["", ""]
  ];
  function renderIntro() {
    var html =
      "<img src='assets/coils1.jpg' alt='文武廟殿內塔香' style='width:100%;height:170px;object-fit:cover;border-radius:10px;border:1px solid rgba(230,184,100,.2)'>" +
      "<p class='small muted' style='margin-top:6px'>殿內塔香由上而下盤旋燃燒 · 照片：Wikimedia Commons（CC BY-SA）</p>" +
      "<p>文武廟位於上環荷李活道，由文武廟、列聖宮與公所三幢建築組成（列聖宮與公所屬另一空間，本頁只重現正殿），約建於 <b>1847 至 1862 年</b>，由華人富商盧亞貴、譚亞財興建，現由東華三院管理，<b>2010 年列為法定古蹟</b>。</p>" +
      "<p>正殿供奉 <b>文昌帝君</b>（主功名、學業）與 <b>關聖帝君</b>（主忠義、誠信）。廟宇為兩進三開間布局，天井以重檐歇山頂覆蓋，屋頂由天井四角的花崗石柱支撐，兩側為捲棚頂廂房；殿內保存 1847 年銅鐘、1862 年官轎，以及木雕、灰塑、壁畫與塔香。</p>" +
      "<p class='small muted'>開埠初期，這裡曾是華人議事、排解糾紛之地，「斬雞頭、燒黃紙」的宣誓儀式亦在廟內舉行；1880 年文武廟值理與坊眾支持東華醫院在廟旁中華書院開辦義學，1958 年修例後廟產收益亦用於辦學。今日每年秋祭，東華三院董事局仍會在廟內主持典禮；秋祭儀式於 2014 年納入香港非物質文化遺產清單。</p>" +
      "<div class='rule'></div>" +
      "<section id='divineTitles'><h3 style='font-family:var(--serif);font-weight:400;letter-spacing:.14em;color:var(--gold);font-size:14px'>中央立牌 · 文武二帝的尊號</h3>" +
      "<p>面向神壇，依傳統直排由右至左的閱讀次序：右列為<b>「九天開化梓潼靈感文昌帝君」</b>，左列為<b>「九天揚化協天無極關聖帝君」</b>。以下依所提供的牌文說明：這些是信仰中的尊號，結合神明職掌與讚頌語，不宜把每個字都當作歷史人物的官銜。</p>" +
      "<h4 style='color:var(--gold)'>右列：文昌帝君——開啟智慧，勤學修德</h4>" +
      "<p><b>「九天開化梓潼靈感文昌帝君」</b>是文帝的尊號。「九天」表達高遠天界的意象；「開化」指啟迪人心、推廣教化；「梓潼」連繫四川梓潼的地方信仰與張亞子傳說；「靈感」在此指神靈感應。文昌信仰融合了文昌星官與梓潼神的傳統，逐漸成為士人祈求學業、功名與官祿的精神寄託。</p>" +
      "<p>文昌帝君又稱文帝，民間相傳與晉代人物有關，至元代獲加封帝君。文武廟的巨型文昌筆，象徵文章、功名與官祿；善信摸筆，是把求學與事業的心願寄託其中。每逢農曆二月初三文昌誕，廟方會舉行文昌啟智禮，配合文昌四寶燈與青雲路等祈福安排，祝願學子聰明勤奮、學業進步，也寄望在職人士工作順利。文昌的意義不只在考試結果，更在勤學、修德與持續自勉。</p>" +
      "<h4 style='color:var(--gold)'>左列：關聖帝君——以忠義守信，以仁勇立身</h4>" +
      "<p><b>「九天揚化協天無極關聖帝君」</b>所尊奉的是關羽，字雲長，民間尊稱關公、武帝。「揚化」可理解為宣揚教化；「協天」帶有協助天道、維護正義的意思；「無極」則是廣大無窮的宗教讚頌語。關羽的歷史形象經後世祭祀、敕封與傳說發展，成為忠誠、正直、仁勇的象徵。</p>" +
      "<p>《三國志》記關羽受曹操厚待，仍不忘劉備舊恩；立功報答後，封存賞賜、留書辭去。後世又以桃園結義、千里走單騎等故事傳揚忠義，其中小說演繹與史實須分開看。關帝的寶刀象徵勇武與決斷；善信敬奉關帝，除了祈願生意興隆，也重視交友與營商中的守信、正直和責任。農曆六月廿四為關帝誕。文武合祀，正好提醒人以文啟智、以武守義，讓學識與品格相互成就。</p>" +
      "<p class='small muted'>左右以參拜者面向神壇為準。以上為本頁文化導讀；歷史記載、民間傳說與祈願象徵分別理解，實際祭祀安排以廟方公布為準。</p></section>" +
      "<div class='rule'></div>" +
      "<h3 style='font-family:var(--serif);font-weight:400;letter-spacing:.14em;color:var(--gold);font-size:14px'>入廟儀式</h3>" +
      "<p>一般廟宇禮節是先跨過門檻（不踏門檻），入殿後向神明合十行禮，再到香案請香、上香。文武廟殿內設有神鐘、神鼓，屬廟方器物，並非供訪客自行敲擊：本頁的鳴鐘、擊鼓與三鞠躬，是為體驗鐘鼓聲而設的場景互動，不是廟方規定的參拜程序。實際禮儀以現場告示及廟方人員指示為準。</p>" +
      "<h3 style='font-family:var(--serif);font-weight:400;letter-spacing:.14em;color:var(--gold);font-size:14px'>裝潢重點</h3>" +
      "<p>入口的木雕擋中（屏風）刻有<b>「帝德同沾」</b>（光緒十九年，1893 年重園社信眾送贈），屏首為相傳光緒帝御筆的「神威普佑」；花崗石門框刻有建廟年份。正殿兩進三開間，天井覆以重簷歇山頂、四角花崗石柱，兩側為捲棚頂廂房。場景把匾額重現於入口上方高處，站在殿內要抬頭仰望；走近入口會出現「仰望匾額」提示，按一下即自動拉高視角。殿內最搶眼是頭頂的<b>塔香陣</b>與<b>八角宮燈</b>——宮燈每面絹畫彩繪、下垂流蘇，燈下就是善信許願的地方。主神龕兩旁為包公殿與城隍殿；前進另有十王殿、福德宮與神鐘、神鼓。</p>" +
      "<div class='rule'></div>" +
      "<h3 style='font-family:var(--serif);font-weight:400;letter-spacing:.14em;color:var(--gold);font-size:14px'>金鹿 · 文昌座前神獸</h3>" +
      "<p>殿內金鹿取「鹿」與<b>「祿」</b>同音，是文昌帝君座前神獸。據東華三院文武廟「祈願金鹿」的說明，善信在廟內櫃位請金箔（2020 年公告列每片 HK$18，現價以廟方為準），雙手合十向文昌帝君稟明心願，再輕輕貼上；貼在不同位置代表不同祈願方向：<b>鹿角</b>求開啟智慧、增加判斷力（宜求學人士）、<b>臉部</b>求工作順利、增添人緣（宜在職人士）、<b>腹部</b>求招財守財（宜營商人士）、<b>腳部</b>求家庭和合（宜已婚人士）、<b>背部</b>求身體健康（任何人士）。走近金鹿可按「互動」貼上金箔。</p>" +
      "<button class='btn ghost small' id='goDeer'>前往金鹿 ›</button>" +
      "<div class='rule'></div>" +
      "<div class='row' style='flex-wrap:wrap;gap:8px'>" +
      "<a class='btn ghost small' href='https://www.discoverhongkong.com/tc/place-to-go/travel.guide-man-mo-temple.html' target='_blank' rel='noopener'>旅發局介紹 ↗</a>" +
      "<a class='btn ghost small' href='https://www.google.com/maps/search/?api=1&query=Man+Mo+Temple+Hong+Kong' target='_blank' rel='noopener'>Google 地圖 ↗</a>" +
      "<a class='btn ghost small' href='https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=22.2840,114.1503' target='_blank' rel='noopener'>街景 ↗</a>" +
      "<a class='btn ghost small' href='https://earth.google.com/web/@22.2840,114.1503,25a,0d,35y,0h,0t,0r' target='_blank' rel='noopener'>Google Earth 3D ↗</a>" +
      "</div>" +
      "<div class='rule'></div>" +
      "<h3 style='font-family:var(--serif);font-weight:400;letter-spacing:.14em;color:var(--gold);font-size:14px'>Google 3D 實景 · 殿內</h3>" +
      "<p class='small muted'>由 Google 街景用家拍攝的殿內 360° 全景，可拖曳環視真實的塔香、神龕與宮燈。</p>" +
      "<a class='btn primary block' href='https://maps.app.goo.gl/kpzhRfBQccijEMmH9?g_st=ac' target='_blank' rel='noopener' style='text-align:center;text-decoration:none'>開啟 Google 真實內景（360°）↗</a>" +
      "<button class='btn block ghost' id='loadPano' style='margin-top:8px'>在頁內載入 360° 全景（需連線）</button>" +
      "<p class='small' style='margin-top:8px'><a href='https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=22.2839478,114.1502271&heading=16.4&pitch=1.1' target='_blank' rel='noopener' style='color:var(--gold)'>在 Google 地圖開啟 360° 全景 ↗</a></p>" +
      "<p class='small muted'>全景照片由 Google 街景用家拍攝及提供，版權屬拍攝者。</p>" +
      "<div id='panoSlot'></div>" +
      "<div class='rule'></div><h3 style='font-family:var(--serif);font-weight:400;letter-spacing:.14em;color:var(--gold);font-size:14px'>實景對照</h3>" +
      "<div class='gal'>" +
      "<figure class='wide'><img src='assets/interior2.jpg' alt='文武廟內殿'><figcaption>內殿 · 塔香與神龕</figcaption></figure>" +
      "<figure><img src='assets/altar.jpg' alt='神龕'><figcaption>文武二帝神龕</figcaption></figure>" +
      "<figure><img src='assets/exterior1.jpg' alt='廟門告示'><figcaption>廟門告示 · 東華三院管理</figcaption></figure>" +
      "<figure><img src='assets/roof.jpg' alt='瓦頂'><figcaption>綠瓦與簷角</figcaption></figure>" +
      "<figure><img src='assets/plaque.jpg' alt='帝德同沾匾額'><figcaption>「帝德同沾」匾額（3D 重建）</figcaption></figure>" +
      "<figure><img src='assets/plaques.jpg' alt='化寶金紙'><figcaption>金紙 · 化寶</figcaption></figure>" +
      "</div>" +
      "<p class='small muted'>照片來源：Wikimedia Commons（CC BY 4.0 / CC BY-SA 4.0 / CC BY 2.0），作者包括 Sarah Stierch、Aethelfirth、PrzemekJaczewski、Alberto Carrasco Casado、Andrew Moore。本頁為文化導覽創作，非廟方官方網站。</p>" +
      "<div class='rule'></div>" +
      "<h3 style='font-family:var(--serif);font-weight:400;letter-spacing:.14em;color:var(--gold);font-size:14px'>實用資料</h3>" +
      "<p class='small'>開放時間：每日 08:00–18:00（農曆初一、十五及誕期 07:00 開始）<br>電話：2540 0350<br>地址：上環荷李活道 124–126 號<br>交通：港鐵上環站 A2 出口，步行約 6–10 分鐘<br>順遊：廟旁裕寶齋、摩羅街（古董街）</p>" +
      "<div class='rule'></div><div id='mapSlot'></div>";
    sheet("文武廟", "MAN MO TEMPLE · 1847", html, function (body) {
      var slot = body.querySelector("#mapSlot");
      var btn = document.createElement("button");
      btn.className = "btn block ghost"; btn.textContent = "載入 Google 地圖（需連線）";
      btn.onclick = function () {
        slot.innerHTML = "<iframe src='https://maps.google.com/maps?q=Man%20Mo%20Temple%20Hollywood%20Road%20Hong%20Kong&z=17&output=embed' style='width:100%;height:230px;border:0;border-radius:10px;filter:grayscale(.2) contrast(1.05)' loading='lazy' referrerpolicy='no-referrer-when-downgrade'></iframe>";
      };
      slot.appendChild(btn);
      var panoBtn = body.querySelector('#loadPano');
      if (panoBtn) panoBtn.onclick = function () {
        body.querySelector('#panoSlot').innerHTML = "<iframe src='https://www.google.com/maps/embed?pb=!4v1595605148125!6m8!1m7!1sCAoSLEFGMVFpcE96U0pHYU1SYjdWaGNUbWlSR2V4WVhnbW94YTVlbzVQb3NGX3pQ!2m2!1d22.2839478!2d114.1502271!3f16.43621813171375!4f1.1318376652534567!5f0.7820865974627469' style='width:100%;height:300px;border:0;border-radius:10px;margin-top:10px' loading='lazy' allowfullscreen referrerpolicy='no-referrer-when-downgrade'></iframe>";
        panoBtn.style.display = "none";
      };
      var gd = body.querySelector('#goDeer');
      if (gd) gd.onclick = function () { closeSheet(); setTimeout(doDeer, 200); };
    });
  }

  /* v97：外語簽文與 /fortunestick/ 一致 — 非中文頁已同步載入 lots-l10n.js，
     喺度掛上 l.l10n，LotView 先攞到譯本；唔掛就會成頁顯示「譯文仍在準備中」。
     中文頁冇載入 lots-l10n.js，呢段唔做嘢。 */
  if (window.LOTS_L10N && window.LOTS) {
    window.LOTS.forEach(function (l) { if (!l.l10n) l.l10n = window.LOTS_L10N[l.n]; });
  }

  /* ---------------- 求籤 ---------------- */
  var currentLot = null;
  function doLot() {
    if (!window.LOTS || !window.LOTS.length) {
      toast("籤文資料載入中，請重新整理後再求籤");
      return;
    }
    if (!MM.LotRitual) { toast("求籤互動載入中，請重新整理後再試"); return; }
    closeSheet();
    caption("先定心默念一件所問之事，再搖籤、擲筊確認。", 4200);
    MM.LotRitual.open({
      lots: window.LOTS,
      needSheng: state.jiaoNeed === 3 ? 3 : 1,
      onConfirm: function (L) {
        currentLot = L;
        state.lastLot = L.n;
        var PV = plaqueView(L);
        state.lastLotData = { n: PV.n, gz: PV.grade || PV.gz || '', poem: PV.poem, meaning: PV.story || '' };
        state.lotHistory.unshift({ n: L.n, grade: L.grade || "", at: new Date().toISOString() });
        save(); showLot(L, { tab: "paper" });
      },
      onCancel: function () { caption("已取消求籤，未記錄新籤。", 2200); }
    });
  }
  /* 聖意白話詞典與 syGloss 已搬到 js/lot-view.js（與 /fortunestick/ 共用同一份） */
  function syGloss(item) { return window.LotView.syGloss(item); }

  /* ---------------- 籤文顯示：原文 / 白話導讀 / 一百籤瀏覽 ---------------- */
  var LOT_SRC = {
    temple: "https://temples.tungwahcsd.org/twghs-man-mo-temple",
    heritage: "https://www.tungwah.org.hk/heritage/historic-architecture/man-mo-temple/"
  };
  var lotTab = "paper";

  function lotMulti(v) {
    if (v == null) return [];
    var arr = Array.isArray(v) ? v : String(v).split(/\r?\n/);
    return arr.map(function (x) { return String(x == null ? "" : x).trim(); }).filter(Boolean);
  }
  /* 白話導讀（summary / explanation / action）與聖意逐項白話由 js/lot-view.js 提供，
     3D 彈窗與 /fortunestick/ 全文頁輸出同一段 HTML。 */
  /* 只允許 http(s)/mailto，並把非 ASCII 路徑編碼；呼叫端仍會 esc() 一次 */
  function lotSafeUrl(u) {
    var s = String(u == null ? "" : u).trim();
    if (!/^(https?:|mailto:)/i.test(s)) return "";
    try { return encodeURI(s); } catch (e) { return ""; }
  }
  function lotSourceLinks(src) {
    if (!src || typeof src !== "object") return "";
    var out = [];
    var pairs = [["原始來源頁", src.url], ["來源索引", src.indexUrl], ["另一來源（籤詩網）", src.altUrl]];
    pairs.forEach(function (p) {
      var href = lotSafeUrl(p[1]);
      if (href) out.push("<a href='" + esc(href) + "' target='_blank' rel='noopener noreferrer'>" + esc(p[0]) + "</a>");
    });
    return out.join(" · ");
  }
  function lotSourceHtml(L) {
    var src = L && L.source;
    var site = src && typeof src === "object" && src.site ? String(src.site) : "";
    var links = lotSourceLinks(src);
    var html;
    if (L && L._plaque) {
      html = "<p class='lot-provenance'>原文：<b>廟方籤版</b>（" +
        esc((L.temple && L.temple.plaque) || "香港荷李活道一二六號文武廟 東華三院管理") +
        "）。用字照錄籤紙，不代為改字；校訂異同見上方版本說明。";
    } else {
      html = "<p class='lot-provenance'>原文：<b>坊間通行本</b>（公共領域民間文本）。非廟方官方出版，個別字句各本或有差異。";
    }
    if (site) html += "<br>來源：" + esc(site) + (src.retrieved ? " · 檢索於 " + esc(src.retrieved) : "") + "。";
    if (links) html += "<br>" + links;
    html += "<br>廟方及背景資料：<a href='" + esc(LOT_SRC.temple) + "' target='_blank' rel='noopener noreferrer'>東華三院文武廟</a> · " +
      "<a href='" + esc(LOT_SRC.heritage) + "' target='_blank' rel='noopener noreferrer'>文武廟歷史</a></p>";
    return html;
  }

  /* 籤紙優先、解曰標點、異文判準都收在 js/lot-view.js：3D 彈窗與全文頁共用，不再各寫一份。 */
  function plaqueView(L) { return window.LotView.plaqueView(L); }
  function joinClauses(a) { return window.LotView.joinClauses(a); }
  function variantHtml(L) { return window.LotView.variantHtml(L); }
  function showLot(L, opts) {
    opts = opts || {};
    var preview = !!opts.preview;
    if (!L) { toast("籤文資料未就緒，請再試一次"); return; }
    if (opts.tab) lotTab = (opts.tab === "reading" || opts.tab === "lib") ? opts.tab : "paper";
    var RAW = L;                                   /* 坊間通行本（校訂） */
    var hasPlaque = !!(L.temple && L.temple.poem);
    var lots = window.LOTS || [];
    var total = lots.length || 100;
    var n = parseInt(L.n, 10) || 1;
    var grade = L.grade ? String(L.grade) : "";
    var gz = L.gz ? String(L.gz) : "";

    function sections(src, opts) {
      opts = opts || {};
      var h = "", syRaw = (Array.isArray(src.shengyi) ? src.shengyi : []).map(function (t) { return "<span>" + esc(t) + "</span>"; }).join("");
      if (syRaw) h += "<div class='lot-orig-sec'><h4>聖意</h4><div class='lot-sy'>" + syRaw + "</div></div>";
      var bx = lotMulti(src.bixian);
      if (bx.length) {
        var half = Math.ceil(bx.length / 2);
        var rows = [bx.slice(0, half), bx.slice(half)].filter(function (a) { return a.length; });
        h += "<div class='lot-orig-sec'><h4>碧仙註</h4><div class='lot-verse'>" + rows.map(function (a) {
          return a.map(function (t) { return esc(t) + (/[，。、；：]$/.test(String(t)) ? "" : "　"); }).join("").replace(/　+$/, "");
        }).join("<br>") + "</div></div>";
      }
      var jy = lotMulti(src.jieyue);
      if (jy.length) h += "<div class='lot-orig-sec'><h4>解曰</h4>" + jy.map(function (t) { return "<p class='lot-orig-p'>" + esc(t) + "</p>"; }).join("") +
        ((opts.plaque) ? window.LotView.jieyueNote(src) : "") + "</div>";
      if (src.dongpo) h += "<div class='lot-orig-sec'><h4>東坡解</h4><p class='lot-orig-p'>" + esc(src.dongpo) +
        "</p><p class='small muted'>pdways.com 原文照錄，原文無標點，未加改動。</p></div>";
      return h;
    }

    /* ---------- 一 · 原籤紙（黃紙紅字；與全文頁共用同一份 paperHtml） ---------- */
    var paper = window.LotView.paperHtml(L);

    /* ---------- 二 · 白話導讀（本站原創；與 /fortunestick/ 逐字相同） ---------- */
    var read = window.LotView.readingHtml(L);

    /* ---------- 三 · 坊間通行本（網頁轉錄原文，未經籤紙校改） ---------- */
    var editionNote = L.editionNote ? String(L.editionNote).trim() : "";
    var LB = L.lib || {};
    var libStory = LB.ancient || L.storyLib || L.story || "";
    var storyDiff = hasPlaque && libStory && (L.temple.ancient || "") !== libStory;
    function libSec(name, val) {
      return val ? "<div class='lot-orig-sec'><h4>" + name + "</h4><p class='lot-orig-p'>" + esc(val) + "</p></div>" : "";
    }
    var lib = "<div class='lot-orig-sec'><p class='small muted'>坊間通行本（雷雨師一百籤傳統流傳本），非廟方籤紙；用字照錄網頁轉錄原文，個別字形各本或有差異。東坡解只見於此本，籤紙不載。</p></div>" +
      (libStory ? "<div class='lot-orig-sec'><h4>古人</h4><p class='lot-orig-p'>" + esc(libStory) +
        (storyDiff ? "<span class='small muted'>（籤紙作「" + esc(L.temple.ancient) + "」）</span>" : "") + "</p></div>" : "") +
      (LB.poem ? "<div class='lot-orig-sec'><h4>籤詩</h4><p class='lot-orig-p'>" + esc(joinClauses(LB.poem)) + "</p></div>"
               : "<div class='lot-orig-sec'><h4>籤詩</h4><p class='lot-orig-p'>" + esc(joinClauses(RAW.poem)) + "</p></div>") +
      sections({ shengyi: LB.shengyi || RAW.shengyi, bixian: LB.bixian || RAW.bixian,
                 jieyue: LB.jieyue || RAW.jieyue, dongpo: RAW.dongpo }, { lib: true });
    lib += variantHtml(RAW);
    lib += window.LotView.collationHtml(RAW);
    lib += lotSourceHtml(RAW);
    lib += "<div class='lot-orig-sec'><a class='lot-index-link' href='/manmotemple/fortunestick/#lot" + esc(n) + "'>在全文頁比對來源 →</a></div>";

    var TABS = [
      { id: "paper", label: "原籤紙", panel: "<div class='lot-paper-wrap'>" + paper + "</div>" },
      { id: "reading", label: "白話導讀", panel: "<div class='lot-reading'><div class='lot-reading-tag'>本站原創導讀 · 非籤紙原文</div>" + read + "</div>" },
      { id: "lib", label: "坊間通行本", panel: "<div class='lot-reading lot-lib'><div class='lot-reading-tag'>坊間通行本 · 非廟方定本</div>" +
          (editionNote ? "<div class='lot-edition-alert' role='note'><b>版本／等第異文</b><p>" + esc(editionNote) + "</p></div>" : "") + lib + "</div>" }
    ];
    if (!TABS.some(function (x) { return x.id === lotTab; })) lotTab = "paper";

    var tabs = "<div class='lot-tabs' role='tablist' aria-label='籤文顯示方式'>" +
      TABS.map(function (t) {
        return "<button class='lot-tab' role='tab' id='lotTab-" + t.id + "' data-tab='" + t.id + "' aria-controls='lotPanel-" + t.id +
          "' aria-selected='" + (lotTab === t.id ? "true" : "false") + "'>" + t.label + "</button>";
      }).join("") + "</div>" +
      
      TABS.map(function (t) {
        return "<section id='lotPanel-" + t.id + "' role='tabpanel' aria-labelledby='lotTab-" + t.id + "'" +
          (lotTab === t.id ? "" : " hidden") + ">" + t.panel + "</section>";
      }).join("");

    var bar = "", pickGrid = "";
    if (preview) {
      bar = "<div class='lot-browsebar'>" +
          "<button class='nav' data-lotnav='-1' aria-label='上一籤'" + (n <= 1 ? " disabled" : "") + ">‹</button>" +
          "<span class='pos'>第 " + esc(n) + " 籤 · 共 " + esc(total) + " 籤</span>" +
          "<button class='nav' data-lotnav='1' aria-label='下一籤'" + (n >= total ? " disabled" : "") + ">›</button>" +
          "<button class='pick' id='lotPick' aria-expanded='false' aria-controls='lotGrid'>選號</button>" +
        "</div>" +
        "<p class='lot-browse-note'>瀏覽模式：只供查看籤文，不計求籤、不改動你的求籤紀錄。</p>" +
        "<div class='lot-grid' id='lotGrid' hidden>";
      lots.forEach(function (x) {
        var xn = parseInt(x.n, 10);
        if (!xn) return;
        var xt = /大吉|上上|上吉/.test(x.grade || "") ? "good" : /下下|下平|下吉/.test(x.grade || "") ? "bad" : "";
        pickGrid += "<button data-jump='" + xn + "' class='" + xt + "'" + (xn === n ? " aria-current='true'" : "") + ">" + xn + "</button>";
      });
      pickGrid += "</div>";
    }

    var acts = preview
      ? "<div class='lot-acts'><button class='btn ghost' id='lotClose2'>關閉瀏覽</button><button class='btn' id='lotDraw'>誠心求籤</button></div>" +
        "<p class='small muted' style='margin-top:10px'>瀏覽不會記錄為求籤。如要正式求籤，請按「誠心求籤」，搖籤後擲聖筊確認。</p>"
      : "<div class='lot-acts'><button class='btn primary' id='lotAgain'>再求一籤</button><button class='btn ghost' id='lotKeep'>誠心領受</button></div>" +
        "<div class='lot-acts'><button class='btn ghost' id='lotBrowse'>瀏覽一百籤（不計求籤）</button></div>" +
        "<p class='small muted' style='margin-top:12px'>" + window.LotView.NAME + "（關聖帝君一百籤 · 雷雨師）· 籤詩、聖意、東坡解屬傳統民間文本；白話導讀為本作品原創整理，只作文化體驗與自我省思，不構成醫療、投資或法律意見。原文與白話分開呈現。</p>";

    sheet(preview ? "一百籤 · 第 " + n + " 籤" : "第 " + n + " 籤" + (grade ? " · " + grade : ""),
      preview ? "BROWSE · 不計求籤" : "LOT NO." + n,
      bar + pickGrid + tabs + acts,
      function (body) {
        var tabBtns = Array.prototype.slice.call(body.querySelectorAll(".lot-tab"));
        function selectTab(name, focus) {
          lotTab = (name === "reading" || name === "lib") ? name : "paper";
          tabBtns.forEach(function (b) {
            var on = b.getAttribute("data-tab") === lotTab;
            b.setAttribute("aria-selected", on ? "true" : "false");
            b.tabIndex = on ? 0 : -1;
            if (on && focus) b.focus({ preventScroll: true });
          });
          ["paper", "reading", "lib"].forEach(function (id) {
            var el = body.querySelector("#lotPanel-" + id);
            if (el) el.hidden = lotTab !== id;
          });
          body.scrollTop = 0;
        }
        tabBtns.forEach(function (b, i) {
          b.onclick = function () { selectTab(b.getAttribute("data-tab"), false); };
          b.onkeydown = function (e) {
            if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
            e.preventDefault();
            var next = tabBtns[(i + (e.key === "ArrowRight" ? 1 : tabBtns.length - 1)) % tabBtns.length];
            selectTab(next.getAttribute("data-tab"), true);
          };
        });
        selectTab(lotTab, false);

        var again = body.querySelector("#lotAgain");
        if (again) again.onclick = function () { closeSheet(); setTimeout(doLot, 260); };
        var keep = body.querySelector("#lotKeep");
        if (keep) keep.onclick = function () { closeSheet(); toast("誠心領受 · 願所願遂心"); };
        var browse = body.querySelector("#lotBrowse");
        if (browse) browse.onclick = function () { MM.showLotPreview(n); };

        if (preview) {
          var pick = body.querySelector("#lotPick"), gridEl = body.querySelector("#lotGrid");
          if (pick && gridEl) pick.onclick = function () {
            gridEl.hidden = !gridEl.hidden;
            pick.setAttribute("aria-expanded", gridEl.hidden ? "false" : "true");
            if (!gridEl.hidden) gridEl.scrollIntoView({ block: "nearest" });
          };
          if (gridEl) gridEl.onclick = function (e) {
            var b = e.target.closest("[data-jump]"); if (!b) return;
            var target = lots[parseInt(b.getAttribute("data-jump"), 10) - 1];
            if (target) showLot(target, { preview: true });
          };
          Array.prototype.forEach.call(body.querySelectorAll("[data-lotnav]"), function (b) {
            b.onclick = function () {
              var target = lots[n - 1 + parseInt(b.getAttribute("data-lotnav"), 10)];
              if (target) showLot(target, { preview: true });
            };
          });
          var close2 = body.querySelector("#lotClose2");
          if (close2) close2.onclick = closeSheet;
          var draw = body.querySelector("#lotDraw");
          if (draw) draw.onclick = function () { closeSheet(); setTimeout(doLot, 260); };
        }
      });

    if (!preview) {
      caption("第 " + n + " 籤 · " + grade + (L.story ? "（" + L.story + "）" : ""), 4200);
      advanceGuide(4);
    }
  }

  /* 只供選號瀏覽：不呼叫 shakeLot、不寫 state / localStorage */
  MM.showLotPreview = function (n) {
    var lots = window.LOTS || [];
    if (!lots.length) { toast("籤文資料載入中，請重新整理後再瀏覽"); return; }
    var idx = Math.max(0, Math.min(lots.length - 1, (parseInt(n, 10) || 1) - 1));
    showLot(lots[idx], { preview: true });
  };
  /* ---------------- 擲筊 ---------------- */
  /* 立筊：罕見（0.1%），視為「這一擲不算」，不計入連續聖筊。 */
  function jiaoLi() {
    A.wood(520);
    caption("立筊：筊杯立起 — 這一擲不算，請再擲一次。", 4200);
    toast("立筊 · 這一擲不算");
    MM.throwJiao("li", function () {
      var html =
        "<div class='jiao-wrap'><div class='jiao-block tai stand'></div><div class='jiao-block'></div></div>" +
        "<div class='res'>立筊</div><div class='res-sub'>一片筊杯立起 — 民間解讀不一，本頁視為「這一擲不算」。</div>" +
        "<p class='small muted'>立筊機率約 0.1%。不算聖筊，也不中斷連續聖筊；再擲一次即可。</p>" +
        "<div class='rule'></div>" +
        "<div class='row' style='gap:8px'><button class='btn primary' style='flex:1' id='jiaoLiAgain'>再擲一次</button><button class='btn ghost' id='jiaoLiDone'>圓滿</button></div>";
      sheet("擲筊請示", "立筊", html, function (body) {
        body.querySelector("#jiaoLiAgain").onclick = function () { closeSheet(); setTimeout(jiaoRound, 240); };
        body.querySelector("#jiaoLiDone").onclick = function () { closeSheet(); };
      });
    });
  }
  var jiaoCount = 0, jiaoLog = [], jiaoStreak = 0;
  function doJiao() {
    closeSheet(); goTo("jiao");
    jiaoCount = 0; jiaoLog = []; jiaoStreak = 0;
    jiaoRound();
  }
  function jiaoRound() {
    var res = (window.DIV ? DIV.rollJiao() : (Math.random() < .5 ? "sheng" : "yin"));
    if (res === "li") return jiaoLi();
    MM.throwJiao(res, function () {
      A.wood(res === "sheng" ? 660 : 440);
      jiaoLog.push(res); jiaoCount++;
      jiaoStreak = res === "sheng" ? jiaoStreak + 1 : 0;
      var need = state.jiaoNeed === 3 ? 3 : 1;
      var name = res === "sheng" ? "聖筊" : res === "xiao" ? "笑筊" : "陰筊";
      var desc = res === "sheng" ? "一平一凸 — 神明應允，所問可行。" : res === "xiao" ? "兩平 — 神明含笑未答，問題未清或時機未到。" : "兩凸 — 神明未允，宜再思量或改問方式。";
      caption(name + "：" + desc, 3600);
      toast(name);
      advanceGuide(5);
      var html =
        "<div class='jiao-wrap'><div class='jiao-block " + (res !== "yin" ? "tai" : "") + "'></div><div class='jiao-block " + (res === "sheng" ? "" : res === "xiao" ? "tai" : "tai") + "'></div></div>" +
        "<div class='res'>" + name + "</div><div class='res-sub'>" + desc + "</div>" +
        (need === 1
          ? (res === "sheng" ? "<p class='small'><b>已得一聖筊</b> — 所問已應允。</p>" : "<p class='small muted'>尚欠一聖筊；可再擲。</p>")
          : "<p class='small'>連續聖筊 <b>" + jiaoStreak + " / 3</b>" + (res === "sheng" && jiaoStreak < 3 ? " — 請再擲。" : "") + "</p>") +
        "<p class='small muted'>筊杯以竹木或塑膠製成，一面平、一面凸。擲下後：一平一凸為 <b>聖筊</b>（應允）、兩平為 <b>笑筊</b>（未明）、兩凸為 <b>陰筊</b>（不允）。</p>" +
        "<p class='small muted'>機率公開：以瀏覽器密碼學亂數擲出，聖筊 50%、笑筊 25%、陰筊 24.9%、立筊 0.1%；立筊視為「這一擲不算」。" +
        (need === 3 ? "現設為<b>連三聖筊</b>方為確認。" : "現設為<b>一聖筊</b>確認，可於設定改為連三聖筊。") + "</p>" +
        "<div class='rule'></div>" +
        "<div class='row' style='gap:8px'><button class='btn primary' style='flex:1' id='jiaoAgain'>再擲一次</button><button class='btn ghost' id='jiaoDone'>圓滿</button></div>";
      sheet("擲筊請示", name, html, function (body) {
        body.querySelector("#jiaoAgain").onclick = function () { closeSheet(); setTimeout(jiaoRound, 240); };
        body.querySelector("#jiaoDone").onclick = function () {
          closeSheet();
          var need = state.jiaoNeed === 3 ? 3 : 1;
          if (jiaoStreak >= need) toast(need === 3 ? "連三聖筊 · 神明應允，所願可成" : "得聖筊 · 所問已應允");
        };
      });
    });
  }

  /* ---------------- 上香 ---------------- */
  /* 自動帶位：延遲避開底板收合，再逐段呼叫場景步行控制。 */
  function walkIncense(x, z, cb) {
    var p = U.player, route = [], side = p.x < 0 ? -1 : 1;
    if (p.z > 11.8 && z < 11) {
      route.push([side * 3.2, Math.max(11.8, p.z)]);
      route.push([side * 3.2, 9.1]);
    }
    /* 殿中央金鹿擋住中軸：先由側邊繞過，再回中央通道。 */
    if (p.z > 3.8 && z < 3.8) {
      route.push([side * 2.6, 4.6]);
      route.push([side * 2.6, .4]);
    }
    /* 正殿主爐／香案：先回中央通道，再貼邊繞過主爐上階（香案已移上神壇平台）。 */
    if (z < -6.0 && p.z > -6.0) {
      route.push([0, -2.8]);
      route.push([x > 0 ? 1.9 : -1.9, -6.3]);
    }
    route.push([x, z]);
    var index = 0, deadline = Date.now() + 300000;
    function next() {
      if (!MM.Incense || !MM.Incense.isBusy()) return;
      if (Date.now() > deadline) { MM.Incense.cancel(); toast('帶位未完成，請移近香爐再試'); return; }
      var point = route[index++];
      if (!point) { p.yaw = Math.PI; p.pitch = -.09; if (cb) cb(); return; }
      /* 帶位只移動位置；朝神壇保持同一方向，不把避障轉角演成四方參拜。 */
      MM.walkTo(point[0], point[1], Math.PI, next);
    }
    setTimeout(next, 180);
  }

  var incenseUiBound = false;
  function incenseNotice(phase) {
    var message = phase === "traveling" ? "正帶你前往香爐，請稍候。"
      : phase === "bowing" ? "合十行禮中，請心念所求。"
      : phase === "settling" ? "香枝已落爐，儀式即將完成。"
      : phase === "offering" ? "香枝依次落爐中，請稍候。"
      : "上香儀式進行中，請稍候完成。";
    toast(message);
  }

  /* 上香：流程與狀態由 MM.Incense 管，這裡只接 UI */
  function incenseHooks() {
    if (!MM.Incense) return false;
    if (!incenseUiBound && MM.Incense.onState) {
      MM.Incense.onState(function (s) {
        var btn = $("#incBtn"), stamp = btn && btn.querySelector(".stamp"), label = $("#incLabel");
        if (!btn) return;
        btn.classList.toggle("ritual-busy", s.busy);
        btn.setAttribute("aria-busy", s.busy ? "true" : "false");
        btn.setAttribute("aria-label", s.busy ? "上香儀式進行中" : "上香");
        if (stamp) stamp.textContent = !s.busy ? "香" : s.phase === "bowing" ? "拜" : s.phase === "settling" ? "香" : "…";
        if (label) label.textContent = s.busy ? (s.phase === "bowing" ? "行禮中" : s.phase === "settling" ? "落爐中" : "上香中") : "上香";
      });
      incenseUiBound = true;
    }
    MM.Incense.configure({
      caption: function (t) { caption(t, 3200); },
      toast: function (t) { toast(t); },
      bow: function () { MM.bow(); A.bell(.1, false); },
      insert: function () { A.chime(); },
      travel: function (x, z, cb) { walkIncense(x, z, cb); },
      save: save,
      done: function (where) {
        if (where === "court") { advanceGuide(3); return; }
        state.incense++; save(); advanceGuide(3);
      }
    });
    return true;
  }

  function doIncense() {
    if (!incenseHooks()) return;
    if (MM.Incense.isBusy()) { incenseNotice(MM.Incense.phase()); return; }
    closeSheet();
    if (!MM.Incense.three()) toast("未能開始上香，請稍候再試。");
  }

  function step2Bow() {
    MM.bow(); A.bell(.12, true);
    setTimeout(function () { if (!sheetOpen) caption("向文武二帝行三鞠躬 —— 一願學業進步，二願行事正直，三願闔家平安。", 4200); }, 900);
  }

  /* ---------------- 參拜 ---------------- */
  function doBow() {
    var p = U.player;

    /* 先帶到定位，站定之後才起拜；避免「拜一拜、中途走位、再拜」的斷裂感。 */
    function bows() {
      MM.bow(); A.bell(.15, true);
      var lines = ["一鞠躬 — 願所求清晰，心不散亂。", "二鞠躬 — 願行事正直，無愧於心。", "三鞠躬 — 願家人平安，福澤綿長。"];
      var i = 0;
      caption(lines[0], 2600);
      var iv = setInterval(function () { i++; if (i < lines.length) { MM.bow(); caption(lines[i], 2600); } else clearInterval(iv); }, 2600);
      state.bowed = true; save();
      setTimeout(function () { if (!sheetOpen) caption("三拜禮成 —— 可上前摸文昌筆或關帝刀，沾智慧與運氣。", 4200); }, 6800);
      advanceGuide(1);
    }

    var a = U.stations.altar;
    var stand = 1.9;
    if (!a) { bows(); return; }
    var tx = a.x - Math.sin(a.face) * stand, tz = a.z - Math.cos(a.face) * stand;
    var off = Math.hypot(p.x - tx, p.z - tz);
    if (off < .9) {
      /* 已站在定位附近：直接對正神壇起拜，不再走位。 */
      MM.teleport(tx, tz, a.face, -.06);
      bows();
      return;
    }
    caption("正帶你到正殿中央，站定後行三鞠躬。", 2600);
    var started = false;
    var once = function () { if (started) return; started = true; bows(); };
    goTo("altar", 1.9, once);
    /* 若中途被玩家操作取消帶位，最多等 12 秒：先站到定位再起拜，不會邊行邊拜。 */
    setTimeout(function () {
      if (started) return;
      started = true;
      if (sheetOpen) return;
      MM.teleport(a.x - Math.sin(a.face) * stand, a.z - Math.cos(a.face) * stand, a.face, -.06);
      bows();
    }, 12000);
  }

  /* ---------------- 光明燈 ---------------- */
  function openLamps() {
    closeSheet(); goTo("lamps");
    renderLamps();
  }
  function renderLamps() {
    var lit = 0;
    var grid = "";
    for (var i = 0; i < 60; i++) {
      var on = !!state.lamps[i];
      if (on) lit++;
      grid += "<button data-lamp='" + i + "' class='" + (on ? "lit" : "") + (state.lamps[i] && state.lamps[i].mine ? " mine" : "") + "'>" + (i + 1) + "</button>";
    }
    var mineN = Object.keys(state.lamps).filter(function (k) { return state.lamps[k].mine; }).length;

    var lampPane =
      "<div class='lampinfo'><span>已點亮 <b>" + lit + "</b> 盞</span><span>我的燈 <b>" + mineN + "</b> 盞</span></div>" +
      "<div class='lamps' id='lampGrid'>" + grid + "</div>" +
      "<p class='small muted' style='margin-top:10px'>本站為虛擬體驗，不涉及付款，亦非廟方登記系統。廟方實際點燈服務為「宮燈」（$150／檔期，每月初一、初八、十五、廿三），善信於紅卡寫名懸於廟內。</p>" +
      "<p class='small muted'>線下登記：東華三院文武廟 · 2803 2916 · <a href='https://temples.tungwahcsd.org/temple-service/7' target='_blank' rel='noopener' style='color:var(--gold)'>廟方宮燈頁</a></p>";

    var seatPane =
      "<p class='small'>廟方設 <b>176 個「登科及第」個人位</b>，另設<b>共享空間</b>；善信把<b>學生證副本</b>奉於位上，祈求文昌帝君庇佑該學年學業進步。</p>" +
      "<div class='card-mini'>" +
        "<div class='kv'><span>開光</span><b>每年文昌啟智禮期間</b></div>" +
        "<div class='kv'><span>敬奉期</span><b>9 月 1 日 – 翌年 8 月 31 日</b></div>" +
        "<div class='kv'><span>登記</span><b>每年 7 月起，先到先得</b></div>" +
        "<div class='kv'><span>名額</span><b>176 個人位 ＋ 共享空間</b></div>" +
      "</div>" +
      "<p class='small muted'>「燈」與「位」在廟中屬兩項不同服務：燈求一年光明平安，位求一個學年學業；本站把兩者合併呈現，線下仍須分別向廟方登記。</p>" +
      "<label class='lbl'>稱呼（不上傳學生資料）</label><input class='field' id='seatName' maxlength='12' value='" + esc(state.name || "") + "' placeholder='例如：陳小明'>" +
      "<label class='lbl'>學年心願（選填）</label><input class='field' id='seatWish' maxlength='40' placeholder='例如：願今年考試順利，心定手穩'>" +
      "<div class='rule'></div><button class='btn primary block' id='seatBtn'>在虛擬位奉上一願</button>" +
      "<p class='small muted' style='margin-top:8px'>只會把稱呼與心願掛上公開祈願牆（標示為「登科及第」），不會收集學生證、學校或任何個人資料。</p>" +
      "<p class='small muted'>線下登記：2803 2916 · <a href='https://temples.tungwahcsd.org/temple-service/220' target='_blank' rel='noopener' style='color:var(--gold)'>廟方登科及第頁</a></p>";

    var html =
      "<p class='small muted'>一盞燈求一年光明，一個位求一個學年。兩者在廟中屬不同服務，此頁合併呈現；本站只做虛擬體驗。</p>" +
      "<div class='seg' id='lampSeg'><button data-lt='lamp' class='on'>點光明燈</button><button data-lt='seat'>登科及第</button></div>" +
      "<div id='paneLamp'>" + lampPane + "</div>" +
      "<div id='paneSeat' hidden>" + seatPane + "</div>";

    sheet("光明燈 · 登科及第", "LIGHT & SEAT", html, function (body) {
      var seg = body.querySelector("#lampSeg");
      seg.addEventListener("click", function (e) {
        var b = e.target.closest("[data-lt]"); if (!b) return;
        var which = b.getAttribute("data-lt");
        Array.prototype.forEach.call(seg.querySelectorAll("button"), function (x) { x.classList.toggle("on", x === b); });
        body.querySelector("#paneLamp").hidden = which !== "lamp";
        body.querySelector("#paneSeat").hidden = which !== "seat";
      });
      body.querySelector("#lampGrid").addEventListener("click", function (e) {
        var b = e.target.closest("[data-lamp]"); if (!b) return;
        pickLamp(+b.getAttribute("data-lamp"));
      });
      body.querySelector("#seatBtn").onclick = function () {
        var n = body.querySelector("#seatName").value.trim() || "善信";
        var w = body.querySelector("#seatWish").value.trim();
        if (!w) { toast("可寫一句學年心願"); return; }
        var btn = this; btn.disabled = true;
        wallReq("/wishes", "POST", { name: n, text: w, color: "jade", type: "seat", dev: devId() }).then(function (r) {
          btn.disabled = false;
          if (r.error === "support" || r.error === "rate" || r.error === "filter" || r.error === "text") { toast(r.message || "未能掛上"); return; }
          if (r.error) { toast(r.message || "未能掛上，請再試"); return; }
          state.name = n;
          state.wallTokens = state.wallTokens || {};
          state.wallTokens[r.id] = r.token;
          state.seat = { on: true, t: Date.now() }; save();
          if (MM.setSeat) MM.setSeat(true, true);
          A.chime();
          toast("登科及第 · 位已亮起");
          caption("一位一願 · 願學業精進，心定手穩。", 3600);
        }).catch(function () { btn.disabled = false; toast("網絡不穩，請再試"); });
      };
    });
    advanceGuide(6);
  }
  function pickLamp(idx) {
    var cur = state.lamps[idx];
    if (cur) {
      sheet("第 " + (idx + 1) + " 盞 · " + (cur.name || "善信"), "LIGHT NO." + (idx + 1),
        "<p>此燈已由 <b>" + esc(cur.name || "善信") + "</b> 點亮" + (cur.wish ? "，心願：「" + esc(cur.wish) + "」" : "") + "。</p>" +
        "<p class='small muted'>燈火長明，象徵智慧與福慧相續。</p>" +
        (cur.mine ? "<button class='btn block' id='unlight'>熄燈</button>" : ""),
        function (body) {
          var u = body.querySelector("#unlight");
          if (u) u.onclick = function () {
            delete state.lamps[idx]; save(); MM.setLamp(idx, false); closeSheet(); renderLamps(); toast("已熄燈");
          };
        });
      return;
    }
    sheet("點第 " + (idx + 1) + " 盞光明燈", "LIGHT NO." + (idx + 1),
      "<label class='lbl'>姓名 / 闔家</label><input class='field' id='lampName' maxlength='12' placeholder='例如：陳大文 闔家' value='" + esc(state.name || "") + "'>" +
      "<label class='lbl'>心願（選填）</label><input class='field' id='lampWish' maxlength='24' placeholder='例如：學業進步、身體健康'>" +
      "<div class='rule'></div><button class='btn primary block' id='lightBtn'>點 燈</button>" +
      "<p class='small muted' style='margin-top:10px'>示意式功德，不涉及任何付款。</p>",
      function (body) {
        body.querySelector("#lightBtn").onclick = function () {
          var n = body.querySelector("#lampName").value.trim() || "善信";
          var w = body.querySelector("#lampWish").value.trim();
          state.name = n;
          state.lamps[idx] = { name: n, wish: w, mine: true, t: Date.now() };
          save(); MM.setLamp(idx, true, true); A.chime();
          closeSheet(); renderLamps(); toast("光明燈已亮起 · 第 " + (idx + 1) + " 盞");
          caption("一盞燈，一份願。願智慧常明。", 3200);
        };
      });
  }

  /* ---------------- 公開祈願牆 ---------------- */
  var WALL_API = "https://manmo-wall.forumdata.workers.dev";
  function devId() {
    var k = STORE + ".dev", v = null;
    try { v = localStorage.getItem(k); } catch (e) { }
    if (!v) {
      var a = new Uint8Array(8); (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : 0;
      v = Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("") + Date.now().toString(16);
      try { localStorage.setItem(k, v); } catch (e) { }
    }
    return v;
  }
  function wallReq(path, method, body) {
    return fetch(WALL_API + path, {
      method: method || "GET",
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) { return r.json().catch(function () { return {}; }); });
  }
  function wallTime(ts) {
    var d = new Date(ts), n = Date.now() - ts;
    if (n < 60e3) return "剛剛";
    if (n < 3600e3) return Math.floor(n / 60e3) + " 分鐘前";
    if (n < 86400e3) return Math.floor(n / 3600e3) + " 小時前";
    return (d.getMonth() + 1) + "/" + d.getDate();
  }
  function openWall() {
    closeSheet(); goTo("wishes");
    var html =
      "<p class='small muted'>公開的心願會掛在牆上，其他香客看得到；不設帳號，只用本機裝置碼辨識。請勿留下連結或聯絡方式。</p>" +
      "<label class='lbl'>署名（選填）</label><input class='field' id='wallName' maxlength='12' value='" + esc(state.name || "") + "' placeholder='善信'>" +
      "<label class='lbl'>心願</label><textarea class='field' id='wallText' maxlength='90' placeholder='例如：願母親手術順利，一家人平安'></textarea>" +
      "<div class='wall-sw' id='wallColor'>" +
        ["gold", "red", "jade", "rose"].map(function (c, i) { return "<button data-c='" + c + "' class='" + (i === 0 ? "on " : "") + "c-" + c + "' aria-label='" + c + "'></button>"; }).join("") +
      "</div>" +
      "<div class='rule'></div>" +
      "<button class='btn primary block' id='wallPost'>掛 上 祈 願 牆</button>" +
      "<div class='rule'></div>" +
      "<h4 class='wall-h'>牆上心願 <span id='wallTotal' class='small muted'></span></h4>" +
      "<div id='wallList' class='small muted'>載入中…</div>";
    sheet("祈願牆", "WISH WALL", html, function (body) {
      var color = "gold";
      body.querySelector("#wallColor").addEventListener("click", function (e) {
        var b = e.target.closest("[data-c]"); if (!b) return;
        color = b.getAttribute("data-c");
        Array.prototype.forEach.call(this.querySelectorAll("button"), function (x) { x.classList.toggle("on", x === b); });
      });
      function load() {
        var list = body.querySelector("#wallList");
        list.textContent = "載入中…";
        wallReq("/wishes?limit=30").then(function (d) {
          if (!d.wishes) { list.innerHTML = "<p>暫未連上祈願牆，請稍後再試。</p>"; return; }
          body.querySelector("#wallTotal").textContent = "（共 " + (d.total || 0) + " 張）";
          if (!d.wishes.length) { list.innerHTML = "<p>牆上仍空白 — 你可以掛上第一張。</p>"; return; }
          var mine = state.wallTokens || {};
          list.innerHTML = d.wishes.map(function (w) {
            var own = mine[w.id];
            return "<div class='wall-card c-" + esc(w.color) + "'>" +
              "<div class='wall-meta'><b>" + esc(w.name) + "</b><span>" + wallTime(w.ts) + (w.type === "lamp" ? " · 燈願" : w.type === "seat" ? " · 登科及第" : "") + "</span></div>" +
              "<p class='wall-txt'>" + esc(w.text) + "</p>" +
              "<div class='wall-act'>" +
                "<button class='btn ghost' data-qi='" + esc(w.id) + "'>集氣 " + (w.qi || 0) + "</button>" +
                "<button class='btn ghost' data-share='" + esc(w.id) + "'>分享</button>" +
                (own ? "<button class='btn ghost' data-del='" + esc(w.id) + "'>刪除</button>" : "<button class='btn ghost' data-rep='" + esc(w.id) + "'>檢舉</button>") +
              "</div></div>";
          }).join("");
        });
      }
      body.querySelector("#wallPost").onclick = function () {
        var t = body.querySelector("#wallText").value.trim();
        var n = body.querySelector("#wallName").value.trim();
        if (t.length < 2) { toast("請寫下一句心願"); return; }
        this.disabled = true;
        var btn = this;
        wallReq("/wishes", "POST", { name: n, text: t, color: color, type: "wish", dev: devId() }).then(function (r) {
          btn.disabled = false;
          if (r.error === "support" || r.error === "filter" || r.error === "rate" || r.error === "text") { toast(r.message || "未能掛上"); if (r.error === "support") sheet("請留意", "SUPPORT", "<p>" + esc(r.message) + "</p>"); return; }
          if (r.error) { toast(r.message || "未能掛上，請再試"); return; }
          state.wallTokens = state.wallTokens || {};
          state.wallTokens[r.id] = r.token; save();
          body.querySelector("#wallText").value = "";
          toast("已掛上祈願牆");
          load();
        }).catch(function () { btn.disabled = false; toast("網絡不穩，請再試"); });
      };
      body.querySelector("#wallList").addEventListener("click", function (e) {
        var qi = e.target.closest("[data-qi]"), rep = e.target.closest("[data-rep]"), del = e.target.closest("[data-del]"), sh = e.target.closest("[data-share]");
        if (qi) {
          wallReq("/wishes/" + qi.getAttribute("data-qi") + "/qi", "POST", { dev: devId() }).then(function (r) {
            if (r.qi != null) { qi.textContent = "集氣 " + r.qi; toast("已集氣"); }
            else toast(r.message || "未能集氣");
          });
        } else if (rep) {
          if (!confirm("確定檢舉這張心願？三個不同裝置檢舉後會先隱藏。")) return;
          wallReq("/wishes/" + rep.getAttribute("data-rep") + "/report", "POST", { dev: devId() }).then(function (r) {
            toast(r.hidden ? "已隱藏，待站長確認" : "已收到檢舉");
            load();
          });
        } else if (del) {
          var id = del.getAttribute("data-del");
          if (!confirm("確定刪除這張心願？")) return;
          wallReq("/wishes/" + id, "DELETE", { token: (state.wallTokens || {})[id] }).then(function (r) {
            if (r.ok) { delete state.wallTokens[id]; save(); toast("已刪除"); load(); }
            else toast("未能刪除");
          });
        } else if (sh) {
          var url = location.origin + "/manmotemple/?wish=" + sh.getAttribute("data-share");
          if (navigator.share) navigator.share({ title: "文武廟 · 祈願牆", url: url }).catch(function () { });
          else if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { toast("連結已複製"); });
          else toast(url);
        }
      });
      load();
    });
  }

  /* ---------------- 祈福牌 ---------------- */
  function openWish() {
    closeSheet(); goTo("wishes");
    var html = "<p class='small muted'>寫下心願，掛在殿側的祈福架上。牌會即時出現在 3D 場景，並保存在此裝置。</p>" +
      "<label class='lbl'>心願</label><textarea class='field' id='wishText' maxlength='24' placeholder='例如：願家人平安健康'></textarea>" +
      "<label class='lbl'>署名（選填）</label><input class='field' id='wishName' maxlength='8' value='" + esc(state.name || "") + "'>" +
      "<div class='rule'></div><button class='btn primary block' id='wishBtn'>掛 上 祈 福 牌</button>";
    if (state.wishes.length) {
      html += "<div class='rule'></div><h3 style='font-family:var(--serif);font-weight:400;color:var(--gold);font-size:13px;letter-spacing:.14em'>已掛的牌</h3>";
      state.wishes.slice(-8).reverse().forEach(function (w) { html += "<p class='small'>· " + esc(w.text) + (w.name ? "　—　" + esc(w.name) : "") + "</p>"; });
    }
    html += "<div class='rule'></div><button class='btn ghost block' id='wallOpen' style='margin-bottom:8px'>公開祈願牆（與其他香客同掛）›</button>";
    sheet("祈福牌", "WISH PLAQUE", html, function (body) {
      body.querySelector("#wallOpen").onclick = openWall;
      body.querySelector("#wishBtn").onclick = function () {
        var t = body.querySelector("#wishText").value.trim();
        if (!t) { toast("請先寫下心願"); return; }
        var n = body.querySelector("#wishName").value.trim();
        state.wishes.push({ text: t, name: n, t: Date.now() });
        if (n) state.name = n;
        save(); MM.addWish(t); A.wood(700);
        closeSheet(); toast("祈福牌已掛上");
        caption("願望已掛在殿側，隨風輕響。", 3200);
      };
    });
  }

  /* ---------------- 鳴鐘 / 擊鼓 ---------------- */
  function doBell() {
    closeSheet(); goTo("bell", 1.6);
    MM.ringBell(); A.bell(.9);
    caption("鐘聲一響，煩惱輕；鐘聲三響，心願達。", 3600);
    advanceGuide(2);
    setTimeout(function () { MM.ringBell(); A.bell(.55); }, 1400);
    setTimeout(function () { MM.ringBell(); A.bell(.35); }, 2800);
  }
  function doDrum() {
    closeSheet(); goTo("drum", 1.6);
    MM.hitDrum(); A.drum();
    caption("暮鼓晨鐘 · 鼓聲沉厚，提醒一日三省。", 3200);
    setTimeout(function () { MM.hitDrum(); A.drum(); }, 700);
  }

  /* ---------------- 香油 ---------------- */
  function doDonate() {
    closeSheet(); goTo("donate");
    sheet("添香油", "MERIT", "<p>廟宇的香火與維修，歷來靠善信一點一滴支持。此頁為文化體驗，<b>不設任何付款</b>。</p>" +
      "<p class='small muted'>如欲真正支持文武廟，可於廟內香油箱隨喜，或經東華三院捐款。</p>" +
      "<div class='rule'></div><button class='btn block ghost' id='donateOk'>誠心一拜</button>", function (body) {
        body.querySelector("#donateOk").onclick = function () { closeSheet(); MM.bow(); A.bell(.2, true); caption("心香一瓣，功德無量。", 3000); };
      });
  }




  /* ---------------- 仰望匾額 ---------------- */
  function lookPlaque() {
    MM.setCam(0, 7.9, 0, 0.5);
    var html =
      "<img src='assets/plaque.jpg' alt='帝德同沾匾額' style='width:100%;border-radius:10px;border:1px solid rgba(230,184,100,.2)'>" +
      "<p class='small muted' style='margin-top:6px'>「帝德同沾」匾額（3D 重建）· 場景重現於入口上方</p>" +
      "<p>「<b>帝德同沾</b>」意為萬民同沾帝君聖德。此匾為光緒十九年（<b>1893</b>）冬季，重園社一眾信眾為文武廟重修工程祈願順利而送贈，至今百餘年。</p>" +
      "<p class='small muted'>廟外門楣另懸「文武廟」匾；花崗石門框上仍刻有建廟年份。實地此匾刻於入口的擋中（木雕屏風）上，場景將它重現於入口上方；因位置高，站在殿內需抬頭仰望 — 已在場景中為你調好角度。</p>" +
      "<div class='rule'></div><button class='btn block ghost' id='plaqueMap'>在 Google 真實內景找這塊匾 ↗</button>";
    sheet("帝德同沾", "PLAQUE · 1893", html, function (body) {
      var b = body.querySelector("#plaqueMap");
      if (b) b.onclick = function () { window.open("https://maps.app.goo.gl/kpzhRfBQccijEMmH9?g_st=ac", "_blank", "noopener"); };
    });
  }

  /* ---------------- 摸聖物 ---------------- */
  function doRelics(kind) {
    if (!state.bowed) {
      toast("先向文武二帝參拜，再上前摸聖物");
      doBow();
      return;
    }
    closeSheet();
    goTo(kind === "brush" ? "brush" : "blade");
    if (MM.touchRelic) MM.touchRelic(kind);
    A.chime();
    state.relics[kind] = (state.relics[kind] || 0) + 1;
    save();
    if (kind === "brush") {
      caption("掌心輕貼文昌筆 —— 願文思敏捷，功名有路。", 3600);
      toast("已摸文昌筆 · 智慧加身");
    } else {
      caption("掌心輕貼關帝刀 —— 願財運亨通，貴人扶持。", 3600);
      toast("已摸關帝刀 · 財運貴人");
    }
    setTimeout(renderRelics, 400);
  }
  function openRelics() {
    closeSheet();
    renderRelics();
  }
  function renderRelics() {
    var r = state.relics || {};
    var ok = !!state.bowed;
    var html =
      "<p>參拜之後，善信會上前<b>摸聖物</b>：掌心輕貼，心中默念所求，藉聖物之靈氣沾取智慧與運氣。</p>" +
      (ok ? "" : "<p class='small' style='color:#e8b25e'>未參拜 — 先向文武二帝行三拜，才上前摸聖物。</p>") +
      "<div class='cat' style='align-items:center'><b style='flex:0 0 52px'>文昌筆</b><span style='flex:1'>民間象徵<b>智慧、功名、考試</b>與文思；考生、學生、寫作人較常摸。<br><span class='small muted'>已摸 " + (r.brush || 0) + " 次</span></span>" +
      "<button class='btn ghost small' data-relic='brush' " + (ok ? "" : "disabled style='opacity:.45'") + ">摸一摸</button></div>" +
      "<div class='cat' style='align-items:center'><b style='flex:0 0 52px'>關帝刀</b><span style='flex:1'>民間象徵<b>財運、貴人、事業</b>與決斷；營商、轉職、求貴人較常摸。<br><span class='small muted'>已摸 " + (r.blade || 0) + " 次</span></span>" +
      "<button class='btn ghost small' data-relic='blade' " + (ok ? "" : "disabled style='opacity:.45'") + ">摸一摸</button></div>" +
      "<div class='rule'></div>" +
      "<button class='btn block primary' id='relicBow'>" + (ok ? "再向文武二帝參拜" : "先參拜（三拜）") + "</button>" +
      "<p class='small muted' style='margin-top:12px'>殿前兩座聖物為互動重現：文昌筆斜擱筆架，關帝刀立於刀座。習俗僅供文化體驗。</p>";
    sheet("摸聖物", "SACRED OBJECTS", html, function (body) {
      body.onclick = function (e) {
        var b = e.target.closest("[data-relic]"); if (!b || b.disabled) return;
        doRelics(b.getAttribute("data-relic"));
      };
      var bb = body.querySelector("#relicBow");
      if (bb) bb.onclick = function () { closeSheet(); doBow(); };
    });
  }

  /* ---------------- 金鹿 · 貼金箔 ---------------- */
  function doDeer() {
    closeSheet(); goTo("deer");
    renderDeer();
  }
  function renderDeer() {
    var AR = MM.DEER_AREAS, order = MM.deerOrder || Object.keys(AR);
    var done = MM.gildedAreas();
    var rows = "";
    order.forEach(function (k) {
      var a = AR[k], hit = done.indexOf(k) >= 0;
      rows += "<div class='cat' style='align-items:center'><b style='flex:0 0 44px'>" + a.name + "</b>" +
        "<span style='flex:1'>" + a.mean + "<br><span class='small muted'>" + a.who + "</span></span>" +
        (hit ? "<span class='chip on' style='flex:0 0 auto'>已貼</span>"
             : "<button class='btn ghost small' data-gild='" + k + "' style='flex:0 0 auto'>貼金箔</button>") + "</div>";
    });
    var html =
      "<p>鹿，喻意<b>俸祿</b>，是<b>文昌帝君座前神獸</b>。善信會先到廟內櫃位請金箔（2020 年公告列每片 HK$18，現價以廟方為準），雙手合十向文昌帝君稟明姓名、所求，然後小心打開金箔，輕輕貼在金鹿身上。</p>" +
      "<p class='small muted'>金箔貼在不同位置，象徵不同的祈願方向：</p>" +
      rows +
      "<div class='rule'></div>" +
      "<p class='small'>已貼 <b style='color:var(--gold)'>" + done.length + "</b> / " + order.length + " 處。金箔會即時出現在殿內金鹿身上，並保存在此裝置。</p>" +
      "<div class='row' style='gap:8px;flex-wrap:wrap'>" +
      (done.length < order.length ? "<button class='btn primary' id='gildAll' style='flex:1'>全部貼上</button>" : "<button class='btn ghost' id='gildReset'>重設金鹿</button>") +
      (done.length < order.length ? "<button class='btn ghost' id='gildReset'>重設</button>" : "") + "</div>" +
      "<p class='small muted' style='margin-top:12px'>本頁為文化習俗模擬，不收取費款、不提供代貼服務。資料參考東華三院文武廟「祈願金鹿」介紹。" +
      " <a href='https://temples.tungwahcsd.org/latest-events/detail?id=270' target='_blank' rel='noopener' style='color:var(--gold)'>原文 ↗</a></p>";
    sheet("金鹿 · 貼金箔祈願", "GOLDEN DEER", html, function (body) {
      body.onclick = function (e) {
        var b = e.target.closest("[data-gild]"); if (!b) return;
        var k = b.getAttribute("data-gild");
        if (MM.gildDeer(k)) {
          if (state.deer.indexOf(k) < 0) state.deer.push(k);
          save(); A.chime(); toast(A_AREAS_NAME(k) + "已貼上金箔");
          renderDeer();
        }
      };
      var all = body.querySelector("#gildAll");
      if (all) all.onclick = function () {
        var n = 0;
        (MM.deerOrder || Object.keys(MM.DEER_AREAS)).forEach(function (k) {
          if (MM.gildDeer(k)) { if (state.deer.indexOf(k) < 0) state.deer.push(k); n++; }
        });
        if (n) { save(); A.chime(); }
        toast(n ? "金箔已貼滿 · 祿氣盈門" : "金鹿已貼滿金箔");
        renderDeer();
      };
      var rs = body.querySelector("#gildReset");
      if (rs) rs.onclick = function () {
        MM.resetDeer(); state.deer = []; save(); renderDeer(); toast("已重設金鹿");
      };
    });
  }
  function A_AREAS_NAME(k) { return (MM.DEER_AREAS[k] || {}).name || "金鹿"; }

  /* ---------------- settings ---------------- */
  /* ---------------- 節慶模式 ---------------- */
  var FEST = [
    { id: "none", name: "平常" },
    { id: "newyear", name: "農曆新年" },
    { id: "wenchang", name: "文昌誕" },
    { id: "autumn", name: "秋祭" }
  ];
  function setFestival(id) {
    state.festival = id; save();
    if (MM.setFestival) MM.setFestival(id);
    var f = FEST.filter(function (x) { return x.id === id; })[0];
    toast("節慶模式：" + (f ? f.name : "平常"));
    var seg = document.querySelector("#festSeg");
    if (seg) Array.prototype.forEach.call(seg.querySelectorAll("button"), function (b) { b.classList.toggle("on", b.getAttribute("data-fest") === id); });
  }

  /* ---------------- 攝太歲 ---------------- */
  function openTaisui() {
    closeSheet();
    var now = new Date().getFullYear();
    var html =
      "<p>太歲為當年值年之神。民俗以出生年地支與當年太歲比較，<b>值、沖、刑、害、破</b> 者為「犯太歲」，會到廟「攝太歲」求平安。</p>" +
      "<label class='lbl'>出生年份（西曆）</label><input class='field' id='tsYear' inputmode='numeric' maxlength='4' placeholder='例如：1987' value='" + (state.taisuiYear || "") + "'>" +
      "<div class='rule'></div><button class='btn primary block' id='tsGo'>看今年運程</button>" +
      "<div id='tsOut' style='margin-top:14px'></div>" +
      "<p class='small muted' style='margin-top:14px'>今年為 " + now + " 年（" + MM.yearGanzhi(now) + "年 · " + MM.zodiacName(MM.zodiacOf(now)) + "）。以上為民俗參考，不作醫療、投資或法律依據。</p>";
    sheet("攝太歲", "TAI SUI · " + now, html, function (body) {
      body.querySelector("#tsGo").onclick = function () {
        var y = parseInt(body.querySelector("#tsYear").value, 10);
        if (!y || y < 1900 || y > now) { toast("請輸入 1900 至今年的西曆年份"); return; }
        state.taisuiYear = y; save();
        var r = MM.checkTaiSui(y, now);
        var hit = r.hits.length > 0;
        var out =
          "<div class='cat'><b>你</b><span>" + r.birth.year + " 年 · 生肖 <b>" + r.birth.zodiac + "</b>（" + r.birth.zhi + "）</span></div>" +
          "<div class='cat'><b>今年</b><span>" + r.now.ganzhi + " 年 · 太歲生肖 <b>" + r.now.zodiac + "</b>（" + r.now.zhi + "）</span></div>" +
          "<div class='res' style='font-size:19px;margin-top:12px'>" + (hit ? r.hits.join(" · ") : "今年不犯太歲") + "</div>" +
          "<p class='small muted' style='text-align:center'>" + (hit
            ? "宜到文武廟攝太歲：請太歲衣、上香稟告姓名生辰，行禮後化寶，求一年順遂。"
            : "無需攝太歲；如想祈福，可點光明燈或摸金鹿。") + "</p>" +
          "<div class='row' style='gap:8px;margin-top:10px'><button class='btn ghost small' id='tsLamp' style='flex:1'>點光明燈</button><button class='btn ghost small' id='tsDeer' style='flex:1'>摸金鹿</button></div>";
        body.querySelector("#tsOut").innerHTML = out;
        body.querySelector("#tsLamp").onclick = function () { closeSheet(); setTimeout(openLamps, 200); };
        body.querySelector("#tsDeer").onclick = function () { closeSheet(); setTimeout(doDeer, 200); };
      };
    });
  }

  /* 舊版只留最後一籤：遷移一次，不虛構原求籤時間。 */
  if (!Array.isArray(state.lotHistory)) state.lotHistory = [];
  if (!state.lotHistory.length && state.lastLotData && state.lastLotData.n) {
    state.lotHistory.push({ n: state.lastLotData.n, grade: state.lastLotData.gz || "", at: null, legacy: true });
    save();
  }
  function lotHistoryHtml() {
    if (!state.lotHistory.length) return "<p class='small muted'>尚未有經聖筊確認的求籤紀錄。</p>";
    return "<p class='small muted'>共 " + state.lotHistory.length + " 次 · 最新在前；瀏覽不計求籤。紀錄只儲存於此瀏覽器。</p>" +
      state.lotHistory.map(function (r, i) {
        var date = r.at ? new Date(r.at).toLocaleString('zh-HK', { hour12: false }) : "舊版保留 · 日期不詳";
        return "<button class='btn ghost block' data-lot-history='" + i + "' style='margin:8px 0;text-align:left;white-space:normal'>第 " + esc(r.n) + " 籤 · " + esc(r.grade) + "<br><span class='small muted'>" + esc(date) + " · 重看籤文 ›</span></button>";
      }).join("");
  }
  /* ---------------- 我的祈願 ---------------- */
  function mineSummary() {
    var lamps = Object.keys(state.lamps).filter(function (k) { return state.lamps[k].mine; }).map(function (k) { return +k; });
    return {
      lot: state.lastLotData,
      lamps: lamps,
      deer: (MM.gildedAreas ? MM.gildedAreas() : state.deer || []),
      relics: state.relics || {},
      ts: state.taisuiYear ? MM.checkTaiSui(state.taisuiYear) : null
    };
  }
  function openMine() {
    closeSheet();
    var m = mineSummary();
    var html =
      "<p class='small muted'>你在此裝置留下的祈願：求籤、光明燈、金鹿金箔、聖物與太歲。</p>" +
      "<div class='cat'><b>求籤</b><span>" + (m.lot ? "第 " + m.lot.n + " 籤 · " + m.lot.gz + "　" + m.lot.poem[0] : "未求籤") + "</span></div>" +
      "<details id='lotHistory'><summary style='color:var(--gold);cursor:pointer;padding:12px 0'>求籤歷史（" + state.lotHistory.length + " 次）</summary>" + lotHistoryHtml() + "</details>" +
      "<div class='cat'><b>光明燈</b><span>" + (m.lamps.length ? m.lamps.length + " 盞（第 " + m.lamps.slice(0, 6).map(function (i) { return i + 1; }).join("、") + (m.lamps.length > 6 ? "…" : "") + "）" : "未點燈") + "</span></div>" +
      "<div class='cat'><b>金鹿</b><span>" + (m.deer.length ? m.deer.length + " / 5 處貼上金箔" : "未貼金箔") + "</span></div>" +
      "<button class='btn ghost block' id='mineWall' style='margin:4px 0 12px'>祈願牆 · 看看別人的心願 ›</button>" +
      "<div class='cat'><b>五爐</b><span>" + (function(){
        try { var q = (JSON.parse(localStorage.getItem(STORE) || "{}").quick || {}).done || []; return q.length + " / 5 爐"; } catch(e) { return "未開始"; }
      })() + "</span></div>" +
      "<div class='cat'><b>祈福牌</b><span>" + (state.wishes && state.wishes.length ? "共 " + state.wishes.length + " 塊 · 最近：" + esc(state.wishes[state.wishes.length - 1].text) : "未掛祈福牌") + "</span></div>" +
      "<div class='cat'><b>聖物</b><span>文昌筆 " + (m.relics.brush || 0) + " 次 · 關帝刀 " + (m.relics.blade || 0) + " 次</span></div>" +
      "<div class='cat'><b>太歲</b><span>" + (m.ts ? (m.ts.hits.length ? m.ts.hits.join(" · ") : "不犯太歲") + "（" + m.ts.birth.year + " 年生）" : "未查") + "</span></div>" +
      "<div class='rule'></div><div id='cardPrev'></div>" +
      "<button class='btn primary block' id='cardDl'>下載分享圖卡</button>" +
      "<button class='btn ghost block' id='cardReset' style='margin-top:8px'>清除本機記錄</button>";
    sheet("我的祈願", "MY WISHES", html, function (body) {
      var mw = body.querySelector("#mineWall");
      if (mw) mw.onclick = openWall;
      body.querySelectorAll('[data-lot-history]').forEach(function (btn) {
        btn.onclick = function () {
          var r = state.lotHistory[+btn.getAttribute('data-lot-history')];
          var L = (window.LOTS || []).find(function (x) { return x.n === +r.n; });
          if (L) showLot(L, { preview: true, tab: "paper" });
          else toast("此籤資料暫未載入，請重新整理");
        };
      });
      var url = drawCard(m);
      body.querySelector("#cardPrev").innerHTML = "<img src='" + url + "' style='width:100%;border-radius:12px;border:1px solid rgba(230,184,100,.3)'>";
      body.querySelector("#cardDl").onclick = function () {
        var a = document.createElement("a");
        a.href = url; a.download = "文武廟祈願-" + new Date().toISOString().slice(0, 10) + ".png";
        document.body.appendChild(a); a.click(); a.remove();
        toast("已下載圖卡");
      };
      body.querySelector("#cardReset").onclick = function () {
        if (!confirm("清除後，光明燈、金箔、祈福牌、籤文與太歲記錄都會消失，確定？")) return;
        localStorage.removeItem(STORE); location.reload();
      };
    });
  }

  function drawCard(m) {
    var W = 1080, H = 1350;
    var c = document.createElement("canvas"); c.width = W; c.height = H;
    var x = c.getContext("2d");
    var g = x.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#2a0f0a"); g.addColorStop(.55, "#3d1410"); g.addColorStop(1, "#160806");
    x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.strokeStyle = "rgba(230,184,100,.75)"; x.lineWidth = 4; x.strokeRect(34, 34, W - 68, H - 68);
    x.strokeStyle = "rgba(230,184,100,.28)"; x.lineWidth = 1.5; x.strokeRect(52, 52, W - 104, H - 104);
    x.textAlign = "center"; x.fillStyle = "#e6b864";
    x.font = "700 76px 'Noto Serif TC','Songti TC',serif";
    x.fillText("文武廟", W / 2, 170);
    x.font = "400 26px 'Noto Sans TC',sans-serif";
    x.fillStyle = "rgba(230,200,150,.75)";
    x.fillText("MAN MO TEMPLE · 上環荷李活道", W / 2, 216);

    var y = 300;
    function line(k, v) {
      x.textAlign = "left";
      x.fillStyle = "rgba(230,184,100,.85)";
      x.font = "500 30px 'Noto Sans TC',sans-serif";
      x.fillText(k, 110, y);
      x.fillStyle = "#f7ecd6";
      x.font = "400 32px 'Noto Sans TC',sans-serif";
      var s = String(v), line1 = "", lines = [];
      for (var i = 0; i < s.length; i++) {
        if (x.measureText(line1 + s[i]).width > 600) { lines.push(line1); line1 = s[i]; }
        else line1 += s[i];
      }
      lines.push(line1);
      for (var l = 0; l < Math.min(2, lines.length); l++) x.fillText(lines[l], 330, y + l * 42);
      y += 100 + (lines.length > 1 ? 40 : 0);
    }
    line("求籤", m.lot ? "第 " + m.lot.n + " 籤 · " + m.lot.gz + "｜" + m.lot.poem[0] : "未求籤");
    line("光明燈", m.lamps.length ? "已點 " + m.lamps.length + " 盞" : "未點燈");
    line("金鹿", m.deer.length ? m.deer.length + " / 5 處貼上金箔" : "未貼金箔");
    line("祈福牌", state.wishes && state.wishes.length ? state.wishes[state.wishes.length - 1].text : "未掛祈福牌");
    line("聖物", "文昌筆 " + (m.relics.brush || 0) + " 次 · 關帝刀 " + (m.relics.blade || 0) + " 次");
    if (m.ts) line("太歲", (m.ts.hits.length ? m.ts.hits.join(" · ") : "不犯太歲") + "（" + m.ts.birth.year + " 年生）");

    x.textAlign = "center";
    x.fillStyle = "rgba(230,184,100,.65)";
    x.font = "400 24px 'Noto Sans TC',sans-serif";
    x.fillText("handcraftstudio.eu.org/manmotemple", W / 2, H - 96);
    x.fillStyle = "rgba(230,200,160,.45)";
    x.font = "400 20px 'Noto Sans TC',sans-serif";
    var d = new Date();
    x.fillText(d.getFullYear() + "." + (d.getMonth() + 1) + "." + d.getDate() + "　文化體驗 · 非廟方官方", W / 2, H - 58);
    return c.toDataURL("image/png");
  }

  function openSettings() {
    var html = "<div class='set-row'><span>畫質</span><div class='seg' id='qSeg'>" +
      ["high", "mid", "low"].map(function (q) { return "<button data-q='" + q + "' class='" + (state.quality === q ? "on" : "") + "'>" + ({ high: "高", mid: "中", low: "省電" })[q] + "</button>"; }).join("") +
      "</div></div>" +
      "<div class='set-row'><span>節慶模式</span><div class='seg' id='festSeg'>" +
      FEST.map(function (f) { return "<button data-fest='" + f.id + "' class='" + (state.festival === f.id ? "on" : "") + "'>" + f.name + "</button>"; }).join("") +
      "</div></div>" +
      "<div class='set-row'><span>求籤確認</span><div class='seg' id='jiaoSeg'>" +
      "<button data-jn='1' class='" + (state.jiaoNeed !== 3 ? "on" : "") + "'>一聖筊</button>" +
      "<button data-jn='3' class='" + (state.jiaoNeed === 3 ? "on" : "") + "'>連三聖筊</button>" +
      "</div></div>" +
      "<div class='set-row'><span>字幕</span><div class='seg' id='capSeg'><button data-cap='1' class='" + (state.captions ? "on" : "") + "'>開</button><button data-cap='0' class='" + (state.captions ? "" : "on") + "'>關</button></div></div>" +
      "<div class='set-row'><span>環境音</span><input type='range' min='0' max='100' step='5' id='volA' value='" + Math.round(state.volAmb * 100) + "'></div>" +
      "<div class='set-row'><span>音效</span><input type='range' min='0' max='100' step='5' id='volS' value='" + Math.round(state.volSfx * 100) + "'></div>" +
      "<div class='set-row'><span>畫面震動（行走）</span><div class='seg' id='bobSeg'><button data-bob='1' class='on'>開</button><button data-bob='0'>關</button></div></div>" +
      "<div class='rule'></div>" +
      "<p class='small muted'>操作：拖曳畫面環視 · 左下搖桿或 WASD 行走 · 點擊動作鍵互動。手機建議用 Safari / Chrome。</p>" +
      "<div class='rule'></div>" +
      "<a class='btn block ghost' href='/manmotemple/quick/' style='margin-bottom:8px;text-align:center;display:block'>快速參拜（不用 3D）</a>" +
      "<a class='btn block ghost' href='/manmotemple/calendar/' style='margin-bottom:8px;text-align:center;display:block'>參拜行事曆（可訂閱）</a>" +
      "<a class='btn block ghost' href='/manmotemple/sources/' style='margin-bottom:8px;text-align:center;display:block'>資料來源與考訂</a>" +
      (installEvt ? "<button class='btn block ghost' id='installBtn' style='margin-bottom:8px'>安裝到主畫面（PWA）</button>" : "") +
      "<button class='btn block ghost' id='resetBtn'>重設本機記錄</button>" +
      "<p class='small muted' style='margin-top:14px'>擲筊以瀏覽器密碼學亂數產生：聖筊 50%、笑筊 25%、陰筊 24.9%、立筊 0.1%，不因所求而調整。</p>" +
      "<p class='small muted' style='margin-top:14px'>本頁為文化導覽創作，非東華三院或文武廟官方網站。3D 場景為程序化重建，並非實景攝影測量。</p>";
    sheet("設定", "SETTINGS", html, function (body) {
      body.querySelector("#qSeg").addEventListener("click", function (e) {
        var b = e.target.closest("[data-q]"); if (!b) return;
        state.quality = b.getAttribute("data-q"); save(); MM.setQuality(state.quality);
        Array.prototype.forEach.call(body.querySelectorAll("#qSeg button"), function (x) { x.classList.toggle("on", x === b); });
        toast("畫質：" + b.textContent);
      });
      body.querySelector("#festSeg").onclick = function (e) {
        var b = e.target.closest("[data-fest]"); if (!b) return;
        setFestival(b.getAttribute("data-fest"));
      };
      body.querySelector("#jiaoSeg").addEventListener("click", function (e) {
        var b = e.target.closest("[data-jn]"); if (!b) return;
        state.jiaoNeed = +b.getAttribute("data-jn") === 3 ? 3 : 1; save();
        Array.prototype.forEach.call(body.querySelectorAll("#jiaoSeg button"), function (x) { x.classList.toggle("on", x === b); });
        toast("求籤確認：" + (state.jiaoNeed === 3 ? "連三聖筊" : "一聖筊"));
      });
      body.querySelector("#capSeg").onclick = function (e) {
        var b = e.target.closest("[data-cap]"); if (!b) return;
        state.captions = b.getAttribute("data-cap") === "1"; save();
        Array.prototype.forEach.call(body.querySelectorAll("#capSeg button"), function (x) { x.classList.toggle("on", x === b); });
        if (!state.captions) $("#caption").classList.remove("show");
      };
      body.querySelector("#volA").oninput = function (e) { state.volAmb = e.target.value / 100; save(); A.setVolume("ambient", state.volAmb); };
      body.querySelector("#volS").oninput = function (e) { state.volSfx = e.target.value / 100; save(); A.setVolume("sfx", state.volSfx); };
      body.querySelector("#bobSeg").addEventListener("click", function (e) {
        var b = e.target.closest("[data-bob]"); if (!b) return;
        var on = b.getAttribute("data-bob") === "1";
        MM._.player.bobLock = !on;
        Array.prototype.forEach.call(body.querySelectorAll("#bobSeg button"), function (x) { x.classList.toggle("on", x === b); });
      });
      var ib = body.querySelector("#installBtn");
      if (ib) ib.onclick = function () { installEvt.prompt(); installEvt = null; ib.remove(); };
      body.querySelector("#resetBtn").onclick = function () {
        if (!confirm("重設後，已點的光明燈與祈福牌記錄會清除，確定？")) return;
        localStorage.removeItem(STORE);
        state.lamps = {}; state.wishes = []; state.incense = 0; state.guide = 0;
        location.reload();
      };
    });
  }

  /* ---------------- hall switch ---------------- */
  var HALLS = [
    { id: "main", name: "文武廟 · 正殿", seal: "文", sub: "上環荷李活道", x: 0, z: 8.2, yaw: Math.PI },
    { id: "well", name: "天井 · 塔香", seal: "香", sub: "重檐歇山頂", x: 0, z: 5.6, yaw: Math.PI, pitch: .32 },
    { id: "censer", name: "立地大香爐", seal: "爐", sub: "正殿中央", x: 0, z: -2.9, yaw: Math.PI },
    { id: "court", name: "廟前 · 天公爐", seal: "廟", sub: "荷李活道", x: 0, z: 25.2, yaw: Math.PI, pitch: .27 }
  ];
  function openHalls() {
    var html = "<p class='small muted'>選擇殿區，場景會帶你過去。</p>";
    HALLS.forEach(function (h) {
      html += "<button class='btn block ghost' style='text-align:left;margin-bottom:8px' data-hall='" + h.id + "'><b style='font-family:var(--serif);letter-spacing:.16em;color:var(--gold);font-weight:400'>" + h.name + "</b><br><span class='small muted'>" + h.sub + "</span></button>";
    });
    sheet("切換殿區", "HALLS", html, function (body) {
      body.addEventListener("click", function (e) {
        var b = e.target.closest("[data-hall]"); if (!b) return;
        var h = HALLS.filter(function (x) { return x.id === b.getAttribute("data-hall"); })[0];
        closeSheet(); MM.setCam(h.x, h.z, h.yaw, h.pitch == null ? -.02 : h.pitch);
        $("#hallName").textContent = h.name; $("#hallSub").textContent = h.sub; $("#hallSeal").textContent = h.seal;
      });
    });
  }
  $("#hallBtn").onclick = openHalls;

  /* ---------------- station routing ---------------- */
  function goTo(station, dist, cb) {
    var s = U.stations[station];
    if (!s) { if (cb) cb(); return; }
    var d = dist || 1.9;
    var dx = Math.sin(s.face) * d, dz = Math.cos(s.face) * d;
    MM.setCam(s.x - dx, s.z - dz, s.face, station === "lamps" ? -.05 : -.06, cb);
  }
  function runStation(id) {
    switch (id) {
      case "incense": doIncense(); break;
      case "altar": doBow(); break;
      case "lot": doLot(); break;
      case "jiao": doJiao(); break;
      case "lamps": openLamps(); break;
      case "wishes": openWish(); break;
      case "bell": doBell(); break;
      case "drum": doDrum(); break;
      case "donate": doDonate(); break;
      case "courtyard": goTo("courtyard"); caption("廟前天公爐 · 先敬天，後拜神。", 3000); break;
      case "deer": doDeer(); break;
      case "guide": if (MM.guideNPC) MM.guideNPC.open(); break;
      case "brush": doRelics("brush"); break;
      case "plaque": lookPlaque(); break;
      case "blade": doRelics("blade"); break;
    }
  }

  /* near-station chip */
  MM.onNear = function (s) {
    if (MM.Incense && MM.Incense.isBusy()) return;
    var el = $("#nearChip");
    if (!s) { el.classList.add("hidden"); return; }
    if (s.id === "guide" && MM.guideNPC) {
      el.classList.remove("hidden");
      el.innerHTML = "<span>廟祝 · 問問廟祝</span><b style='color:#ffe0a6'>對話 ›</b>";
      el.onclick = function () { MM.guideNPC.open(); };
      return;
    }
    el.classList.remove("hidden");
    el.innerHTML = "<span>" + s.label + "</span><b style='color:#ffe0a6'>互動 ›</b>";
    el.onclick = function () { runStation(s.id); };
    /* highlight matching action */
    var map = { incense: "incBtn", altar: "bowBtn", lot: "lotBtn", jiao: "jiaoBtn", lamps: "lampBtn", bell: "bowBtn", deer: "deerBtn" };
    ["bowBtn", "jiaoBtn", "lotBtn", "incBtn", "lampBtn", "deerBtn", "relicBtn"].forEach(function (k) { $("#" + k).classList.remove("hot"); });
    if (map[s.id]) $("#" + map[s.id]).classList.add("hot");
  };

  /* ---------------- buttons ---------------- */
  $("#bowBtn").onclick = doBow;
  $("#jiaoBtn").onclick = doJiao;
  $("#lotBtn").onclick = doLot;
  function doIncenseOne() {
    if (!incenseHooks()) return;
    if (MM.Incense.isBusy()) { incenseNotice(MM.Incense.phase()); return; }
    closeSheet();
    if (!MM.Incense.one()) toast("未能開始上香，請稍候再試。");
  }

  /* 上香：先選「三炷」或「一炷」，避免誤觸 */
  function openIncenseSheet() {
    if (!incenseHooks()) return;
    if (MM.Incense.isBusy()) { incenseNotice(MM.Incense.phase()); return; }
    var outdoor = !!(U.player && U.player.z > 9);
    var html =
      "<p class='small muted'>" + (outdoor
        ? "你而家喺廟前。傳統次序：先敬天公，再入殿向文武二帝上香。"
        : "你而家喺正殿。傳統次序：香案取香 → 主爐上香。") + "</p>" +
      "<div class='rule'></div>" +
      "<button class='btn primary block' id='incThree' style='text-align:left'>" + (outdoor ? "天公爐一炷 · 敬天" : "三炷清香 · 敬神") + "<p class='small' style='margin:6px 0 0;opacity:.8'>" +
      (outdoor ? "先敬天公：天公爐 1 炷，行禮後插香；入殿後再向文武二帝上香。" : "香案取香點燃（不插香）→ 正殿主爐行禮後插三炷。") + "</p></button>" +
      "<button class='btn ghost block' id='incOne' style='margin-top:10px;text-align:left'>一炷心香 · 補香<p class='small' style='margin:6px 0 0;opacity:.8'>只插最近香爐 1 炷，適合已上過香或只想靜心。</p></button>" +
      "<p class='small muted' style='margin-top:14px'>" + (outdoor ? "先敬天公，再入殿向文武二帝行禮。" : "三炷代表敬天、敬地、敬神；一炷多為「心香」，心誠則靈。") + "</p>";
    sheet("上香", "INCENSE", html, function (body) {
      body.querySelector("#incThree").onclick = function () {
        if (MM.Incense.isBusy()) { incenseNotice(MM.Incense.phase()); return; }
        closeSheet(); setTimeout(doIncense, 200);
      };
      body.querySelector("#incOne").onclick = function () {
        if (MM.Incense.isBusy()) { incenseNotice(MM.Incense.phase()); return; }
        closeSheet(); setTimeout(doIncenseOne, 200);
      };
    });
  }
    var btn = document.getElementById("incBtn"), label = document.getElementById("incLabel");
    if (btn) btn.onclick = openIncenseSheet;
    if (label) label.textContent = "上香";
  $("#lampBtn").onclick = openLamps;
  $("#deerBtn").onclick = doDeer;
  $("#relicBtn").onclick = openRelics;
  $("#infoBtn").onclick = renderIntro;
  $("#tsBtn").onclick = openTaisui;
  $("#myBtn").onclick = openMine;
  $("#setBtn").onclick = openSettings;
  $("#soundBtn").onclick = function () {
    var m = A.toggleMute();
    state.sound = !m; save();
    $("#wave").style.display = m ? "none" : "";
    $("#mute").style.display = m ? "" : "none";
    $("#soundBtn").classList.toggle("on", !m);
    toast(m ? "已靜音" : "聲音已開");
  };

  /* ---------------- joystick ---------------- */
  (function () {
    var joy = $("#joy"), knob = $("#joyKnob"), active = false, cx = 0, cy = 0, R = 40;
    function setKnob(dx, dy) {
      knob.style.transform = "translate(" + dx + "px," + dy + "px)";
      MM.setJoy(dx / R, dy / R);
    }
    function start(e) {
      active = true;
      var r = joy.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2;
      R = r.width * .38;
      move(e); joy.setPointerCapture(e.pointerId);
    }
    function move(e) {
      if (!active) return;
      var dx = e.clientX - cx, dy = e.clientY - cy, d = Math.hypot(dx, dy);
      if (d > R) { dx = dx / d * R; dy = dy / d * R; }
      setKnob(dx, dy);
    }
    function end(e) { active = false; setKnob(0, 0); }
    joy.addEventListener("pointerdown", start);
    joy.addEventListener("pointermove", move);
    joy.addEventListener("pointerup", end);
    joy.addEventListener("pointercancel", end);
    window.addEventListener("blur", end);
  })();

  /* ---------------- in-app browser ---------------- */
  (function () {
    var ua = navigator.userAgent || "";
    var inApp = /Line|FBAN|FBAV|Instagram|Twitter|MicroMessenger|Snapchat/i.test(ua);
    if (inApp) {
      setTimeout(function () {
        var d = document.createElement("div");
        d.className = "glass";
        d.style.cssText = "position:fixed;left:12px;right:12px;top:90px;z-index:60;padding:14px 16px;border-radius:12px;font-size:12px;line-height:1.7";
        d.innerHTML = "<b style='color:#e6b864'>建議用瀏覽器開啟</b><br>App 內瀏覽器可能較卡。請點右上「⋯」→ 在 Safari / Chrome 開啟。<button style='float:right;color:#e6b864'>✕</button>";
        d.querySelector("button").onclick = function () { d.remove(); };
        document.body.appendChild(d);
        clearTimeout(d._t = setTimeout(function () { d.remove(); }, 9000));
      }, 2500);
    }
  })();

  /* ---------------- boot ---------------- */
  function boot() {
    if (booted) return; booted = true;
    A.init(); A.bgm("assets/bgm.mp3"); A.start();
    A.setVolume("ambient", state.volAmb); A.setVolume("sfx", state.volSfx);
    MM.init(document.getElementById("c"), { quality: state.quality });
    MM.buildWorld();
    if (MM.buildDeer) MM.buildDeer();
    if (MM.buildRelics) MM.buildRelics();
    if (MM._initFestival) MM._initFestival();
    if (MM.setFestival) MM.setFestival(state.festival || "none");
    if (MM.optimizeStatic) MM.optimizeStatic();
    if (MM.mergeColored) MM.mergeColored();
    if (MM.Incense && MM.Incense.restore) MM.Incense.restore();   /* 接返上次未燒完的香（必須在幾何合併之後） */
    if (state.quality === 'high' && MM.enableShadows) MM.enableShadows();
    if (state.deer && state.deer.length) state.deer.forEach(function (k) { MM.gildDeer(k, true); });
    if (state.wishes && state.wishes.length) state.wishes.forEach(function (w) { MM.addWish(w.text, true); });
    /* restore lamps */
    Object.keys(state.lamps).forEach(function (k) { MM.setLamp(+k, true, false); });
    /* restore wishes (silent) */
    $("#loader").classList.add("done");
    progress(100);
    setTimeout(function () { $("#loader").classList.add("done"); }, 300);
    renderGuide();
    /* deep link：#lot / #deer / #lamps / #relics / #taisui / #mine / #plaque */
    setTimeout(function () {
      var h = (location.hash || "").replace("#", "");
      var map = { lot: doLot, deer: doDeer, lamps: openLamps, relics: openRelics, taisui: openTaisui, mine: openMine, plaque: lookPlaque, jiao: doJiao };
      if (map[h]) map[h]();
    }, 1600);
    if (state.lastLot) { /* keep for reference */ }
    setTimeout(function () {
      if (!localStorage.getItem(STORE + ".seen")) {
        caption("拖曳畫面環視 · 左下搖桿行走", 4200);
        localStorage.setItem(STORE + ".seen", "1");
      }
    }, 1400);
    if (state.sound === false) { A.toggleMute(); $("#wave").style.display = "none"; $("#mute").style.display = ""; $("#soundBtn").classList.remove("on"); }
    /* keyboard shortcuts */
    window.addEventListener("keydown", function (e) {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      var k = e.key.toLowerCase();
      if (k === "1" || k === "b") doBow();
      else if (k === "2" || k === "i") doIncense();
      else if (k === "3" || k === "l") doLot();
      else if (k === "4" || k === "j") doJiao();
      else if (k === "5") openLamps();
      else if (k === "6") doBell();
      else if (k === "escape") closeSheet();
    });

  }

  $("#enterBtn").onclick = function () {
    $("#enterBtn").classList.remove("on");
    $("#ldHint").textContent = "正在開光…";
    setTimeout(boot, 120);
  };

  /* preload fake progress; enable enter when assets are ready */
  window.addEventListener("load", function () {
    var imgs = ["assets/coils1.jpg", "assets/interior2.jpg", "assets/altar.jpg", "assets/exterior1.jpg"];
    var done = 0;
    imgs.forEach(function (src) {
      var im = new Image(); im.onload = im.onerror = function () { done++; if (done === imgs.length) finish(); }; im.src = src;
    });
    setTimeout(finish, 2600);
    function finish() {
      if (pct < 92) progress(100, "準備完成");
      clearInterval(tick);
      $("#ldBar").style.width = "100%";
      $("#ldHint").textContent = "香火已備";
      $("#enterBtn").classList.add("on");
    }
  });

  /* PWA */
  if ("serviceWorker" in navigator && location.protocol === "https:") {
    navigator.serviceWorker.register("sw.js?v=36", { updateViaCache: "none" }).then(function (reg) {
      reg.update().catch(function () { });
      reg.addEventListener("updatefound", function () {
        var w = reg.installing;
        if (!w) return;
        w.addEventListener("statechange", function () {
          if (w.state === "installed" && navigator.serviceWorker.controller) toast("已更新至最新版本");
        });
      });
    }).catch(function () { });
  }
})();
