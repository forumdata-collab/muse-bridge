# 文武廟 · 雲端參拜 — 開發者備註

> 純靜態網站（HTML + three.js r128，無 build step）。解壓即部署：任何靜態主機、Cloudflare Pages、GitHub Pages 均可。

## 1. 檔案地圖

```
index.html            版面 / CSS / UI 結構（inline CSS）
manifest.webmanifest  PWA
sw.js                 Service Worker（network-first 程式碼，cache-first 圖片）
robots.txt, sitemap.xml
assets/               相片、icon
vendor/three.min.js   three.js r128
js/
  scene.js     場景渲染、相機/玩家、燈光、塔香、匾額、walkTo/setCam/bow
  world.js     建築、神像、香案、光明燈牆、金鹿位置、stations
  incense.js   ★ 上香子系統（香爐註冊表 + 儀式狀態機）
  deer.js      金鹿模型 + 五區貼金箔
  relics.js    文昌筆 / 關帝刀
  festival.js  節慶模式 + 攝太歲計算
  optimize.js  靜態幾何合併（657 → 214 draw calls）
  app.js       UI / 狀態 / 求籤 / 擲筊 / 光明燈 / 分享卡（~1000 行）
  lots.js      關聖帝君一百籤資料（100 首，~40KB）
  audio.js     Web Audio 合成音效
tests/incense.spec.py  上香回歸測試（5 情境）
```

## 2. 關鍵 API

| API | 說明 |
|---|---|
| `MM.init(canvas,{quality})` | 建立 renderer / 場景 |
| `MM.buildWorld()` | 建立廟宇、香爐、stations |
| `MM.setCam(x,z,yaw,pitch)` | 平滑移到定點（保留給 UI） |
| `MM.teleport(x,z,yaw,pitch)` | 即時定位（測試用） |
| `MM.bow()` | 觸發合十動畫 |
| `MM.Incense.register({id,name,group,ashY,approach})` | 註冊香爐 |
| `MM.Incense.three()` / `.one()` / `.cancel()` | 三炷儀式 / 一炷心香 / 取消 |
| `MM.Incense.configure(hooks)` | 注入 caption/toast/bow/travel/save/done |
| `MM.optimizeStatic()` / `MM.mergeColored()` | 幾何合併（boot 時自動跑） |
| `MM.setFestival(mode)` | `none / newyear / wenchang / autumn` |
| `MM.checkTaiSui(year)` | 回傳值/沖/刑/害/破 |

## 3. 上香流程（現行）

```
三炷（殿內）：香案取香、點燃（不插香）→ 正殿主爐行禮後插 3 炷
三炷（廟外）：天公爐 1 炷（提示入殿後再上香）
一炷　　　　：最近香爐 1 炷，人不移動
每爐次序　　：到位（淡入淡出 0.3s）→ 行禮（bow:true 步驟：主爐 / 天公爐 / 一炷）→ 停 0.9s → 插香
完成結語　　：按模式分清——hall「三炷清香已上」/ court「天公爐清香已上」/ one「一炷心香已上 · 心誠則靈」
煙霧　　　　：register 可傳 smoke（該爐 U.makeSmoke 回傳值）；offer 時該爐煙霧轉濃，缺省 fallback U.censerSmoke
```

狀態機在 `js/incense.js`：`run(mode)` 以 `buildSteps(mode)` 產生步驟表，單一 `busy` + `token` 取消機制；重複點擊會被忽略，空註冊表時 `one()` 安全返回 false。

## 3b. 香枝燃燒（時間衰減）

- 每枝香記錄 `{censerId, i, h, t0, dur}`，存在 `localStorage["manmo.sticks.v1"]`
- `BURN_MS = 8 分鐘`（`MM.Incense.setBurnMs(ms)` 可調，測試用）
- 每 8 秒 `tick()` 按 `elapsed/dur` 縮短香枝、降火頭、減光暈；`p>=1` 即移除並清記錄
- **關頁再開**：`restore()` 於 boot（幾何合併之後）按時間差重建，8 分鐘後燒盡
- 分頁隱藏時暫停 tick，`visibilitychange` 返嚟即重算

## 3c. 背景音樂（assets/bgm.mp3）

- 站主提供曲目，壓縮為 mono 44.1kHz / 40kbps MP3（466KB → 291KB），loudnorm −18 LUFS、頭尾 20ms 淡入淡出
- `A.bgm(url)` 設定來源，`A.start()`（使用者按「入殿」後）才 fetch + `decodeAudioData` → `BufferSource.loop = true`，sample-accurate 無接縫
- 經 `ambientGain` 輸出，設定頁「環境音」滑桿與靜音同時生效
- 解碼失敗會自動退回舊有合成 drone（`buildAmbient()`）

## 4. 資料出處

- 籤詩、聖意、東坡解：雷雨師一百籤傳統文本（公共領域），以公開整理資料校對；**未採用他人白話、故事或問事詳解**
- 聖意白話短註為本作品自行整理的詞典（`app.js` 內 `SY_CAT` / `SY_VERDICT`）
- 相片：Wikimedia Commons（見 README 授權段）

## 5. 已知限制

- `optimize.js` 以材質簽名合併幾何；若日後新增「會獨立改材質」的物件，需標 `userData.dynamic = true`，否則會被合併
- 光明燈改用 InstancedMesh（`world.js` buildLamps），逐盞顏色用 `instanceColor`，發光 overlay 另計 1 draw call
- 無 headless 專用 fallback：Playwright 在 SwiftShader 下 frame 很慢，長流程測試需先 `MM.pause()`（tests 已這樣做）
- Service Worker 版本字串在 `sw.js` 的 `CACHE` 與 `app.js` 的 `sw.js?v=N`，改版要一齊改

## 6. 待定問題（給廟方/內容審）

1. ~~三炷是否應全部插主爐？~~ 已定：香案只取香、點燃；三炷全插主爐。
2. 第 20、33 籤典故（韓信功成身退、莊子慕道）在參考資料無對應，需廟方籤本核實。
3. 第 49、54 籤典故從缺（兩個來源皆無），UI 自動隱藏該行。

## 7. 本機測試

```bash
python3 -m http.server 8899          # 在專案根目錄
python3 tests/incense.spec.py http://127.0.0.1:8899/
# 需 playwright（chromium）
```

## 8. v95（2026-11-10）

見 `README-MUSE.md` §7 與根目錄 `CHANGES-v95.md`。重點：金鹿與供品細緻度、程序化鎏金／青花／橙皮／竹紋、`U.ENV` 環境反光、燭光閃爍、快取 bump 到 v95。

新增動態件必須標 `userData.dynamic = true`，否則 `optimizeStatic` 會合併走動畫（鹿角輕擺舊版就係咁失效）。新增會獨立改材質嘅物件同理。

## 9. v96（2026-11-10）

見 `README-MUSE.md` §8 與根目錄 `CHANGES-v96.md`。重點：鹿角樞軸回歸修復、鹿嘴麥穗、鹿台牌面遮擋回歸修復、
NPC 衣服細節、求籤取香（3D 香盤 + 介面第一步）、香案爐腳穿透修復。

教訓：`dynamic` 標記會令舊嘅群組轉角真正生效 — 改樞軸之前，先檢查 `onFrame` 有無大角度靜態轉角；
實心「框」會遮住後面嘅牌面 — 框只可以用邊條，或者牌面要喺框前面。

## 10. v97（2026-11-10，已部署）
已交付（inbox/v97-20261110.json，commit 348cf53e）並由 Hermes 部署上線（2026-11-10 09:53 HKT，status state "deployed"）。
見 `README-MUSE.md` §9 與根目錄 `CHANGES-v97.md`。重點：麥穗由直棍改為 S 形彎曲 + 上下唇瓣托住，穗頭微垂。

教訓：wheat 局部 +z 約等於世界向下 — 上唇要放局部 -z，下唇放局部 +z；寫 code 前先計一次旋轉方向，唔好靠估。

## 11. v98（2026-11-10，未交付）
見根目錄 `CHANGES-v98.md`。重點：香盤由供桌右邊（x=+.55）移去香案左邊（x=-1.3），對返取香動畫嘅企位。

教訓：加 3D 道具嗰陣，要同時對返用佢嘅動畫企位同字幕 — v96 加香盤只係諗「供桌要有香盤先講得通」，冇對過 `incense.js` 嘅 approach 點 (-1.3, -7.1)，結果道具同動畫分開兩邊。之後加親同儀式有關嘅道具，先查 `incense.js buildSteps` 同 `MM.Incense.register` 嘅 approach 座標。

金鹿按實物相改進：做舊金箔要另開鹿專用貼圖，唔好改全廟共用嘅 `TEX.gold`（會連供品、香爐一齊變舊）；靈芝柄身螺旋用 `computeFrenetFrames` 貼住柄徑走，偏距要跟返柄徑漸收，唔係粗頭會埋咗入柄、幼尾會浮起；麥穗垂柄用 wheat 局部座標 — 局部 +z 係世界向下、局部 -y 係世界向後（貼喉胸），計清楚先畫曲線，唔好靠估；台座多咗一塊牌面之後，smoke test 唔可以直接攞 `plates[0]`，要按尺寸揀。
